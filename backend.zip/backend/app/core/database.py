
from prisma import Prisma
import logging

# Initialize Prisma client
prisma = Prisma()

# Function to connect Prisma client
async def connect_db():
    if not prisma.is_connected():  # Check if Prisma is already connected
        logging.debug("Connecting to Prisma...")
        await prisma.connect()

# Function to disconnect Prisma client
async def disconnect_db():
    if prisma.is_connected():  # Only disconnect if connected
        logging.debug("Disconnecting from Prisma...")
        await prisma.disconnect()

# Dependency to get the connected Prisma client
async def get_prisma_client():
    if not prisma.is_connected():
        logging.debug("Prisma client not connected. Connecting now...")
        await prisma.connect()  # Ensure Prisma client is connected
    return prisma