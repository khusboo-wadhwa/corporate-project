import logging
from logging.handlers import RotatingFileHandler

logging.basicConfig(
    filename='application.log',  # Log file name
    level=logging.DEBUG,         # Set log level to DEBUG
    format='%(asctime)s - %(levelname)s - %(message)s',  # Log message format
    filemode='a'  # Use 'a' to append logs; change to 'w' to overwrite
)

# Set up logging configuration
def setup_logging():
    log_formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
    log_file = 'application.log'

    # Configure the file handler
    file_handler = RotatingFileHandler(log_file, maxBytes=5 * 1024 * 1024, backupCount=3)
    file_handler.setFormatter(log_formatter)
    file_handler.setLevel(logging.DEBUG)

    # Configure the root logger
    root_logger = logging.getLogger()
    root_logger.setLevel(logging.DEBUG)  # Log all levels (DEBUG, INFO, ERROR, etc.)
    root_logger.addHandler(file_handler)

    # Optional: Prevent duplicate logs in the console if using uvicorn
    uvicorn_logger = logging.getLogger("uvicorn")
    uvicorn_logger.propagate = False
