# import firebase_admin
# from firebase_admin import auth, credentials
# from app.config import settings

# # Initialize Firebase with service account
# cred = credentials.Certificate(settings.GOOGLE_APPLICATION_CREDENTIALS)
# firebase_admin.initialize_app(cred)

# def create_firebase_user(email: str, password: str, is_admin: bool = False) -> str:
#     user = auth.create_user(email=email, password=password)
#     auth.set_custom_user_claims(user.uid, {"is_admin": is_admin})
#     return user.uid

# def verify_admin_claim(email: str) -> bool:
#     user = auth.get_user_by_email(email)
#     return user.custom_claims.get("is_admin", False)

import firebase_admin
from firebase_admin import auth, credentials
from app.core.config import settings
import logging

# Initialize Firebase Admin SDK if not already initialized
if not firebase_admin._apps:
    cred = credentials.Certificate(settings.GOOGLE_APPLICATION_CREDENTIALS)
    firebase_admin.initialize_app(cred)

logging.basicConfig(level=logging.INFO)

async def get_firebase_user_by_email(email: str):
    """
    Retrieve Firebase user by email.
    """
    try:
        return auth.get_user_by_email(email)
    except auth.UserNotFoundError:
        raise Exception("No user record found for the provided email.")
    except Exception as e:
        raise Exception(f"Error fetching user by email: {str(e)}")

async def set_admin_claim(uid: str):
    """
    Set custom admin claim for the given Firebase user ID.
    """
    try:
        auth.set_custom_user_claims(uid, {"is_admin": True})
    except Exception as e:
        raise Exception(f"Error setting admin claim: {str(e)}")

async def verify_admin_claim(uid: str) -> bool:
    """
    Verify if the Firebase user has the 'is_admin' claim.
    """
    try:
        user = auth.get_user(uid)
        return bool(user.custom_claims and user.custom_claims.get('is_admin', False))
    except auth.UserNotFoundError:
        raise Exception("No user record found for the provided UID.")
    except Exception as e:
        raise Exception(f"Error verifying admin claim: {str(e)}")

async def create_firebase_user(email: str, password: str) -> str:
    """
    Create a Firebase user and return the UID.
    """
    try:
        user = auth.create_user(email=email, password=password)
        return user.uid
    except Exception as e:
        raise Exception(f"Error creating Firebase user: {str(e)}")



async def verify_firebase_token(id_token: str) -> str:
    """
    Verifies the Firebase ID token and returns the verified phone number.
    """
    try:
        decoded_token = auth.verify_id_token(id_token)
        phone_number = decoded_token.get("phone_number")
        if not phone_number:
            raise Exception("Phone number not found in ID token.")
        return phone_number[-10:]  # Only return last 10 digits (optional based on your use-case)
    except Exception as e:
        logging.error(f"Firebase token verification failed: {e}")
        raise Exception("Invalid or expired Firebase ID token.")
