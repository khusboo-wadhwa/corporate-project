"""Basic connection example.
"""

import redis

r = redis.Redis(
    host='redis-13762.c330.asia-south1-1.gce.redns.redis-cloud.com',
    port=13762,
    decode_responses=True,
    username="default",
    password="FmfoHGDBEdkvSpZbWME6ApG02UKsIUuL",
)

success = r.set('foo', 'bar')
# True

result = r.get('foo')
print(result)
# >>> bar

