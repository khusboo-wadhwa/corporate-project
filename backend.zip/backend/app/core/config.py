import os
from dotenv import load_dotenv
from pathlib import Path

load_dotenv()

class Settings:
    #GOOGLE_APPLICATION_CREDENTIALS = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'dataplatform.json')
    GOOGLE_APPLICATION_CREDENTIALS = Path(__file__).resolve().parent.parent/ 'dataplatform.json'

settings = Settings()
