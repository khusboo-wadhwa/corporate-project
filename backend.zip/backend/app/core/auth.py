# from app.core.database import get_prisma_client
# from prisma import Prisma
# import logging
# from app.core.firebase import (
#     get_firebase_user_by_email,
#     set_admin_claim,
#     verify_admin_claim,
#     create_firebase_user,
# )
# import datetime 
# from fastapi import HTTPException, status
# from typing import Optional, List
# from prisma.enums import UserRoleEnum  # Import the UserRoleEnum from Prisma enums
# import firebase_admin
# from firebase_admin import auth as firebase_auth,exceptions
# from fastapi.security import OAuth2PasswordBearer
# import jwt

# # JWT configurations
# SECRET_KEY = "https://jwt.io/#debugger-io?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyfQ.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c"  # Replace with your actual secret key
# ALGORITHM = "HS256"
# SESSION_TOKEN_EXPIRE_MINUTES = 2
# REFRESH_TOKEN_EXPIRE_MINUTES = 15

# #oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")
# oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/userManagement/token")


# logging.basicConfig(level=logging.INFO)

# # Initialize Prisma Client
# client = Prisma()

# async def check_if_admin_exists():
#     """
#     Check if an admin already exists in the Prisma database.
#     """
#     client = await get_prisma_client()  # Ensure Prisma client is connected
#     admin = await client.users1.find_first(where={"is_admin": True})
#     return admin

# async def login_user(email: str, password: str) -> dict:
#     """
#     Login function to verify if a user is an admin.
#     """
#     try:
#         user = await get_firebase_user_by_email(email)
#         is_admin = await verify_admin_claim(user.uid)
        
#         return {
#             "is_admin": is_admin,
#             "message": "Admin login successful." if is_admin else "Login successful."
#         }
#     except Exception as e:
#         raise Exception(f"Error logging in user: {str(e)}")

# async def create_user_in_db(data: dict):
#     """
#     Create a user record in Prisma database.
#     """
#     try:
#         client = await get_prisma_client()
#         new_user = await client.users1.create(data=data)
#         return new_user
#     except Exception as e:
#         logging.error(f"Error creating user in database: {e}")
#         raise Exception(f"Error creating user in database: {e}")

# async def create_user_and_register_in_db(
#     first_name: str,
#     last_name: str,
#     username: str,
#     email: str,
#     password: str,
#     is_admin: bool,
#     role: List[UserRoleEnum],  # Use UserRoleEnum for roles
#     mobile_number: int,
#     country_code: str,
#     phone_verification_code: str,
#     phone_verification_code_sent_at: datetime.datetime,
#     phone_verification_code_expires_at: datetime.datetime,
#     email_verification_code: str,
#     email_verification_code_sent_at: datetime.datetime,
#     email_verification_code_expires_at: datetime.datetime
# ):
#     """
#     Create a Firebase user, set claims if admin, and store the user in Prisma DB.
#     """
#     try:
#         if is_admin:
#             admin = await check_if_admin_exists()
#             if admin:
#                 raise Exception("Admin user already exists. Only one admin is allowed.")

#         # Create user in Firebase
#         uid = await create_firebase_user(email, password)
        
#         # Set custom claims if the user is an admin
#         if is_admin:
#             await set_admin_claim(uid)

#         # Store user details in Prisma database
#         user_data = {
#             "first_name": first_name,
#             "last_name": last_name,
#             "username": username,
#             "email": email,
#             "password": password,
#             "role": [role.value for role in role],  # Convert enum values to strings
#             "is_admin": is_admin,
#             "mobile_number": mobile_number,
#             "country_code": country_code,
#             "phone_verification_code": phone_verification_code,
#             "phone_verification_code_sent_at": phone_verification_code_sent_at,
#             "phone_verification_code_expires_at": phone_verification_code_expires_at,
#             "email_verification_code": email_verification_code,
#             "email_verification_code_sent_at": email_verification_code_sent_at,
#             "email_verification_code_expires_at": email_verification_code_expires_at,
#         }
        
#         new_user = await create_user_in_db(user_data)
        
#         return new_user

#     except Exception as e:
#         raise Exception(f"Error creating user: {e}")

# async def register_non_admin_user(
#     first_name: str,
#     last_name: str,
#     username: str,
#     email: str,
#     password: str,
#     country_code: str,
#     mobile_number: int,
#     role: List[UserRoleEnum],  # Use UserRoleEnum for roles
#     phone_verification_code: str,
#     phone_verification_code_sent_at: datetime.datetime,
#     phone_verification_code_expires_at: datetime.datetime,
#     email_verification_code: str,
#     email_verification_code_sent_at: datetime.datetime,
#     email_verification_code_expires_at: datetime.datetime
# ):
    
#     """
#     Wrapper to register a non-admin user with specified roles and personal details.
#     """
#     return await create_user_and_register_in_db(
#         first_name=first_name,
#         last_name=last_name,
#         username=username,
#         email=email,
#         password=password,
#         country_code=country_code,
#         mobile_number=mobile_number,
#         is_admin=False,
#         role=role,
#         phone_verification_code=phone_verification_code,
#         phone_verification_code_sent_at=phone_verification_code_sent_at,
#         phone_verification_code_expires_at=phone_verification_code_expires_at,
#         email_verification_code=email_verification_code,
#         email_verification_code_sent_at=email_verification_code_sent_at,
#         email_verification_code_expires_at=email_verification_code_expires_at
#     )


# async def is_email_taken(email: str) -> bool:
#     client = await get_prisma_client()
#     user = await client.users1.find_first(where={'email': email})
#     return user is not None

# async def is_username_taken(username: str) -> bool:
#     client = await get_prisma_client()
#     user = await client.users1.find_first(where={'username': username})
#     return user is not None

# async def is_mobile_number_taken(mobile_number: str) -> bool:
#     client = await get_prisma_client()
#     user = await client.users1.find_first(where={'mobile_number': mobile_number})
#     return user is not None
# # Helper Functions for Email Verification
# async def get_user_by_email_verification_code(email_verification_code: str) -> dict:
#     """
#     Retrieve a user by email verification code.
#     """
#     user = await client.users1.find_first(
#         where={"email_verification_code": email_verification_code}
#     )
#     return user

# async def update_user_email_verification_code(email: str, email_verification_code: str, email_verification_code_expires_at: datetime.datetime):
#     """
#     Update the email verification code and expiration time in the database for a user.
#     """
#     prisma = await get_prisma_client()
#     user = await prisma.users1.update(
#         where={"email": email},
#         data={
#             "email_verification_code": email_verification_code,
#             "email_verification_code_expires_at": email_verification_code_expires_at
#         }
#     )
#     return user


# async def get_user_by_email(email: str) -> Optional[dict]:
#     """
#     Retrieve a user by their email address.
#     """
#     try:
#         prisma = await get_prisma_client()  # Ensure Prisma client is connected

#         # Fetch user based on email
#         user = await prisma.users1.find_first(where={"email": email})
#         if not user:
#             logging.warning(f"User with email {email} not found.")
#         return user
#     except Exception as e:
#         logging.error(f"Error fetching user by email: {str(e)}")
#         return None


# async def update_user_password(email: str, hashed_password: str) -> Optional[dict]:
#     """
#     Update the password for a user identified by their email.
#     """
#     try:
#         prisma = await get_prisma_client()  # Ensure Prisma client is connected

#         # Update password in the database
#         updated_user = await prisma.users1.update(
#             where={"email": email},
#             data={"password": hashed_password}
#         )
#         logging.info(f"Password updated for user: {email}")
#         return updated_user
#     except Exception as e:
#         logging.error(f"Error updating user password for {email}: {str(e)}")
#         return None
    
# async def get_current_user(email: str):
#     """
#     Fetch the current user based on the provided email.
#     """
#     try:
#         prisma = await get_prisma_client()
#         user = await prisma.users1.find_first(where={"email": email})
#         if not user:
#             raise HTTPException(status_code=404, detail="User not found.")
#         return user
#     except Exception as e:
#         raise HTTPException(status_code=500, detail=f"Error fetching user: {str(e)}")

# def create_session_token(data: dict):
#     expire = datetime.utcnow() + timedelta(minutes=SESSION_TOKEN_EXPIRE_MINUTES)
#     data.update({"exp": expire})
#     return jwt.encode(data, SECRET_KEY, algorithm=ALGORITHM)


# def create_access_token(data: dict):
#     return jwt.encode(data, SECRET_KEY, algorithm=ALGORITHM)


# def create_refresh_token(data: dict):
#     expire = datetime.utcnow() + timedelta(minutes=REFRESH_TOKEN_EXPIRE_MINUTES)
#     return jwt.encode({**data, "exp": expire}, SECRET_KEY, algorithm=ALGORITHM)


# def decode_token(token: str):
#     try:
#         return jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
#     except jwt.ExpiredSignatureError:
#         raise HTTPException(status_code=401, detail="Token expired")
#     except jwt.InvalidTokenError:
#         raise HTTPException(status_code=401, detail="Invalid token")




from app.core.database import get_prisma_client
from prisma import Prisma
import logging
from app.core.firebase import (
    get_firebase_user_by_email,
    set_admin_claim,
    verify_admin_claim,
    create_firebase_user,
)
import datetime 
from fastapi import HTTPException, status
from typing import Optional, List
 # Import the UserRoleEnum from Prisma enums
import firebase_admin
from firebase_admin import auth as firebase_auth,exceptions
from fastapi.security import OAuth2PasswordBearer
import jwt

# JWT configurations
SECRET_KEY = "https://jwt.io/#debugger-io?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyfQ.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c"  # Replace with your actual secret key
ALGORITHM = "HS256"
SESSION_TOKEN_EXPIRE_MINUTES = 2
REFRESH_TOKEN_EXPIRE_MINUTES = 15

#oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/userManagement/token")


logging.basicConfig(level=logging.INFO)

# Initialize Prisma Client
client = Prisma()

# Helper function to fetch valid roles from the database
async def fetch_valid_roles() -> List[str]:
    """
    Fetch all valid roles from the aq_roles table.
    """
    prisma_client = await get_prisma_client()  # Ensure Prisma client is co}nnected
    roles = await prisma_client.aq_roles.find_many()
    return [role.role_name for role in roles]


async def check_if_admin_exists():
    """
    Check if an admin already exists in the Prisma database.
    """
    client = await get_prisma_client()  # Ensure Prisma client is connected
    admin = await client.aq_users.find_first(where={"is_admin": True})
    return admin

async def login_user(email: str, password: str) -> dict:
    """
    Login function to verify if a user is an admin.
    """
    try:
        user = await get_firebase_user_by_email(email)
        is_admin = await verify_admin_claim(user.uid)
        
        return {
            "is_admin": is_admin,
            "message": "Admin login successful." if is_admin else "Login successful."
        }
    except Exception as e:
        raise Exception(f"Error logging in user: {str(e)}")

async def create_user_in_db(data: dict):
    """
    Create a user record in Prisma database.
    """
    try:
        client = await get_prisma_client()
        new_user = await client.aq_users.create(data=data)
        return new_user
    except Exception as e:
        logging.error(f"Error creating user in database: {e}")
        raise Exception(f"Error creating user in database: {e}")

async def create_user_and_register_in_db(
    first_name: str,
    last_name: str,
    username: str,
    email: str,
    password: str,
    is_admin: bool,
    role: List[str],  # Role is now a list of strings
    mobile_number: int,
    country_code: str,
    phone_verification_code: str,
    phone_verification_code_sent_at: datetime.datetime,
    phone_verification_code_expires_at: datetime.datetime,
    email_verification_code: str,
    email_verification_code_sent_at: datetime.datetime,
    email_verification_code_expires_at: datetime.datetime
):
    """
    Create a Firebase user, set claims if admin, and store the user in Prisma DB.
    """
    try:
        # Fetch valid roles from the aq_roles table
        valid_roles = await fetch_valid_roles()

        # Check if all provided roles are valid
        for r in role:
            if r not in valid_roles:
                raise Exception(f"Invalid role: {r}. Please provide a valid role.")

        if is_admin:
            admin = await check_if_admin_exists()
            if admin:
                raise Exception("Admin user already exists. Only one admin is allowed.")

        # Create user in Firebase
        uid = await create_firebase_user(email, password)

        # Set custom claims if the user is an admin
        if is_admin:
            await set_admin_claim(uid)

        # Store user details in Prisma database
        user_data = {
            "first_name": first_name,
            "last_name": last_name,
            "username": username,
            "email": email,
            "password": password,
            "role": role,  # Directly use the provided roles
            "is_admin": is_admin,
            "mobile_number": mobile_number,
            "country_code": country_code,
            "phone_verification_code": phone_verification_code,
            "phone_verification_code_sent_at": phone_verification_code_sent_at,
            "phone_verification_code_expires_at": phone_verification_code_expires_at,
            "email_verification_code": email_verification_code,
            "email_verification_code_sent_at": email_verification_code_sent_at,
            "email_verification_code_expires_at": email_verification_code_expires_at,
        }

        new_user = await create_user_in_db(user_data)

        return new_user

    except Exception as e:
        raise Exception(f"Error creating user: {e}")

async def register_non_admin_user(
    first_name: str,
    last_name: str,
    username: str,
    email: str,
    password: str,
    country_code: str,
    mobile_number: int,
    role: List[str],  # Role is now a list of strings
    phone_verification_code: str,
    phone_verification_code_sent_at: datetime.datetime,
    phone_verification_code_expires_at: datetime.datetime,
    email_verification_code: str,
    email_verification_code_sent_at: datetime.datetime,
    email_verification_code_expires_at: datetime.datetime
):
    """
    Wrapper to register a non-admin user with specified roles and personal details.
    """
    return await create_user_and_register_in_db(
        first_name=first_name,
        last_name=last_name,
        username=username,
        email=email,
        password=password,
        country_code=country_code,
        mobile_number=mobile_number,
        is_admin=False,
        role=role,  # Pass the roles directly
        phone_verification_code=phone_verification_code,
        phone_verification_code_sent_at=phone_verification_code_sent_at,
        phone_verification_code_expires_at=phone_verification_code_expires_at,
        email_verification_code=email_verification_code,
        email_verification_code_sent_at=email_verification_code_sent_at,
        email_verification_code_expires_at=email_verification_code_expires_at
    )


async def is_email_taken(email: str) -> bool:
    prisma_client = await get_prisma_client()
    user = await prisma_client.aq_users.find_first(where={'email': email})
    return user is not None

async def is_username_taken(username: str) -> bool:
    prisma_client = await get_prisma_client()
    user = await prisma_client.aq_users.find_first(where={'username': username})
    return user is not None

async def is_mobile_number_taken(mobile_number: str) -> bool:
    prisma_client = await get_prisma_client()
    user = await prisma_client.aq_users.find_first(where={'mobile_number': mobile_number})
    return user is not None


# Helper Functions for Email Verification
async def get_user_by_email_verification_code(email_verification_code: str) -> dict:
    """
    Retrieve a user by email verification code.
    """
    user = await client.aq_users.find_first(
        where={"email_verification_code": email_verification_code}
    )
    return user

async def update_user_email_verification_code(email: str, email_verification_code: str, email_verification_code_expires_at: datetime.datetime):
    """
    Update the email verification code and expiration time in the database for a user.
    """
    prisma = await get_prisma_client()
    user = await prisma.aq_users.update(
        where={"email": email},
        data={
            "email_verification_code": email_verification_code,
            "email_verification_code_expires_at": email_verification_code_expires_at
        }
    )
    return user


async def get_user_by_email(email: str) -> Optional[dict]:
    """
    Retrieve a user by their email address.
    """
    try:
        prisma = await get_prisma_client()  # Ensure Prisma client is connected

        # Fetch user based on email
        user = await prisma.aq_users.find_first(where={"email": email})
        if not user:
            logging.warning(f"User with email {email} not found.")
        return user
    except Exception as e:
        logging.error(f"Error fetching user by email: {str(e)}")
        return None


async def update_user_password(email: str, hashed_password: str) -> Optional[dict]:
    """
    Update the password for a user identified by their email.
    """
    try:
        prisma = await get_prisma_client()  # Ensure Prisma client is connected

        # Update password in the database
        updated_user = await prisma.aq_users.update(
            where={"email": email},
            data={"password": hashed_password}
        )
        logging.info(f"Password updated for user: {email}")
        return updated_user
    except Exception as e:
        logging.error(f"Error updating user password for {email}: {str(e)}")
        return None
    
async def get_current_user(email: str):
    """
    Fetch the current user based on the provided email.
    """
    try:
        prisma = await get_prisma_client()
        user = await prisma.aq_users.find_first(where={"email": email})
        if not user:
            raise HTTPException(status_code=404, detail="User not found.")
        return user
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error fetching user: {str(e)}")

def create_session_token(data: dict):
    expire = datetime.utcnow() + timedelta(minutes=SESSION_TOKEN_EXPIRE_MINUTES)
    data.update({"exp": expire})
    return jwt.encode(data, SECRET_KEY, algorithm=ALGORITHM)


def create_access_token(data: dict):
    return jwt.encode(data, SECRET_KEY, algorithm=ALGORITHM)


def create_refresh_token(data: dict):
    expire = datetime.utcnow() + timedelta(minutes=REFRESH_TOKEN_EXPIRE_MINUTES)
    return jwt.encode({**data, "exp": expire}, SECRET_KEY, algorithm=ALGORITHM)


def decode_token(token: str):
    try:
        return jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token expired")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Invalid token")


