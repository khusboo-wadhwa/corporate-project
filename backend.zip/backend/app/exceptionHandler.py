# app/exception_handlers.py

from fastapi import HTTPException, Request
from fastapi.responses import JSONResponse
from fastapi.exceptions import RequestValidationError
import logging

# Set up logging (you can configure logging more extensively if needed)
logging.basicConfig(level=logging.INFO)

# Custom exception handler for HTTPExceptions
async def http_exception_handler(request: Request, exc: HTTPException):
    """
    Handles HTTPException and returns a structured JSON response.
    """
    # Log the error details for internal tracking
    logging.error(f"HTTPException: {exc.detail} - {request.url}")
    
    # Return a structured JSON response with error details
    return JSONResponse(
        status_code=exc.status_code,
        content={"detail": exc.detail, "error": str(exc)}
    )


# Custom exception handler for validation errors
async def validation_exception_handler(request: Request, exc: RequestValidationError):
    """
    Handles RequestValidationError (i.e., validation errors from Pydantic models).
    """
    # Log validation error details
    logging.error(f"ValidationError: {exc.errors()} - {request.url}")

    # Return a structured response with validation errors
    return JSONResponse(
        status_code=422,
        content={"detail": exc.errors(), "error": "Validation error"}
    )


# Optional: Handle other custom exceptions as needed
# For example, if you have specific exceptions like DatabaseError, FirebaseError, etc.
