
# # dependencie.py for main1.0py
# from fastapi import Depends, HTTPException, Security
# from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
# from firebase_admin import auth as firebase_auth
# from prisma import Prisma

# # Define HTTP Bearer for authorization
# security = HTTPBearer()

# # Prisma client
# prisma = Prisma()

# # Function to verify and decode Firebase token
# async def get_current_user(
#     credentials: HTTPAuthorizationCredentials = Security(security)
# ):
#     token = credentials.credentials
#     try:
#         decoded_token = firebase_auth.verify_id_token(token)
#         user = await prisma.user.find_unique(where={'email': decoded_token['email']})
#         if not user:
#             raise HTTPException(status_code=404, detail="User not found")
#         return user
#     except Exception:
#         raise HTTPException(status_code=401, detail="Invalid token")
