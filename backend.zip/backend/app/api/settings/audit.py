import json
import logging
from datetime import datetime, timezone
from typing import Any, Optional, Dict

audit_logger = logging.getLogger("settings_audit")
audit_logger.setLevel(logging.INFO)

if not audit_logger.handlers:
    handler = logging.StreamHandler()
    formatter = logging.Formatter(
        "%(asctime)s | AUDIT | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )
    handler.setFormatter(formatter)
    audit_logger.addHandler(handler)
    audit_logger.propagate = False


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


async def log_setting_change(
    db,
    settings_id: Optional[str],
    property_id: Optional[int],
    setting_type: str,
    setting_key: Optional[str],
    old_value: Any,
    new_value: Any,
    changed_by: int = 0,
    change_reason: str = "No reason provided",
    context: Optional[Dict] = None,
):
    context = context or {
        "ip_address": "unknown",
        "user_agent": "unknown",
    }

    audit_entry = {
        "timestamp": utc_now_iso(),
        "entity_type": setting_type,
        "entity_id": settings_id,
        "property_id": property_id,
        "setting_key": setting_key,
        "action": (
            "create"
            if old_value is None
            else "update"
            if new_value is not None
            else "deactivate"
        ),
        "change_reason": change_reason,
        "changed_by": changed_by,
        "ip_address": context.get("ip_address"),
        "user_agent": context.get("user_agent"),
        "old_value": old_value,
        "new_value": new_value,
    }

    audit_logger.info(json.dumps(audit_entry, default=str, indent=2))
