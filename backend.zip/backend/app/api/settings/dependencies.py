from typing import Optional, Dict
from fastapi import Header


def get_request_context(
    x_forwarded_for: Optional[str] = Header(None, alias="X-Forwarded-For"),
    user_agent: Optional[str] = Header(None, alias="User-Agent"),
) -> Dict[str, str]:
    ip = "unknown"
    if x_forwarded_for:
        ip = x_forwarded_for.split(",")[0].strip()
    return {"ip_address": ip, "user_agent": user_agent or "unknown"}
