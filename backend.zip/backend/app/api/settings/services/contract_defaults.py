from typing import Dict
from datetime import datetime
from fastapi import HTTPException
from prisma import Prisma

from ..audit import log_setting_change

async def get_contract_defaults(
    db: Prisma,
    property_id: int,
) -> Dict:
    record = await db.corporate_contract_defaults.find_unique(
        where={"property_id": property_id}
    )

    if not record:
        raise HTTPException(
            status_code=404,
            detail="Contract defaults not found for this property",
        )

    return record.dict()

async def update_contract_defaults(
    db: Prisma,
    payload: Dict,
    context: Dict,
) -> None:
    property_id = payload["property_id"]
    change_reason = payload.get("change_reason")

    existing = await db.corporate_contract_defaults.find_unique(
        where={"property_id": property_id}
    )

    old_value = existing.dict() if existing else None

    update_data = {
        k: v
        for k, v in payload.items()
        if k not in {"property_id", "change_reason"}
    }

    record = await db.corporate_contract_defaults.upsert(
        where={"property_id": property_id},
        update={
            **update_data,
            "updated_by": context["user_id"],
            "updated_date": datetime.utcnow(),
        },
        create={
            "property_id": property_id,
            **update_data,
            "created_by": context["user_id"],
        },
    )

    await log_setting_change(
        db=db,
        settings_id=record.id,
        property_id=property_id,
        setting_type="contract",
        setting_key="contract_defaults",
        old_value=old_value,
        new_value=update_data,
        changed_by=context["user_id"],
        change_reason=change_reason,
        context=context,
    )

async def upload_contract_template(
    db: Prisma,
    property_id: int,
    template_name: str,
    template_type: str,
    notification_event: str,
    variables: list,
    file_content: bytes,
    context: Dict,
) -> None:
    body = file_content.decode("utf-8", errors="ignore")

    template = await db.corporate_notification_template.upsert(
        where={
            "property_id_template_type_notification_event": {
                "property_id": property_id,
                "template_type": template_type,
                "notification_event": notification_event,
            }
        },
        update={
            "template_name": template_name,
            "body": body,
            "variables": variables,
            "updated_by": context["user_id"],
            "updated_date": datetime.utcnow(),
        },
        create={
            "property_id": property_id,
            "template_name": template_name,
            "template_type": template_type,
            "notification_event": notification_event,
            "body": body,
            "variables": variables,
            "created_by": context["user_id"],
        },
    )

    await log_setting_change(
        db=db,
        settings_id=template.id,
        property_id=property_id,
        setting_type="contract",
        setting_key="contract_template",
        old_value=None,
        new_value={"template_name": template_name},
        changed_by=context["user_id"],
        change_reason="Uploaded/updated contract template",
        context=context,
    )

async def get_contract_template(
    db: Prisma,
    property_id: int,
) -> Dict:
    template = await db.corporate_notification_template.find_first(
        where={
            "property_id": property_id,
            "template_type": "contract",
            "is_active": True,
        },
        order={"updated_date": "desc"},
    )

    if not template:
        raise HTTPException(
            status_code=404,
            detail="Contract template not found",
        )

    return template.dict()
