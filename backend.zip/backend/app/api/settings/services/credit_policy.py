from typing import Optional, Dict
from fastapi import HTTPException, status
from prisma import Prisma

from ..audit import log_setting_change
from ..schemas import (
    CreditPolicyResponse,
    CreditPolicyListResponse,
    CreditPolicyCreateRequest,
    CreditPolicyUpdateRequest,
    AppliedPolicyResponse,
)


async def get_credit_policies(
    db: Prisma,
    property_id: int,
    is_active: Optional[bool] = True,
) -> CreditPolicyListResponse:
    """Fetch all credit policies for a property."""
    policies = await db.corporate_credit_policy.find_many(
        where={
            "property_id": property_id,
            "is_active": is_active,
        },
        order={"policy_name": "asc"},
    )
    return CreditPolicyListResponse(
        policies=[CreditPolicyResponse.model_validate(p) for p in policies]
    )


async def create_credit_policy(
    db: Prisma,
    payload: CreditPolicyCreateRequest,
    change_reason: str,
    context: Dict,
) -> CreditPolicyResponse:
    """Create a new credit policy with audit logging."""
    existing = await db.corporate_credit_policy.find_first(
        where={
            "property_id": payload.property_id,
            "policy_name": payload.policy_name,
        }
    )
    if existing:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=f"A credit policy with name '{payload.policy_name}' already exists for property {payload.property_id}",
        )

    new_policy = await db.corporate_credit_policy.create(
        data={**payload.dict(), "is_active": True}
    )

    await log_setting_change(
        db=db,
        settings_id=new_policy.id,
        property_id=payload.property_id,
        setting_type="credit_policy",
        setting_key="corporate_credit_policy",
        old_value=None,
        new_value=payload.dict(),
        changed_by=0,
        change_reason=change_reason,
        context=context,
    )

    return CreditPolicyResponse.model_validate(new_policy)


async def update_credit_policy(
    db: Prisma,
    policy_id: str,
    payload: CreditPolicyUpdateRequest,
    change_reason: str,
    context: Dict,
) -> CreditPolicyResponse:
    """Update an existing credit policy with audit logging."""
    existing = await db.corporate_credit_policy.find_unique(where={"id": policy_id})
    if not existing:
        raise HTTPException(status_code=404, detail="Credit policy not found")
    if not existing.is_active:
        raise HTTPException(status_code=410, detail="Cannot update deactivated policy")

    update_data = payload.dict(exclude_unset=True, exclude={"change_reason"})
    old_values = {k: getattr(existing, k) for k in update_data.keys()}

    updated = await db.corporate_credit_policy.update(
        where={"id": policy_id},
        data=update_data,
    )

    await log_setting_change(
        db=db,
        settings_id=policy_id,
        property_id=existing.property_id,
        setting_type="credit_policy",
        setting_key="corporate_credit_policy",
        old_value=old_values,
        new_value=update_data,
        changed_by=0,
        change_reason=change_reason,
        context=context,
    )

    return CreditPolicyResponse.model_validate(updated)


async def deactivate_credit_policy(
    db: Prisma,
    policy_id: str,
    deactivation_reason: str,
    context: Dict,
) -> None:
    """Soft-deactivate a credit policy with audit logging."""
    existing = await db.corporate_credit_policy.find_unique(where={"id": policy_id})
    if not existing:
        raise HTTPException(status_code=404, detail="Credit policy not found")
    if not existing.is_active:
        raise HTTPException(status_code=410, detail="Policy already deactivated")

    await db.corporate_credit_policy.update(
        where={"id": policy_id},
        data={"is_active": False},
    )

    await log_setting_change(
        db=db,
        settings_id=policy_id,
        property_id=existing.property_id,
        setting_type="credit_policy",
        setting_key="corporate_credit_policy",
        old_value={"is_active": True},
        new_value={"is_active": False},
        changed_by=0,
        change_reason=f"Deactivated: {deactivation_reason}",
        context=context,
    )


async def get_applied_credit_policy(
    db: Prisma,
    company_id: int,
    property_id: int,
) -> AppliedPolicyResponse:
    """Determine and return the applied credit policy for a company (simulated logic)."""
    active_policies = await db.corporate_credit_policy.find_many(
        where={"property_id": property_id, "is_active": True}
    )
    if not active_policies:
        raise HTTPException(
            status_code=404,
            detail="No active credit policies found for this property",
        )

    applied = active_policies[0]
    eligibility = {
        "is_eligible": True,
        "reasons": [],
        "recommended_limit": applied.default_credit_limit,
    }

    return AppliedPolicyResponse(
        applied_policy=CreditPolicyResponse.model_validate(applied),
        eligibility=eligibility,
    )
