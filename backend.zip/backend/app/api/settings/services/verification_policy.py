from typing import Dict
from fastapi import HTTPException, status
from prisma import Prisma

from ..audit import log_setting_change
from ..schemas import (
    VerificationPolicyResponse,
    VerificationPolicyCreateRequest,
    VerificationPolicyUpdateRequest,
    VerificationPolicyTestRequest,
    VerificationPolicyTestResponse,
)


async def get_verification_policy(
    db: Prisma, property_id: int
) -> VerificationPolicyResponse:
    policy = await db.corporate_verification_policy.find_unique(
        where={"property_id": property_id}
    )
    if not policy:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Verification policy not found for this property",
        )
    if not policy.is_active:
        raise HTTPException(
            status_code=status.HTTP_410_GONE,
            detail="This verification policy is no longer active",
        )

    return VerificationPolicyResponse.model_validate(policy)


async def create_verification_policy(
    db: Prisma,
    payload: VerificationPolicyCreateRequest,
    context: Dict,
) -> VerificationPolicyResponse:
    existing = await db.corporate_verification_policy.find_unique(
        where={"property_id": payload.property_id}
    )
    if existing:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Verification policy already exists for this property. Use PUT to update.",
        )

    new_policy = await db.corporate_verification_policy.create(
        data={
            "property_id": payload.property_id,
            "require_phone_verification": payload.require_phone_verification,
            "require_company_id_verification": payload.require_company_id_verification,
            "require_address_verification": payload.require_address_verification,
            "require_bank_verification": payload.require_bank_verification,
            "auto_mark_verified": payload.auto_mark_verified,
            "verification_expiry_months": payload.verification_expiry_months,
            "reminder_days_before_expiry": payload.reminder_days_before_expiry,
            "is_active": True,
        }
    )

    await log_setting_change(
        db=db,
        settings_id=new_policy.id,
        property_id=payload.property_id,
        setting_type="verification_policy",
        setting_key="corporate_verification_policy",
        old_value=None,
        new_value=payload.dict(exclude={"property_id", "change_reason"}),
        changed_by=0,
        change_reason=payload.change_reason,
        context=context,
    )

    return VerificationPolicyResponse.model_validate(new_policy)


async def update_verification_policy(
    db: Prisma,
    payload: VerificationPolicyUpdateRequest,
    change_reason: str,
    context: Dict,
) -> VerificationPolicyResponse:
    existing = await db.corporate_verification_policy.find_unique(
        where={"property_id": payload.property_id}
    )
    if not existing:
        raise HTTPException(status_code=404, detail="Verification policy not found")
    if not existing.is_active:
        raise HTTPException(status_code=410, detail="Cannot update inactive policy")

    update_data = payload.dict(
        exclude_unset=True, exclude={"property_id", "change_reason"}
    )
    old_values = {k: getattr(existing, k) for k in update_data.keys()}

    updated_policy = await db.corporate_verification_policy.update(
        where={"property_id": payload.property_id},
        data=update_data,
    )

    await log_setting_change(
        db=db,
        settings_id=existing.id,
        property_id=payload.property_id,
        setting_type="verification_policy",
        setting_key="corporate_verification_policy",
        old_value=old_values,
        new_value=update_data,
        changed_by=0,
        change_reason=change_reason,
        context=context,
    )

    return VerificationPolicyResponse.model_validate(updated_policy)


async def test_verification_policy(
    db: Prisma,
    payload: VerificationPolicyTestRequest,
) -> VerificationPolicyTestResponse:
    policy = await db.corporate_verification_policy.find_unique(
        where={"property_id": payload.property_id}
    )
    if not policy or not policy.is_active:
        raise HTTPException(
            status_code=404, detail="Active verification policy not found"
        )

    test_data = payload.test_data
    missing = []

    if policy.require_phone_verification and not test_data.get("phone_verified"):
        missing.append("phone_verification")
    if policy.require_company_id_verification and not test_data.get(
        "company_id_verified"
    ):
        missing.append("company_id_verification")
    if policy.require_address_verification and not test_data.get("address_verified"):
        missing.append("address_verification")
    if policy.require_bank_verification and not test_data.get("bank_verified"):
        missing.append("bank_verification")

    is_verified = len(missing) == 0 or policy.auto_mark_verified

    message = "Passes all required verifications"
    if missing and not policy.auto_mark_verified:
        message = f"Missing required verifications: {', '.join(missing)}"
    elif missing and policy.auto_mark_verified:
        message = f"Missing: {', '.join(missing)} — but auto_mark_verified is enabled"

    return VerificationPolicyTestResponse(
        is_verified=is_verified,
        missing_requirements=missing,
        message=message,
    )
