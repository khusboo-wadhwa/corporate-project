from typing import Optional, List
from prisma import Prisma

from ..audit import log_setting_change
from ..schemas import (
    ClearCacheRequest,
    DiagnosticsResponse,
    DiagnosticIssue,
    DiagnosticsFullResponse,
    ReloadSettingsRequest,
)


async def clear_cache(db: Prisma, payload: ClearCacheRequest) -> dict:
    """Clear system cache for specified types or all"""
    types_to_clear = payload.cache_types
    if payload.clear_all:
        types_to_clear = ["all"]

    await log_setting_change(
        db=db,
        settings_id="cache_clear",
        property_id=payload.property_id,
        setting_type="cache_management",
        setting_key="clear_cache",
        old_value=None,
        new_value={
            "cache_types": types_to_clear,
            "clear_all": payload.clear_all,
        },
        changed_by=0,
        change_reason=payload.clear_reason,
        context={"ip_address": "unknown", "user_agent": "unknown"},
    )

    return {
        "property_id": payload.property_id,
        "cleared_types": types_to_clear,
        "status": "completed",
    }


async def run_diagnostics(
    property_id: int, test_components: Optional[List[str]] = None
) -> DiagnosticsFullResponse:
    """Run system diagnostics and return a report"""
    diagnostics = DiagnosticsResponse(
        database={
            "connected": True,
            "response_time": "45ms",
            "status": "healthy",
        },
        cache={
            "connected": True,
            "hit_rate": "92%",
            "status": "healthy",
        },
        storage={
            "available_space": "500GB",
            "status": "healthy",
        },
    )

    issues = [
        DiagnosticIssue(
            component="notification_service",
            severity="warning",
            message="Email service latency above threshold",
            recommendation="Check SMTP configuration and network connectivity",
        ),
        DiagnosticIssue(
            component="backup_service",
            severity="info",
            message="Last backup completed 2 hours ago",
            recommendation="Next scheduled backup in 22 hours",
        ),
    ]

    summary = "System is healthy with minor warnings. No critical issues detected."

    return DiagnosticsFullResponse(
        diagnostics=diagnostics, issues=issues, summary=summary
    )


async def reload_settings(db: Prisma, payload: ReloadSettingsRequest) -> dict:
    """Reload settings into application memory"""
    types_to_reload = payload.setting_types
    if "all" in types_to_reload:
        types_to_reload = [
            "verification",
            "credit",
            "security",
            "system",
            "notification",
            "contract",
        ]

    await log_setting_change(
        db=db,
        settings_id="settings_reload",
        property_id=payload.property_id,
        setting_type="settings_management",
        setting_key="reload",
        old_value=None,
        new_value={"setting_types": types_to_reload},
        changed_by=0,
        change_reason=payload.reload_reason,
        context={"ip_address": "unknown", "user_agent": "unknown"},
    )

    return {
        "property_id": payload.property_id,
        "reloaded_types": types_to_reload,
        "status": "completed",
    }
