from typing import Optional, Dict
from fastapi import HTTPException
from prisma import Prisma

from ..audit import log_setting_change
from ..schemas import (
    NotificationTemplateResponse,
    NotificationTemplateListResponse,
    NotificationTemplateCreateRequest,
    NotificationTemplateUpdateRequest,
    NotificationPreferencesResponse,
    NotificationPreferencesUpdateRequest,
    NotificationTestRequest,
)


async def get_templates(
    db: Prisma,
    property_id: int,
    template_type: Optional[str] = None,
    is_active: Optional[bool] = True,
) -> NotificationTemplateListResponse:
    where_clause = {"property_id": property_id, "is_active": is_active}
    if template_type:
        where_clause["template_type"] = template_type

    templates = await db.corporate_notification_template.find_many(
        where=where_clause,
        order={"template_name": "asc"},
    )
    return NotificationTemplateListResponse(
        templates=[NotificationTemplateResponse.model_validate(t) for t in templates]
    )


async def get_specific_template(
    db: Prisma,
    property_id: int,
    template_type: str,
    notification_event: str,
) -> NotificationTemplateResponse:
    template = await db.corporate_notification_template.find_first(
        where={
            "property_id": property_id,
            "template_type": template_type,
            "notification_event": notification_event,
            "is_active": True,
        }
    )
    if not template:
        raise HTTPException(
            status_code=404,
            detail=f"Template not found for type '{template_type}' and event '{notification_event}'",
        )
    return NotificationTemplateResponse.model_validate(template)


async def create_template(
    db: Prisma,
    payload: NotificationTemplateCreateRequest,
    context: Dict,
) -> NotificationTemplateResponse:
    existing = await db.corporate_notification_template.find_first(
        where={
            "property_id": payload.property_id,
            "template_type": payload.template_type,
            "notification_event": payload.notification_event,
        }
    )
    if existing:
        raise HTTPException(
            status_code=409,
            detail="Template with this type and event already exists",
        )

    new_template = await db.corporate_notification_template.create(
        data={**payload.dict(), "is_active": True}
    )

    await log_setting_change(
        db=db,
        settings_id=new_template.id,
        property_id=payload.property_id,
        setting_type="notification_template",
        setting_key="corporate_notification_template",
        old_value=None,
        new_value=payload.dict(),
        changed_by=0,
        change_reason="New notification template created",
        context=context,
    )

    return NotificationTemplateResponse.model_validate(new_template)


async def update_template(
    db: Prisma,
    template_id: str,
    payload: NotificationTemplateUpdateRequest,
    change_reason: str,
    context: Dict,
) -> NotificationTemplateResponse:
    existing = await db.corporate_notification_template.find_unique(
        where={"id": template_id}
    )
    if not existing:
        raise HTTPException(status_code=404, detail="Notification template not found")
    if not existing.is_active:
        raise HTTPException(status_code=410, detail="Cannot update inactive template")

    update_data = payload.dict(exclude_unset=True, exclude={"change_reason"})
    old_values = {k: getattr(existing, k) for k in update_data.keys()}

    updated = await db.corporate_notification_template.update(
        where={"id": template_id},
        data=update_data,
    )

    await log_setting_change(
        db=db,
        settings_id=template_id,
        property_id=existing.property_id,
        setting_type="notification_template",
        setting_key="corporate_notification_template",
        old_value=old_values,
        new_value=update_data,
        changed_by=0,
        change_reason=change_reason,
        context=context,
    )

    return NotificationTemplateResponse.model_validate(updated)


async def get_preferences(property_id: int) -> NotificationPreferencesResponse:
    preferences = {
        "credit_approval": {"email": True, "sms": False, "system": True},
        "contract_expiry": {"email": True, "sms": True, "system": True},
        "invoice_due": {"email": True, "sms": False, "system": True},
    }
    recipients = {
        "admins": ["admin@property.com"],
        "managers": ["manager@property.com"],
        "finance": ["finance@property.com"],
    }
    return NotificationPreferencesResponse(
        preferences=preferences, recipients=recipients
    )


async def update_preferences(
    db: Prisma,
    payload: NotificationPreferencesUpdateRequest,
    context: Dict,
) -> None:
    await log_setting_change(
        db=db,
        settings_id="preferences",
        property_id=payload.property_id,
        setting_type="notification_preferences",
        setting_key="corporate_notification_preferences",
        old_value={"note": "previous preferences not tracked"},
        new_value={"preferences": payload.preferences},
        changed_by=0,
        change_reason=payload.change_reason,
        context=context,
    )


async def test_template(
    db: Prisma,
    template_id: str,
    payload: NotificationTestRequest,
) -> Dict:
    template = await db.corporate_notification_template.find_unique(
        where={"id": template_id}
    )
    if not template:
        raise HTTPException(status_code=404, detail="Template not found")
    if not template.is_active:
        raise HTTPException(status_code=410, detail="Template is inactive")

    rendered_subject = template.subject or ""
    rendered_body = template.body

    for var, val in payload.test_data.items():
        placeholder = f"{{{{{var}}}}}"
        if rendered_subject:
            rendered_subject = rendered_subject.replace(placeholder, str(val))
        rendered_body = rendered_body.replace(placeholder, str(val))

    return {
        "template_id": template_id,
        "rendered_subject": rendered_subject,
        "rendered_body": rendered_body,
        "test_email": payload.test_email,
        "test_phone": payload.test_phone,
        "message": "Test notification would be sent with the above content",
    }
