from typing import Optional, Dict
from datetime import datetime, timedelta
import json
from fastapi import HTTPException
from prisma import Prisma
from collections import defaultdict

from ..audit import log_setting_change
from ..schemas import (
    ExportSettingsRequest,
    ResetSettingsRequest,
    ValidateSettingsRequest,
    DefaultSetting,
    DefaultsResponse,
)

async def export_settings(
    db: Prisma,
    payload: ExportSettingsRequest,
    context: Dict,
) -> Dict:
    """Gather and return settings data for export (currently JSON only)."""
    export_data = {
        "exported_at": datetime.utcnow().isoformat() + "Z",
        "property_id": payload.property_id,
        "format": payload.format,
        "included_types": payload.include_types,
        "settings": {},
    }

    if "verification" in payload.include_types:
        policy = await db.corporate_verification_policy.find_unique(
            where={"property_id": payload.property_id}
        )
        if policy:
            export_data["settings"]["verification"] = {
                "require_phone_verification": policy.require_phone_verification,
                "require_company_id_verification": policy.require_company_id_verification,
                "require_address_verification": policy.require_address_verification,
                "require_bank_verification": policy.require_bank_verification,
                "auto_mark_verified": policy.auto_mark_verified,
                "verification_expiry_months": policy.verification_expiry_months,
                "reminder_days_before_expiry": policy.reminder_days_before_expiry,
            }

    if "credit" in payload.include_types:
        policies = await db.corporate_credit_policy.find_many(
            where={"property_id": payload.property_id, "is_active": True}
        )
        export_data["settings"]["credit"] = [
            {
                "policy_name": p.policy_name,
                "min_credit_limit": float(p.min_credit_limit),
                "max_credit_limit": float(p.max_credit_limit),
                "default_credit_limit": float(p.default_credit_limit),
                "credit_terms": p.credit_terms,
                "risk_level": p.risk_level,
            }
            for p in policies
        ]

    if "security" in payload.include_types:
        sec = await db.corporate_security_settings.find_unique(
            where={"property_id": payload.property_id}
        )
        if sec:
            export_data["settings"]["security"] = {
                "session_timeout_minutes": sec.session_timeout_minutes,
                "two_factor_auth": sec.two_factor_auth,
                "ip_whitelisting": sec.ip_whitelisting,
                "max_login_attempts": sec.max_login_attempts,
                "password_expiry_days": sec.password_expiry_days,
            }

    if "system" in payload.include_types:
        sys = await db.corporate_system_settings.find_unique(
            where={"property_id": payload.property_id}
        )
        if sys:
            export_data["settings"]["system"] = {
                "auto_backup": sys.auto_backup,
                "backup_frequency": sys.backup_frequency,
                "data_retention_years": sys.data_retention_years,
                "maintenance_mode": sys.maintenance_mode,
            }

    if payload.include_audit_logs:
        export_data["audit_logs"] = [
            {
                "timestamp": "2025-12-22T10:00:00Z",
                "action": "update",
                "type": "credit_policy",
                "reason": "Updated limits",
            }
        ]

    await log_setting_change(
        db=db,
        settings_id="export",
        property_id=payload.property_id,
        setting_type="settings_export",
        setting_key="export_action",
        old_value=None,
        new_value={"format": payload.format, "types": payload.include_types},
        changed_by=0,
        change_reason=f"Exported settings in {payload.format}",
        context=context,
    )

    return export_data


async def import_settings(
    db: Prisma,
    property_id: int,
    file_content: bytes,
    overwrite_existing: bool,
    dry_run: bool,
    import_password: Optional[str],
    context: Dict,
) -> Dict:
    """Validate/process imported JSON file and log the action."""
    try:
        data = json.loads(file_content)
    except json.JSONDecodeError:
        raise HTTPException(status_code=400, detail="Invalid JSON file")

    result = {
        "dry_run": dry_run,
        "property_id": property_id,
        "imported_types": list(data.get("settings", {}).keys()),
        "validation": "passed" if dry_run else "applied",
        "warnings": [],
        "errors": [],
    }

    await log_setting_change(
        db=db,
        settings_id="import",
        property_id=property_id,
        setting_type="settings_import",
        setting_key="import_action",
        old_value=None,
        new_value={
            "dry_run": dry_run,
            "overwrite": overwrite_existing,
            "file_size": len(file_content),
        },
        changed_by=0,
        change_reason="Imported settings from file",
        context=context,
    )

    return result


async def reset_settings_type(
    db: Prisma,
    setting_type: str,
    payload: ResetSettingsRequest,
    context: Dict,
) -> None:
    valid_types = ["verification", "credit", "security", "system"]
    if setting_type not in valid_types:
        raise HTTPException(
            status_code=400, detail=f"Invalid type. Must be one of: {valid_types}"
        )

    await log_setting_change(
        db=db,
        settings_id=f"reset_{setting_type}",
        property_id=payload.property_id,
        setting_type="settings_reset",
        setting_key=setting_type,
        old_value={"note": "previous values"},
        new_value={"note": "reset to defaults"},
        changed_by=0,
        change_reason=payload.reset_reason,
        context=context,
    )


async def get_default_settings(setting_type: str) -> DefaultsResponse:
    defaults_map = {
        "verification": [
            DefaultSetting(
                setting_key="require_phone_verification",
                default_value=True,
                description="Require phone verification",
                type="bool",
            ),
            DefaultSetting(
                setting_key="verification_expiry_months",
                default_value=12,
                description="Months until re-verification needed",
                type="int",
            ),
            DefaultSetting(
                setting_key="auto_mark_verified",
                default_value=True,
                description="Auto-mark as verified if all checks pass",
                type="bool",
            ),
        ],
        "credit": [
            DefaultSetting(
                setting_key="min_credit_limit",
                default_value=1000.00,
                description="Minimum allowable credit limit",
                type="decimal",
            ),
            DefaultSetting(
                setting_key="default_credit_limit",
                default_value=10000.00,
                description="Default credit limit for new accounts",
                type="decimal",
            ),
            DefaultSetting(
                setting_key="risk_level",
                default_value="medium",
                description="Default risk category",
                type="string",
            ),
        ],
        "security": [
            DefaultSetting(
                setting_key="session_timeout_minutes",
                default_value=30,
                description="Inactive session timeout",
                type="int",
            ),
            DefaultSetting(
                setting_key="max_login_attempts",
                default_value=5,
                description="Lock account after failed attempts",
                type="int",
            ),
            DefaultSetting(
                setting_key="password_expiry_days",
                default_value=90,
                description="Force password change every N days",
                type="int",
            ),
        ],
        "system": [
            DefaultSetting(
                setting_key="auto_backup",
                default_value=True,
                description="Enable automatic backups",
                type="bool",
            ),
            DefaultSetting(
                setting_key="backup_frequency",
                default_value="daily",
                description="How often to backup",
                type="string",
            ),
            DefaultSetting(
                setting_key="data_retention_years",
                default_value=5,
                description="Retain data for N years",
                type="int",
            ),
        ],
    }

    if setting_type not in defaults_map:
        raise HTTPException(
            status_code=404, detail="Default settings not found for this type"
        )

    return DefaultsResponse(defaults=defaults_map[setting_type])


async def validate_settings(payload: ValidateSettingsRequest) -> Dict:
    validation_result = {
        "valid": True,
        "compliance_check": "passed" if payload.validate_compliance else "skipped",
        "business_rules_check": "passed"
        if payload.validate_business_rules
        else "skipped",
        "issues": [],
        "warnings": [],
    }

    if "credit" in payload.settings:
        credit = payload.settings["credit"]
        if credit.get("max_credit_limit", 0) > 1000000:
            validation_result["warnings"].append(
                "Very high credit limit may require approval"
            )

    return validation_result




# NEW ADDED APIs (KHUSHBOO)
async def get_all_corporate_settings(
    db: Prisma,
    property_id: Optional[int],
) -> Dict:
    where_clause = {"is_active": True}

    if property_id is not None:
        where_clause["property_id"] = property_id

    settings = await db.corporate_settings.find_many(
        where=where_clause,
        order=[
            {"setting_type": "asc"},
            {"setting_key": "asc"},
        ],
    )

    grouped: Dict[str, Dict[str, list]] = defaultdict(lambda: {"settings": []})

    for s in settings:
        grouped[s.setting_type]["settings"].append(
            {
                "id": s.id,
                "setting_key": s.setting_key,
                "setting_value": s.setting_value,
                "setting_group": s.setting_group,
                "is_active": s.is_active,
            }
        )

    return dict(grouped)

async def get_settings_by_type(
    db: Prisma,
    setting_type: str,
    property_id: int,
) -> Dict:
    settings = await db.corporate_settings.find_many(
        where={
            "property_id": property_id,
            "setting_type": setting_type,
            "is_active": True,
        },
        order={"setting_key": "asc"},
    )

    return {
        "settings": [
            {
                "id": s.id,
                "setting_key": s.setting_key,
                "setting_value": s.setting_value,
                "setting_group": s.setting_group,
                "is_active": s.is_active,
            }
            for s in settings
        ]
    }

async def update_settings_by_type(
    db: Prisma,
    setting_type: str,
    payload: Dict,
    context: Dict,
) -> None:
    property_id = payload["property_id"]
    updates = payload["updates"]
    change_reason = payload.get("change_reason")

    for u in updates:
        existing = await db.corporate_settings.find_unique(
            where={
                "property_id_setting_type_setting_key": {
                    "property_id": property_id,
                    "setting_type": setting_type,
                    "setting_key": u["setting_key"],
                }
            }
        )

        old_value = existing.setting_value if existing else None

        record = await db.corporate_settings.upsert(
            where={
                "property_id_setting_type_setting_key": {
                    "property_id": property_id,
                    "setting_type": setting_type,
                    "setting_key": u["setting_key"],
                }
            },
            update={
                "setting_value": u["setting_value"],
                "setting_group": u.get("setting_group"),
                "updated_by": context["user_id"],
                "updated_date": datetime.utcnow(),
            },
            create={
                "property_id": property_id,
                "setting_type": setting_type,
                "setting_key": u["setting_key"],
                "setting_value": u["setting_value"],
                "setting_group": u.get("setting_group"),
                "created_by": context["user_id"],
            },
        )

        await log_setting_change(
            db=db,
            settings_id=record.id,
            property_id=property_id,
            setting_type=setting_type,
            setting_key=u["setting_key"],
            old_value=old_value,
            new_value=u["setting_value"],
            changed_by=context["user_id"],
            change_reason=change_reason,
            context=context,
        )

async def bulk_update_corporate_settings(
    db: Prisma,
    payload: Dict,
    context: Dict,
) -> None:
    property_id = payload["property_id"]
    updates = payload["updates"]
    change_reason = payload.get("change_reason")

    for u in updates:
        existing = await db.corporate_settings.find_unique(
            where={
                "property_id_setting_type_setting_key": {
                    "property_id": property_id,
                    "setting_type": u["setting_type"],
                    "setting_key": u["setting_key"],
                }
            }
        )

        old_value = existing.setting_value if existing else None

        record = await db.corporate_settings.upsert(
            where={
                "property_id_setting_type_setting_key": {
                    "property_id": property_id,
                    "setting_type": u["setting_type"],
                    "setting_key": u["setting_key"],
                }
            },
            update={
                "setting_value": u["setting_value"],
                "updated_by": context["user_id"],
                "updated_date": datetime.utcnow(),
            },
            create={
                "property_id": property_id,
                "setting_type": u["setting_type"],
                "setting_key": u["setting_key"],
                "setting_value": u["setting_value"],
                "created_by": context["user_id"],
            },
        )

        await log_setting_change(
            db=db,
            settings_id=record.id,
            property_id=property_id,
            setting_type=u["setting_type"],
            setting_key=u["setting_key"],
            old_value=old_value,
            new_value=u["setting_value"],
            changed_by=context["user_id"],
            change_reason=change_reason,
            context=context,
        )

async def get_settings_audit_history(
    db: Prisma,
    settings_id: str,
    days: int = 30,
) -> Dict:
    since = datetime.utcnow() - timedelta(days=days)

    logs = await db.corporate_settings_audit.find_many(
        where={
            "settings_id": settings_id,
            "created_date": {"gte": since},
        },
        order={"created_date": "desc"},
    )

    return {
        "audit_logs": [
            {
                "id": l.id,
                "old_value": l.old_value,
                "new_value": l.new_value,
                "changed_by": l.changed_by,
                "change_reason": l.change_reason,
                "created_date": l.created_date,
            }
            for l in logs
        ]
    }