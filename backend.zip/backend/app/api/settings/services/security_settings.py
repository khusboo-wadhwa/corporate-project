from typing import Optional, Dict
from datetime import date
from fastapi import HTTPException
from prisma import Prisma

from ..audit import log_setting_change
from ..schemas import (
    SecuritySettingsResponse,
    SecuritySettingsCreateRequest,
    SecuritySettingsUpdateRequest,
    IPWhitelistAddRequest,
    IPWhitelistRemoveRequest,
    AuditLogsResponse,
)


async def get_security_settings(
    db: Prisma,
    property_id: int,
) -> SecuritySettingsResponse:
    settings = await db.corporate_security_settings.find_unique(
        where={"property_id": property_id}
    )
    if not settings:
        raise HTTPException(
            status_code=404, detail="Security settings not found for this property"
        )
    if not settings.is_active:
        raise HTTPException(status_code=410, detail="Security settings are inactive")

    return SecuritySettingsResponse.model_validate(settings)


async def create_security_settings(
    db: Prisma,
    payload: SecuritySettingsCreateRequest,
    context: Dict[str, str],
) -> SecuritySettingsResponse:
    existing = await db.corporate_security_settings.find_unique(
        where={"property_id": payload.property_id}
    )
    if existing:
        raise HTTPException(
            status_code=409,
            detail="Security settings already exist for this property. Use PUT to update.",
        )

    new_settings = await db.corporate_security_settings.create(
        data={
            "property_id": payload.property_id,
            "session_timeout_minutes": payload.session_timeout_minutes,
            "two_factor_auth": payload.two_factor_auth,
            "ip_whitelisting": payload.ip_whitelisting,
            "audit_log_retention_days": payload.audit_log_retention_days,
            "max_login_attempts": payload.max_login_attempts,
            "password_expiry_days": payload.password_expiry_days,
            "api_access_enabled": payload.api_access_enabled,
            "data_encryption": payload.data_encryption,
            "is_active": True,
        }
    )

    await log_setting_change(
        db=db,
        settings_id=new_settings.id,
        property_id=payload.property_id,
        setting_type="security_settings",
        setting_key="corporate_security_settings",
        old_value=None,
        new_value=payload.dict(exclude={"property_id", "change_reason"}),
        changed_by=0,
        change_reason=payload.change_reason,
        context=context,
    )

    return SecuritySettingsResponse.model_validate(new_settings)


async def update_security_settings(
    db: Prisma,
    payload: SecuritySettingsUpdateRequest,
    context: Dict[str, str],
) -> SecuritySettingsResponse:
    existing = await db.corporate_security_settings.find_unique(
        where={"property_id": payload.property_id}
    )
    if not existing:
        raise HTTPException(status_code=404, detail="Security settings not found")
    if not existing.is_active:
        raise HTTPException(status_code=410, detail="Cannot update inactive settings")

    update_data = payload.dict(
        exclude_unset=True, exclude={"property_id", "change_reason"}
    )
    old_values = {k: getattr(existing, k) for k in update_data.keys()}

    updated = await db.corporate_security_settings.update(
        where={"property_id": payload.property_id},
        data=update_data,
    )

    await log_setting_change(
        db=db,
        settings_id=existing.id,
        property_id=payload.property_id,
        setting_type="security_settings",
        setting_key="corporate_security_settings",
        old_value=old_values,
        new_value=update_data,
        changed_by=0,
        change_reason=payload.change_reason,
        context=context,
    )

    return SecuritySettingsResponse.model_validate(updated)


async def add_ip_whitelist(
    db: Prisma,
    payload: IPWhitelistAddRequest,
    context: Dict[str, str],
) -> Dict:
    await log_setting_change(
        db=db,
        settings_id="ip_whitelist",
        property_id=payload.property_id,
        setting_type="ip_whitelist",
        setting_key="add_ips",
        old_value=None,
        new_value={
            "ip_addresses": payload.ip_addresses,
            "description": payload.description,
        },
        changed_by=0,
        change_reason=payload.change_reason,
        context=context,
    )
    return {"added_ips": payload.ip_addresses}


async def remove_ip_whitelist(
    db: Prisma,
    payload: IPWhitelistRemoveRequest,
    ip: str,
    property_id: int,
    change_reason: str,
    context: Dict[str, str],
) -> None:
    await log_setting_change(
        db=db,
        settings_id="ip_whitelist",
        property_id=property_id,
        setting_type="ip_whitelist",
        setting_key="remove_ip",
        old_value={"ip": ip},
        new_value=None,
        changed_by=0,
        change_reason=change_reason,
        context=context,
    )


async def get_security_audit_logs(
    property_id: int,
    start_date: Optional[date] = None,
    end_date: Optional[date] = None,
    user_id: Optional[int] = None,
    event_type: Optional[str] = None,
) -> AuditLogsResponse:
    mock_logs = [
        {
            "id": "log-001",
            "user_id": 123,
            "user_name": "John Doe",
            "event_type": "login_success",
            "ip_address": "192.168.1.100",
            "details": "Successful login from office",
            "created_date": "2025-12-22T10:30:00Z",
        },
        {
            "id": "log-002",
            "user_id": 456,
            "user_name": "Jane Smith",
            "event_type": "failed_login",
            "ip_address": "203.0.113.50",
            "details": "Failed login attempt (wrong password)",
            "created_date": "2025-12-22T11:15:00Z",
        },
    ]
    summary = {"total_logs": 150, "failed_logins": 5, "suspicious_activities": 2}
    return AuditLogsResponse(logs=mock_logs, summary=summary)
