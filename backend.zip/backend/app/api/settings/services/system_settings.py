from typing import Optional, Dict
from fastapi import HTTPException
from prisma import Prisma

from ..audit import log_setting_change
from ..schemas import (
    SystemSettingsResponse,
    SystemSettingsCreateRequest,
    SystemSettingsUpdateRequest,
    ManualBackupRequest,
    MaintenanceModeRequest,
    SystemStatusResponse,
)


async def get_system_settings(db: Prisma, property_id: int) -> SystemSettingsResponse:
    settings = await db.corporate_system_settings.find_unique(
        where={"property_id": property_id}
    )
    if not settings:
        raise HTTPException(
            status_code=404, detail="System settings not found for this property"
        )
    if not settings.is_active:
        raise HTTPException(status_code=410, detail="System settings are inactive")

    return SystemSettingsResponse.model_validate(settings)


async def create_system_settings(
    db: Prisma,
    payload: SystemSettingsCreateRequest,
    context: Dict[str, str],
) -> SystemSettingsResponse:
    existing = await db.corporate_system_settings.find_unique(
        where={"property_id": payload.property_id}
    )
    if existing:
        raise HTTPException(
            status_code=409,
            detail="System settings already exist for this property. Use PUT to update.",
        )

    new_settings = await db.corporate_system_settings.create(
        data={
            "property_id": payload.property_id,
            "auto_backup": payload.auto_backup,
            "backup_frequency": payload.backup_frequency,
            "audit_trail_enabled": payload.audit_trail_enabled,
            "data_retention_years": payload.data_retention_years,
            "performance_metrics": payload.performance_metrics,
            "auto_updates_enabled": payload.auto_updates_enabled,
            "maintenance_mode": payload.maintenance_mode,
            "current_version": payload.current_version,
            "is_active": True,
        }
    )

    await log_setting_change(
        db=db,
        settings_id=new_settings.id,
        property_id=payload.property_id,
        setting_type="system_settings",
        setting_key="corporate_system_settings",
        old_value=None,
        new_value=payload.dict(exclude={"property_id", "change_reason"}),
        changed_by=0,
        change_reason=payload.change_reason,
        context=context,
    )

    return SystemSettingsResponse.model_validate(new_settings)


async def update_system_settings(
    db: Prisma,
    payload: SystemSettingsUpdateRequest,
    context: Dict[str, str],
) -> None:
    existing = await db.corporate_system_settings.find_unique(
        where={"property_id": payload.property_id}
    )
    if not existing:
        raise HTTPException(status_code=404, detail="System settings not found")
    if not existing.is_active:
        raise HTTPException(status_code=410, detail="Cannot update inactive settings")

    update_data = payload.dict(
        exclude_unset=True, exclude={"property_id", "change_reason"}
    )
    old_values = {k: getattr(existing, k) for k in update_data.keys()}

    await db.corporate_system_settings.update(
        where={"property_id": payload.property_id},
        data=update_data,
    )

    await log_setting_change(
        db=db,
        settings_id=existing.id,
        property_id=payload.property_id,
        setting_type="system_settings",
        setting_key="corporate_system_settings",
        old_value=old_values,
        new_value=update_data,
        changed_by=0,
        change_reason=payload.change_reason,
        context=context,
    )


async def trigger_manual_backup(
    db: Prisma,
    payload: ManualBackupRequest,
    context: Dict[str, str],
) -> None:
    await log_setting_change(
        db=db,
        settings_id="manual_backup",
        property_id=payload.property_id,
        setting_type="system_backup",
        setting_key="manual_trigger",
        old_value=None,
        new_value={
            "backup_type": payload.backup_type,
            "description": payload.description,
        },
        changed_by=0,
        change_reason=f"Manual {payload.backup_type} backup triggered",
        context=context,
    )


async def get_system_status(property_id: int) -> SystemStatusResponse:
    return SystemStatusResponse(
        system_status="healthy",
        database={"status": "connected", "latency": "32ms"},
        cache={"status": "connected", "hit_rate": "94%"},
        storage={"used": "68%", "available": "32%"},
        last_backup="2025-12-22T02:00:00Z",
        uptime="99.9%",
    )


async def set_maintenance_mode(
    db: Prisma,
    payload: MaintenanceModeRequest,
    context: Dict[str, str],
) -> Dict:
    existing = await db.corporate_system_settings.find_unique(
        where={"property_id": payload.property_id}
    )
    if not existing:
        raise HTTPException(status_code=404, detail="System settings not found")

    await db.corporate_system_settings.update(
        where={"property_id": payload.property_id},
        data={"maintenance_mode": payload.maintenance_mode},
    )

    action = "enabled" if payload.maintenance_mode else "disabled"
    reason = payload.maintenance_message or f"Maintenance mode {action}"

    await log_setting_change(
        db=db,
        settings_id=existing.id,
        property_id=payload.property_id,
        setting_type="system_settings",
        setting_key="maintenance_mode",
        old_value={"maintenance_mode": not payload.maintenance_mode},
        new_value={"maintenance_mode": payload.maintenance_mode},
        changed_by=0,
        change_reason=reason,
        context=context,
    )

    return {
        "maintenance_mode": payload.maintenance_mode,
        "message": payload.maintenance_message,
        "estimated_duration": payload.estimated_duration,
        "scheduled_start": payload.scheduled_start,
        "scheduled_end": payload.scheduled_end,
    }


async def get_system_logs(
    property_id: int,
    log_type: Optional[str] = None,
    date: Optional[str] = None,
) -> Dict:
    sample_logs = [
        "[2025-12-22 10:30:15] INFO  Backup completed successfully",
        "[2025-12-22 10:25:00] INFO  User login: admin@property.com",
        "[2025-12-22 09:45:30] WARN  High memory usage detected",
        "[2025-12-22 08:00:00] INFO  Daily cleanup job finished",
    ]

    return {
        "property_id": property_id,
        "log_type": log_type or "all",
        "date": date or "latest",
        "logs": sample_logs,
        "total_lines": len(sample_logs),
        "note": "Simulated log data",
    }
