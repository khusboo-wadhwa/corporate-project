from typing import Optional
from prisma import Prisma
from fastapi import HTTPException

from ..audit import log_setting_change
from ..schemas import (
    SettingsSummary,
    TypeSummary,
    SummaryByType,
    SettingsSummaryResponse,
    ActivityEntry,
    ActivitySummary,
    SettingsActivityResponse,
    ComplianceCheck,
    ComplianceOverview,
    ComplianceResponse,
    SettingsSyncRequest,
)


async def get_settings_summary(property_id: int) -> SettingsSummaryResponse:
    summary = SettingsSummary(
        total_settings=45,
        active_settings=40,
        last_updated="2025-12-23T14:30:00Z",
        compliance_score=95,
        pending_changes=3,
    )
    by_type = SummaryByType(
        verification=TypeSummary(total=8, active=8),
        credit=TypeSummary(total=12, active=10),
        security=TypeSummary(total=10, active=10),
        system=TypeSummary(total=8, active=8),
        notification=TypeSummary(total=5, active=5),
        contract=TypeSummary(total=7, active=7),
    )
    return SettingsSummaryResponse(summary=summary, by_type=by_type)


async def get_settings_activity(
    property_id: int,
    days: int = 7,
    setting_type: Optional[str] = None,
) -> SettingsActivityResponse:
    activities = [
        ActivityEntry(
            id="act-001",
            setting_type="credit",
            setting_key="min_credit_limit",
            old_value=1000,
            new_value=5000,
            changed_by=123,
            changed_by_name="John Doe",
            change_reason="Increased minimum limit for better coverage",
            created_date="2025-12-23T10:30:00Z",
        ),
        ActivityEntry(
            id="act-002",
            setting_type="verification",
            setting_key="verification_expiry_months",
            old_value=12,
            new_value=24,
            changed_by=456,
            changed_by_name="Jane Smith",
            change_reason="Extended verification period",
            created_date="2025-12-22T15:45:00Z",
        ),
    ]
    summary = ActivitySummary(
        total_changes=15,
        most_active_user="Jane Smith",
        most_changed_type="verification",
    )
    return SettingsActivityResponse(activities=activities, summary=summary)


async def get_settings_compliance(
    property_id: int,
    regulation_type: Optional[str] = None,
) -> ComplianceResponse:
    checks = [
        ComplianceCheck(
            check_name="data_retention",
            status="passed",
            requirement="Data retention >= 5 years",
            actual_value="7 years",
            regulation="GDPR Article 17",
        ),
        ComplianceCheck(
            check_name="password_expiry",
            status="failed",
            requirement="Password expiry <= 90 days",
            actual_value="120 days",
            regulation="ISO 27001",
            recommendation="Set password expiry to 90 days or less",
        ),
        ComplianceCheck(
            check_name="two_factor_auth",
            status="warning",
            requirement="2FA recommended for admin accounts",
            actual_value="Enabled for admins only",
            regulation="NIST 800-63B",
        ),
    ]
    overview = ComplianceOverview(
        overall_compliance=95,
        passed_checks=28,
        failed_checks=2,
        warnings=3,
    )
    return ComplianceResponse(compliance_check=overview, checks=checks)


async def sync_settings(
    db: Prisma,
    target_property_id: int,
    payload: SettingsSyncRequest,
) -> dict:
    if target_property_id == payload.source_property_id:
        raise HTTPException(
            status_code=400,
            detail="Source and target properties cannot be the same",
        )

    await log_setting_change(
        db=db,
        settings_id=f"sync_{payload.source_property_id}_to_{target_property_id}",
        property_id=target_property_id,
        setting_type="settings_sync",
        setting_key="sync_action",
        old_value=None,
        new_value={
            "source_property_id": payload.source_property_id,
            "setting_types": payload.setting_types,
            "overwrite": payload.overwrite_existing,
        },
        changed_by=0,
        change_reason=payload.sync_reason,
        context={"ip_address": "unknown", "user_agent": "unknown"},
    )

    return {
        "target_property": target_property_id,
        "source_property": payload.source_property_id,
        "types": payload.setting_types,
        "overwrite": payload.overwrite_existing,
        "status": "queued",
    }
