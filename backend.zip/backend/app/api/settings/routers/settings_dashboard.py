from typing import Optional
from fastapi import APIRouter, Depends, Path
from prisma import Prisma

from app.core.database import get_prisma_client
from ..responses import success_response
from ..schemas import SettingsSyncRequest
from ..services import (
    get_settings_summary,
    get_settings_activity,
    get_settings_compliance,
    sync_settings,
)

router = APIRouter(prefix="/corporate/settings", tags=["Corporate Settings Dashboard"])


@router.get("/summary")
async def fetch_settings_summary(
    property_id: int,
    db: Prisma = Depends(get_prisma_client),
):
    data = await get_settings_summary(property_id)
    return success_response(
        data=data, message="Settings summary retrieved successfully"
    )


@router.get("/activity")
async def fetch_settings_activity(
    property_id: int,
    days: int = 7,
    setting_type: Optional[str] = None,
    db: Prisma = Depends(get_prisma_client),
):
    data = await get_settings_activity(property_id, days, setting_type)
    return success_response(data=data, message="Recent settings activity retrieved")


@router.get("/compliance")
async def fetch_settings_compliance(
    property_id: int,
    regulation_type: Optional[str] = None,
    db: Prisma = Depends(get_prisma_client),
):
    data = await get_settings_compliance(property_id, regulation_type)
    return success_response(data=data, message="Compliance check completed")


@router.post("/sync/{propertyId}")
async def initiate_settings_sync(
    payload: SettingsSyncRequest,
    propertyId: int = Path(..., alias="propertyId", description="Target property ID"),
    db: Prisma = Depends(get_prisma_client),
):
    result = await sync_settings(db, propertyId, payload)
    return success_response(
        message=f"Settings sync from property {payload.source_property_id} to {propertyId} initiated",
        data=result,
    )
