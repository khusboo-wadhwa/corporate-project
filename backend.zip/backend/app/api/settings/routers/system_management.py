from typing import Optional, List
from fastapi import APIRouter, Depends, Query
from prisma import Prisma

from app.core.database import get_prisma_client
from ..responses import success_response
from ..schemas import ClearCacheRequest, ReloadSettingsRequest
from ..services import (
    clear_cache,
    run_diagnostics,
    reload_settings,
)

router = APIRouter(prefix="/corporate/settings", tags=["Corporate System Management"])


@router.post("/clear-cache")
async def perform_cache_clear(
    payload: ClearCacheRequest,
    db: Prisma = Depends(get_prisma_client),
):
    result = await clear_cache(db, payload)
    return success_response(
        message=f"Cache cleared successfully for types: {', '.join(result['cleared_types'])}",
        data=result,
    )


@router.get("/diagnostics")
async def execute_diagnostics(
    property_id: int,
    test_components: Optional[List[str]] = Query(None),
    db: Prisma = Depends(get_prisma_client),
):
    data = await run_diagnostics(property_id, test_components)
    return success_response(data=data, message="System diagnostics completed")


@router.post("/reload")
async def perform_settings_reload(
    payload: ReloadSettingsRequest,
    db: Prisma = Depends(get_prisma_client),
):
    result = await reload_settings(db, payload)
    return success_response(
        message=f"Settings reloaded successfully for types: {', '.join(result['reloaded_types'])}",
        data=result,
    )
