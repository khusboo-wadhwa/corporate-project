from typing import Optional
from fastapi import APIRouter, Depends, Header, Path, HTTPException
from prisma import Prisma

from app.core.database import get_prisma_client
from ..responses import success_response
from ..dependencies import get_request_context
from ..schemas import (
    CreditPolicyCreateRequest,
    CreditPolicyUpdateRequest,
    CreditPolicyDeactivateRequest,
)
from ..services import (
    get_credit_policies,
    create_credit_policy,
    update_credit_policy,
    deactivate_credit_policy,
    get_applied_credit_policy,
)

router = APIRouter(prefix="/corporate", tags=["Corporate Credit Policy"])


@router.get("/credit-policy")
async def list_credit_policies(
    property_id: int,
    is_active: Optional[bool] = True,
    db: Prisma = Depends(get_prisma_client),
):
    data = await get_credit_policies(db, property_id, is_active)
    return success_response(
        data=data,
        message="Credit policies retrieved successfully",
    )


@router.post("/credit-policy")
async def create_new_credit_policy(
    payload: CreditPolicyCreateRequest,
    db: Prisma = Depends(get_prisma_client),
    context: dict = Depends(get_request_context),
    x_change_reason: Optional[str] = Header(None, alias="X-Change-Reason"),
):
    change_reason = x_change_reason or "New credit policy created"
    policy = await create_credit_policy(db, payload, change_reason, context)
    return success_response(
        data=policy,
        message="Credit policy created successfully",
    )


@router.put("/credit-policy/{policy_id}")
async def modify_credit_policy(
    policy_id: str = Path(..., description="UUID of the credit policy"),
    payload: CreditPolicyUpdateRequest = None,
    db: Prisma = Depends(get_prisma_client),
    context: dict = Depends(get_request_context),
    x_change_reason: Optional[str] = Header(None, alias="X-Change-Reason"),
):
    change_reason = payload.change_reason or x_change_reason
    if not change_reason:
        raise HTTPException(
            status_code=400,
            detail="Change reason is required (in body or X-Change-Reason header)",
        )
    updated = await update_credit_policy(db, policy_id, payload, change_reason, context)
    return success_response(
        data=updated,
        message="Credit policy updated successfully",
    )


@router.delete("/credit-policy/{policy_id}")
async def deactivate_existing_credit_policy(
    policy_id: str = Path(..., description="UUID of the credit policy"),
    payload: CreditPolicyDeactivateRequest = None,
    db: Prisma = Depends(get_prisma_client),
    context: dict = Depends(get_request_context),
):
    reason = payload.deactivation_reason if payload else "No reason provided"
    await deactivate_credit_policy(db, policy_id, reason, context)
    return success_response(message="Credit policy deactivated successfully")


@router.get("/credit-policy/apply/{companyId}")
async def fetch_applied_credit_policy(
    companyId: int,
    property_id: int,
    db: Prisma = Depends(get_prisma_client),
):
    data = await get_applied_credit_policy(db, companyId, property_id)
    return success_response(
        data=data,
        message="Applied credit policy determined",
    )
