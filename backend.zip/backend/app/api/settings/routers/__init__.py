from .credit_policy import router as credit_policy_router
from .notification_templates import router as notification_templates_router
from .security_settings import router as security_settings_router
from .settings_dashboard import router as dashboard_router
from .settings_management import router as management_router
from .system_management import router as system_management_router
from .system_settings import router as system_settings_router
from .verification_policy import router as verification_policy_router
from .contract_defaults import router as contract_defaults_router

__all__ = [
    "credit_policy_router",
    "notification_templates_router",
    "security_settings_router",
    "dashboard_router",
    "management_router",
    "system_management_router",
    "system_settings_router",
    "verification_policy_router",
    "contract_defaults_router"
]
