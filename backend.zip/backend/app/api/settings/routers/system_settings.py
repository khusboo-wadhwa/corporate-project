from typing import Optional, Dict
from fastapi import APIRouter, Depends
from prisma import Prisma

from app.core.database import get_prisma_client
from ..responses import success_response
from ..dependencies import get_request_context
from ..schemas import (
    SystemSettingsCreateRequest,
    SystemSettingsUpdateRequest,
    ManualBackupRequest,
    MaintenanceModeRequest,
)
from ..services import (
    get_system_settings,
    create_system_settings,
    update_system_settings,
    trigger_manual_backup,
    get_system_status,
    set_maintenance_mode,
    get_system_logs,
)

router = APIRouter(prefix="/corporate", tags=["Corporate System Settings"])


@router.get("/system-settings")
async def fetch_system_settings(
    property_id: int,
    db: Prisma = Depends(get_prisma_client),
):
    data = await get_system_settings(db, property_id)
    return success_response(data=data, message="System settings retrieved successfully")


@router.post("/system-settings")
async def create_new_system_settings(
    payload: SystemSettingsCreateRequest,
    db: Prisma = Depends(get_prisma_client),
    context: Dict[str, str] = Depends(get_request_context),
):
    data = await create_system_settings(db, payload, context)
    return success_response(data=data, message="System settings created successfully")


@router.put("/system-settings")
async def modify_system_settings(
    payload: SystemSettingsUpdateRequest,
    db: Prisma = Depends(get_prisma_client),
    context: Dict[str, str] = Depends(get_request_context),
):
    await update_system_settings(db, payload, context)
    return success_response(message="System settings updated successfully")


@router.post("/system-settings/backup")
async def initiate_manual_backup(
    payload: ManualBackupRequest,
    db: Prisma = Depends(get_prisma_client),
    context: Dict[str, str] = Depends(get_request_context),
):
    await trigger_manual_backup(db, payload, context)
    return success_response(
        message=f"Manual {payload.backup_type} backup triggered successfully"
    )


@router.get("/system-settings/status")
async def fetch_system_status(property_id: int):
    data = await get_system_status(property_id)
    return success_response(data=data, message="System status retrieved")


@router.post("/system-settings/maintenance")
async def configure_maintenance_mode(
    payload: MaintenanceModeRequest,
    db: Prisma = Depends(get_prisma_client),
    context: Dict[str, str] = Depends(get_request_context),
):
    result = await set_maintenance_mode(db, payload, context)
    action = "enabled" if payload.maintenance_mode else "disabled"
    return success_response(
        message=f"Maintenance mode {action} successfully", data=result
    )


@router.get("/system-settings/logs")
async def fetch_system_logs(
    property_id: int,
    log_type: Optional[str] = None,
    date: Optional[str] = None,
    db: Prisma = Depends(get_prisma_client),
):
    data = await get_system_logs(property_id, log_type, date)
    return success_response(data=data, message="System logs retrieved")
