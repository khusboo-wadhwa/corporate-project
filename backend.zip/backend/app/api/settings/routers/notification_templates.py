from typing import Optional
from fastapi import APIRouter, Depends, Header, Path, HTTPException
from prisma import Prisma

from app.core.database import get_prisma_client
from ..responses import success_response
from ..dependencies import get_request_context
from ..schemas import (
    NotificationTemplateCreateRequest,
    NotificationTemplateUpdateRequest,
    NotificationPreferencesUpdateRequest,
    NotificationTestRequest,
)
from ..services import (
    get_templates,
    get_specific_template,
    create_template,
    update_template,
    get_preferences,
    update_preferences,
    test_template,
)

router = APIRouter(
    prefix="/corporate/notifications", tags=["Corporate Notification Templates"]
)


@router.get("/templates")
async def get_notification_templates(
    property_id: int,
    template_type: Optional[str] = None,
    is_active: Optional[bool] = True,
    db: Prisma = Depends(get_prisma_client),
):
    data = await get_templates(db, property_id, template_type, is_active)
    return success_response(
        data=data, message="Notification templates retrieved successfully"
    )


@router.get("/templates/{template_type}/{notification_event}")
async def fetch_specific_template(
    template_type: str,
    notification_event: str,
    property_id: int,
    db: Prisma = Depends(get_prisma_client),
):
    template = await get_specific_template(
        db, property_id, template_type, notification_event
    )
    return success_response(
        data=template, message="Notification template retrieved successfully"
    )


@router.post("/templates")
async def create_notification_template(
    payload: NotificationTemplateCreateRequest,
    db: Prisma = Depends(get_prisma_client),
    context: dict = Depends(get_request_context),
):
    template = await create_template(db, payload, context)
    return success_response(
        data=template, message="Notification template created successfully"
    )


@router.put("/templates/{template_id}")
async def update_notification_template(
    payload: NotificationTemplateUpdateRequest,
    template_id: str = Path(..., description="UUID of the template"),
    x_change_reason: Optional[str] = Header(None, alias="X-Change-Reason"),
    db: Prisma = Depends(get_prisma_client),
    context: dict = Depends(get_request_context),
):
    change_reason = payload.change_reason or x_change_reason
    if not change_reason:
        raise HTTPException(status_code=400, detail="Change reason is required")

    updated = await update_template(db, template_id, payload, change_reason, context)
    return success_response(
        data=updated, message="Notification template updated successfully"
    )


@router.get("/preferences")
async def get_notification_preferences(
    property_id: int,
    db: Prisma = Depends(get_prisma_client),
):
    data = await get_preferences(property_id)
    return success_response(data=data, message="Notification preferences retrieved")


@router.put("/preferences")
async def update_notification_preferences(
    payload: NotificationPreferencesUpdateRequest,
    db: Prisma = Depends(get_prisma_client),
    context: dict = Depends(get_request_context),
):
    await update_preferences(db, payload, context)
    return success_response(message="Notification preferences updated successfully")


@router.post("/test/{template_id}")
async def test_notification_template(
    payload: NotificationTestRequest,
    template_id: str = Path(..., description="UUID of the template"),
    db: Prisma = Depends(get_prisma_client),
):
    result = await test_template(db, template_id, payload)
    return success_response(data=result, message="Test notification preview generated")
