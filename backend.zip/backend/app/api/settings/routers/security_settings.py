from typing import Optional, Dict
from datetime import date
from fastapi import APIRouter, Depends, Path, Query
from prisma import Prisma

from app.core.database import get_prisma_client
from ..responses import success_response
from ..dependencies import get_request_context
from ..schemas import (
    SecuritySettingsCreateRequest,
    SecuritySettingsUpdateRequest,
    IPWhitelistAddRequest,
    IPWhitelistRemoveRequest,
)
from ..services import (
    get_security_settings,
    create_security_settings,
    update_security_settings,
    add_ip_whitelist,
    remove_ip_whitelist,
    get_security_audit_logs,
)

router = APIRouter(prefix="/corporate", tags=["Corporate Security Settings"])


@router.get("/security-settings")
async def fetch_security_settings(
    property_id: int,
    db: Prisma = Depends(get_prisma_client),
):
    settings = await get_security_settings(db, property_id)
    return success_response(
        data=settings, message="Security settings retrieved successfully"
    )


@router.post("/security-settings")
async def create_new_security_settings(
    payload: SecuritySettingsCreateRequest,
    db: Prisma = Depends(get_prisma_client),
    context: Dict[str, str] = Depends(get_request_context),
):
    settings = await create_security_settings(db, payload, context)
    return success_response(
        data=settings, message="Security settings created successfully"
    )


@router.put("/security-settings")
async def modify_security_settings(
    payload: SecuritySettingsUpdateRequest,
    db: Prisma = Depends(get_prisma_client),
    context: Dict[str, str] = Depends(get_request_context),
):
    settings = await update_security_settings(db, payload, context)
    return success_response(
        data=settings, message="Security settings updated successfully"
    )


@router.post("/security-settings/whitelist")
async def add_to_ip_whitelist(
    payload: IPWhitelistAddRequest,
    db: Prisma = Depends(get_prisma_client),
    context: Dict[str, str] = Depends(get_request_context),
):
    result = await add_ip_whitelist(db, payload, context)
    return success_response(
        message=f"Added {len(result['added_ips'])} IP(s) to whitelist",
        data=result,
    )


@router.delete("/security-settings/whitelist/{ip}")
async def remove_from_ip_whitelist(
    ip: str = Path(..., description="IP address to remove from whitelist"),
    property_id: int = Query(...),
    payload: IPWhitelistRemoveRequest = None,
    db: Prisma = Depends(get_prisma_client),
    context: Dict[str, str] = Depends(get_request_context),
):
    reason = payload.change_reason if payload else "Removed IP from whitelist"
    await remove_ip_whitelist(db, ip, property_id, reason, context)
    return success_response(message=f"Removed IP {ip} from whitelist")


@router.get("/security-settings/audit-logs")
async def fetch_security_audit_logs(
    property_id: int,
    start_date: Optional[date] = None,
    end_date: Optional[date] = None,
    user_id: Optional[int] = None,
    event_type: Optional[str] = None,
    db: Prisma = Depends(get_prisma_client),
):
    logs = await get_security_audit_logs(
        property_id, start_date, end_date, user_id, event_type
    )
    return success_response(data=logs, message="Security audit logs retrieved")
