from typing import Optional
from fastapi import APIRouter, Depends, UploadFile, File, Form, Path, Query, Body
from prisma import Prisma

from app.core.database import get_prisma_client
from ..responses import success_response
from ..dependencies import get_request_context
from ..schemas import (
    ExportSettingsRequest,
    ResetSettingsRequest,
    ValidateSettingsRequest,
)
from ..services import (
    export_settings,
    import_settings,
    reset_settings_type,
    get_default_settings,
    validate_settings,
    get_all_corporate_settings,
    get_settings_by_type,
    update_settings_by_type,
    bulk_update_corporate_settings,
    get_settings_audit_history,
)

router = APIRouter(
    prefix="/corporate/settings", tags=["Corporate Settings Management"]
)

@router.get("")
async def fetch_all_corporate_settings(
    property_id: Optional[int] = Query(None),
    db: Prisma = Depends(get_prisma_client),
):
    data = await get_all_corporate_settings(db, property_id)
    return success_response(
        data=data,
        message="Corporate settings retrieved successfully",
    )

@router.get("/{type}")
async def fetch_settings_by_type(
    type: str = Path(..., description=""),
    property_id: int = Query(...),
    db: Prisma = Depends(get_prisma_client),
):
    data = await get_settings_by_type(db, type, property_id)
    return success_response(
        data=data,
        message=f"{type.capitalize()} settings retrieved successfully",
    )

@router.put("/{type}")
async def update_settings_for_type(
    type: str = Path(...),
    payload: dict = Body(...),
    db: Prisma = Depends(get_prisma_client),
    context: dict = Depends(get_request_context),
):
    await update_settings_by_type(db, type, payload, context)
    return success_response(
        message=f"{type.capitalize()} settings updated successfully"
    )

@router.post("/bulk-update")
async def bulk_update_settings(
    payload: dict = Body(...),
    db: Prisma = Depends(get_prisma_client),
    context: dict = Depends(get_request_context),
):
    await bulk_update_corporate_settings(db, payload, context)
    return success_response(
        message="Corporate settings updated successfully"
    )

@router.get("/history/{settingsId}")
async def fetch_settings_audit_history(
    settingsId: str = Path(...),
    days: int = Query(30),
    db: Prisma = Depends(get_prisma_client),
):
    data = await get_settings_audit_history(db, settingsId, days)
    return success_response(
        data=data,
        message="Settings audit history retrieved successfully",
    )






@router.post("/export")
async def perform_settings_export(
    payload: ExportSettingsRequest,
    db: Prisma = Depends(get_prisma_client),
    context: dict = Depends(get_request_context),
):
    data = await export_settings(db, payload, context)
    return success_response(
        data=data,
        message=f"Settings exported successfully in {payload.format.upper()} format",
    )


@router.post("/import")
async def perform_settings_import(
    property_id: int = Form(...),
    file: UploadFile = File(...),
    overwrite_existing: bool = Form(False),
    dry_run: bool = Form(True),
    import_password: Optional[str] = Form(None),
    db: Prisma = Depends(get_prisma_client),
    context: dict = Depends(get_request_context),
):
    content = await file.read()
    result = await import_settings(
        db=db,
        property_id=property_id,
        file_content=content,
        overwrite_existing=overwrite_existing,
        dry_run=dry_run,
        import_password=import_password,
        context=context,
    )
    message = (
        "Settings import validation completed"
        if dry_run
        else "Settings imported successfully"
    )
    return success_response(data=result, message=message)


@router.post("/reset/{type}")
async def reset_specific_settings_type(
    payload: ResetSettingsRequest,
    type: str = Path(
        ..., description="Setting type: verification, credit, security, system"
    ),
    db: Prisma = Depends(get_prisma_client),
    context: dict = Depends(get_request_context),
):
    await reset_settings_type(db, type, payload, context)
    return success_response(
        message=f"{type.capitalize()} settings reset to defaults successfully"
    )


@router.get("/defaults/{type}")
async def fetch_default_settings(
    type: str = Path(..., description="Setting type to get defaults for"),
):
    data = await get_default_settings(type)
    return success_response(data=data, message=f"Default {type} settings retrieved")


@router.post("/validate")
async def run_settings_validation(
    payload: ValidateSettingsRequest,
    db: Prisma = Depends(get_prisma_client),
):
    result = await validate_settings(payload)
    return success_response(data=result, message="Settings validation completed")
