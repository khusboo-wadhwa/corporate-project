from fastapi import APIRouter, Depends, Header, HTTPException, status, Query, Body, Form, File, UploadFile
from prisma import Prisma

from app.core.database import get_prisma_client
from ..responses import success_response
from ..dependencies import get_request_context
from ..services.contract_defaults import (
    get_contract_defaults,
    update_contract_defaults,
    upload_contract_template,
    get_contract_template,
)

router = APIRouter(
    prefix="/corporate/contract-defaults",
    tags=["Corporate Contract Defaults"],
)

@router.get("")
async def fetch_contract_defaults(
    property_id: int = Query(...),
    db: Prisma = Depends(get_prisma_client),
):
    data = await get_contract_defaults(db, property_id)
    return success_response(
        data=data,
        message="Contract defaults retrieved successfully",
    )

@router.put("")
async def update_contract_defaults_route(
    payload: dict = Body(...),
    db: Prisma = Depends(get_prisma_client),
    context: dict = Depends(get_request_context),
):
    await update_contract_defaults(db, payload, context)
    return success_response(
        message="Contract defaults updated successfully",
    )

@router.post("/template")
async def upload_contract_template_route(
    property_id: int = Form(...),
    template_name: str = Form(...),
    template_type: str = Form(...),
    notification_event: str = Form(...),
    variables: str = Form("[]"),
    file: UploadFile = File(...),
    db: Prisma = Depends(get_prisma_client),
    context: dict = Depends(get_request_context),
):
    content = await file.read()

    await upload_contract_template(
        db=db,
        property_id=property_id,
        template_name=template_name,
        template_type=template_type,
        notification_event=notification_event,
        variables=eval(variables),
        file_content=content,
        context=context,
    )

    return success_response(
        message="Contract template uploaded successfully",
    )

@router.get("/template")
async def download_contract_template(
    property_id: int = Query(...),
    db: Prisma = Depends(get_prisma_client),
):
    data = await get_contract_template(db, property_id)
    return success_response(
        data=data,
        message="Contract template retrieved successfully",
    )