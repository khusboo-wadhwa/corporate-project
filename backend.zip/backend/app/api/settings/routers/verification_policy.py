from typing import Optional
from fastapi import APIRouter, Depends, Header, HTTPException, status
from prisma import Prisma

from app.core.database import get_prisma_client
from ..responses import success_response
from ..dependencies import get_request_context
from ..schemas import (
    VerificationPolicyCreateRequest,
    VerificationPolicyUpdateRequest,
    VerificationPolicyTestRequest,
)
from ..services import (
    get_verification_policy,
    create_verification_policy,
    update_verification_policy,
    test_verification_policy,
)

router = APIRouter(prefix="/corporate", tags=["Corporate Verification Policy"])


@router.get("/verification-policy")
async def fetch_verification_policy(
    property_id: int,
    db: Prisma = Depends(get_prisma_client),
):
    data = await get_verification_policy(db, property_id)
    return success_response(
        data=data, message="Verification policy retrieved successfully"
    )


@router.post("/verification-policy")
async def create_new_verification_policy(
    payload: VerificationPolicyCreateRequest,
    db: Prisma = Depends(get_prisma_client),
    context: dict = Depends(get_request_context),
):
    data = await create_verification_policy(db, payload, context)
    return success_response(
        data=data, message="Verification policy created successfully"
    )


@router.put("/verification-policy")
async def modify_verification_policy(
    payload: VerificationPolicyUpdateRequest,
    db: Prisma = Depends(get_prisma_client),
    context: dict = Depends(get_request_context),
    x_change_reason: Optional[str] = Header(None, alias="X-Change-Reason"),
):
    change_reason = payload.change_reason or x_change_reason
    if not change_reason:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Change reason is required (provide in body or X-Change-Reason header)",
        )

    data = await update_verification_policy(db, payload, change_reason, context)
    return success_response(
        data=data, message="Verification policy updated successfully"
    )


@router.post("/verification-policy/test")
async def run_verification_policy_test(
    payload: VerificationPolicyTestRequest,
    db: Prisma = Depends(get_prisma_client),
):
    result = await test_verification_policy(db, payload)
    return success_response(data=result, message="Verification test completed")
