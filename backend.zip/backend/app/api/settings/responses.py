from fastapi import HTTPException
from pydantic import BaseModel, Field
from typing import Any, Generic, TypeVar, List, Optional
from datetime import datetime, timezone

T = TypeVar("T")


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


class ErrorDetail(BaseModel):
    field: Optional[str] = None
    code: str
    message: str


class APIErrorResponse(BaseModel):
    status: str = "error"
    message: str
    errors: List[ErrorDetail] = Field(default_factory=list)
    code: Optional[str] = None
    timestamp: str = Field(default_factory=utc_now_iso)


class APIMetadata(BaseModel):
    page: int = 1
    limit: int = 20
    total: int = 0
    total_pages: int = 0


class APIResponse(BaseModel, Generic[T]):
    status: str = "success"
    message: Optional[str] = None
    data: Optional[T] = None
    metadata: Optional[APIMetadata] = None
    timestamp: str = Field(default_factory=utc_now_iso)


def success_response(
    data: Any = None,
    message: Optional[str] = None,
    metadata: Optional[dict] = None,
) -> APIResponse:
    return APIResponse(
        data=data,
        message=message,
        metadata=APIMetadata(**metadata) if metadata else None,
    )


def error_response(
    message: str,
    errors: Optional[List[ErrorDetail]] = None,
    code: Optional[str] = None,
    status_code: int = 400,
):
    raise HTTPException(
        status_code=status_code,
        detail=APIErrorResponse(
            message=message,
            errors=errors or [],
            code=code,
        ).model_dump(),
    )
