from fastapi import Form
from typing import Optional, List, Literal, Any
from pydantic import BaseModel, Field


class ExportSettingsRequest(BaseModel):
    property_id: int
    format: Literal["json", "csv"] = "json"
    include_types: List[str] = Field(
        default=["verification", "credit", "security", "system", "notification"],
        description="Types to include: verification, credit, security, system, notification, contract",
    )
    include_audit_logs: bool = False
    password_protect: bool = False
    password: Optional[str] = Field(None, min_length=8, max_length=64)


class ImportSettingsRequest(BaseModel):
    property_id: int = Form(...)
    overwrite_existing: bool = Form(False)
    dry_run: bool = Form(True)
    import_password: Optional[str] = Form(None)


class ResetSettingsRequest(BaseModel):
    property_id: int
    reset_reason: str = Field(..., min_length=5)


class ValidateSettingsRequest(BaseModel):
    property_id: int
    settings: dict = Field(..., description="Nested settings by type")
    validate_compliance: bool = True
    validate_business_rules: bool = True


class DefaultSetting(BaseModel):
    setting_key: str
    default_value: Any
    description: str
    type: str


class DefaultsResponse(BaseModel):
    defaults: List[DefaultSetting]
