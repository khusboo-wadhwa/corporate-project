from typing import Optional, List, Dict
from pydantic import BaseModel, Field, ConfigDict


class SecuritySettingsCreateRequest(BaseModel):
    property_id: int
    session_timeout_minutes: int = Field(..., ge=5, le=480)
    two_factor_auth: bool = False
    ip_whitelisting: bool = False
    audit_log_retention_days: int = Field(365, ge=30, le=3650)
    max_login_attempts: int = Field(5, ge=1, le=20)
    password_expiry_days: int = Field(90, ge=30, le=365)
    api_access_enabled: bool = False
    data_encryption: bool = True
    change_reason: str = Field(
        ..., min_length=5, description="Reason for initial security setup"
    )


class SecuritySettingsResponse(BaseModel):
    id: str
    property_id: Optional[int] = None
    session_timeout_minutes: int
    two_factor_auth: bool
    ip_whitelisting: bool
    audit_log_retention_days: int
    max_login_attempts: int
    password_expiry_days: int
    api_access_enabled: bool
    data_encryption: bool
    is_active: bool

    model_config = ConfigDict(from_attributes=True)


class SecuritySettingsUpdateRequest(BaseModel):
    property_id: int
    session_timeout_minutes: Optional[int] = Field(None, ge=5, le=480)
    two_factor_auth: Optional[bool] = None
    ip_whitelisting: Optional[bool] = None
    audit_log_retention_days: Optional[int] = Field(None, ge=30, le=3650)
    max_login_attempts: Optional[int] = Field(None, ge=1, le=20)
    password_expiry_days: Optional[int] = Field(None, ge=30, le=365)
    api_access_enabled: Optional[bool] = None
    data_encryption: Optional[bool] = None
    change_reason: str = Field(
        ..., min_length=5, description="Reason for security policy change"
    )


class IPWhitelistAddRequest(BaseModel):
    property_id: int
    ip_addresses: List[str] = Field(..., min_items=1)
    description: Optional[str] = None
    change_reason: str = Field(..., min_length=5)


class IPWhitelistRemoveRequest(BaseModel):
    change_reason: str = Field(..., min_length=5)


class AuditLogEntry(BaseModel):
    id: str
    user_id: Optional[int] = None
    user_name: Optional[str] = None
    event_type: str
    ip_address: Optional[str] = None
    details: str
    created_date: str


class AuditLogsResponse(BaseModel):
    logs: List[AuditLogEntry]
    summary: Dict[str, int]
