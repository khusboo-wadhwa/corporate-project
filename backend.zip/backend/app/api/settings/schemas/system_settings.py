from typing import Optional, Literal
from pydantic import BaseModel, Field, ConfigDict


class SystemSettingsCreateRequest(BaseModel):
    property_id: int
    auto_backup: bool = True
    backup_frequency: Literal["daily", "weekly", "monthly"] = "daily"
    audit_trail_enabled: bool = True
    data_retention_years: int = Field(5, ge=1, le=10)
    performance_metrics: bool = True
    auto_updates_enabled: bool = False
    maintenance_mode: bool = False
    current_version: Optional[str] = "1.0.0"
    change_reason: str = Field(..., min_length=5)


class SystemSettingsResponse(BaseModel):
    id: str
    property_id: Optional[int] = None
    auto_backup: bool
    backup_frequency: str
    audit_trail_enabled: bool
    data_retention_years: int
    performance_metrics: bool
    auto_updates_enabled: bool
    maintenance_mode: bool
    current_version: Optional[str] = None
    is_active: bool

    model_config = ConfigDict(from_attributes=True)


class SystemSettingsUpdateRequest(BaseModel):
    property_id: int
    auto_backup: Optional[bool] = None
    backup_frequency: Optional[Literal["daily", "weekly", "monthly"]] = None
    audit_trail_enabled: Optional[bool] = None
    data_retention_years: Optional[int] = Field(None, ge=1, le=10)
    performance_metrics: Optional[bool] = None
    auto_updates_enabled: Optional[bool] = None
    maintenance_mode: Optional[bool] = None
    change_reason: str = Field(..., min_length=5)


class ManualBackupRequest(BaseModel):
    property_id: int
    backup_type: Literal["full", "incremental"] = "full"
    description: Optional[str] = None


class MaintenanceModeRequest(BaseModel):
    property_id: int
    maintenance_mode: bool
    maintenance_message: Optional[str] = None
    estimated_duration: Optional[str] = None
    scheduled_start: Optional[str] = None
    scheduled_end: Optional[str] = None


class SystemStatusResponse(BaseModel):
    system_status: str
    database: dict
    cache: dict
    storage: dict
    last_backup: str
    uptime: str
