from typing import Optional, List
from pydantic import BaseModel, Field, field_validator, ConfigDict


class CreditPolicyResponse(BaseModel):
    id: str
    property_id: Optional[int] = None
    policy_name: str
    min_credit_limit: float
    max_credit_limit: float
    default_credit_limit: float
    credit_terms: str
    risk_level: str
    auto_credit_freeze: bool
    freeze_threshold_days: Optional[int] = None
    auto_approval_enabled: Optional[bool] = None
    review_interval: str
    alerts_enabled: Optional[bool] = None
    is_active: bool

    model_config = ConfigDict(from_attributes=True)


class CreditPolicyListResponse(BaseModel):
    policies: List[CreditPolicyResponse]

    model_config = ConfigDict(from_attributes=True)


class CreditPolicyCreateRequest(BaseModel):
    property_id: int
    policy_name: str = Field(..., min_length=3, max_length=100)
    min_credit_limit: float = Field(..., ge=0)
    max_credit_limit: float = Field(..., ge=0)
    default_credit_limit: float = Field(..., ge=0)
    credit_terms: str = Field(..., example="Net 30")
    risk_level: str = Field(..., pattern="^(low|medium|high)$")
    auto_credit_freeze: Optional[bool] = True
    freeze_threshold_days: Optional[int] = Field(None, ge=1, le=365)
    auto_approval_enabled: Optional[bool] = False
    review_interval: str = Field(..., example="monthly")
    alerts_enabled: Optional[bool] = True

    model_config = ConfigDict(from_attributes=True)

    @field_validator("max_credit_limit")
    @classmethod
    def max_greater_than_min(cls, v: float, info):
        if "min_credit_limit" in info.data and v <= info.data["min_credit_limit"]:
            raise ValueError("max_credit_limit must be greater than min_credit_limit")
        return v

    @field_validator("default_credit_limit")
    @classmethod
    def default_within_range(cls, v: float, info):
        min_val = info.data.get("min_credit_limit", 0)
        max_val = info.data.get("max_credit_limit", float("inf"))
        if not (min_val <= v <= max_val):
            raise ValueError(
                "default_credit_limit must be between min and max credit limit"
            )
        return v


class CreditPolicyUpdateRequest(BaseModel):
    policy_name: Optional[str] = Field(None, min_length=3, max_length=100)
    min_credit_limit: Optional[float] = Field(None, ge=0)
    max_credit_limit: Optional[float] = Field(None, ge=0)
    default_credit_limit: Optional[float] = Field(None, ge=0)
    credit_terms: Optional[str] = None
    risk_level: str = Field(..., pattern="^(low|medium|high)$")
    auto_credit_freeze: Optional[bool] = None
    freeze_threshold_days: Optional[int] = Field(None, ge=1, le=365)
    auto_approval_enabled: Optional[bool] = None
    review_interval: str = Field(..., example="monthly")
    alerts_enabled: Optional[bool] = None
    change_reason: str = Field(
        ..., min_length=5, description="Reason for updating the policy"
    )

    model_config = ConfigDict(from_attributes=True)


class CreditPolicyDeactivateRequest(BaseModel):
    deactivation_reason: str = Field(..., min_length=5)

    model_config = ConfigDict(from_attributes=True)


class AppliedPolicyResponse(BaseModel):
    applied_policy: Optional[CreditPolicyResponse] = None
    eligibility: dict = Field(
        default_factory=lambda: {
            "is_eligible": True,
            "reasons": [],
            "recommended_limit": 0.0,
        }
    )

    model_config = ConfigDict(from_attributes=True)
