from typing import Optional, List, Literal
from pydantic import BaseModel, Field


class ClearCacheRequest(BaseModel):
    property_id: int
    cache_types: List[str] = Field(
        default=["settings", "policies", "templates"],
        description="Types of cache to clear: settings, policies, templates, all",
    )
    clear_all: bool = False
    clear_reason: str = Field(..., min_length=5)


class DiagnosticsResponse(BaseModel):
    database: dict
    cache: dict
    storage: dict


class DiagnosticIssue(BaseModel):
    component: str
    severity: Literal["info", "warning", "error"]
    message: str
    recommendation: Optional[str] = None


class DiagnosticsFullResponse(BaseModel):
    diagnostics: DiagnosticsResponse
    issues: List[DiagnosticIssue]
    summary: str


class ReloadSettingsRequest(BaseModel):
    property_id: int
    setting_types: List[str] = Field(
        default=["all"],
        description="Types to reload: verification, credit, security, system, notification, all",
    )
    reload_reason: str = Field(..., min_length=5)
