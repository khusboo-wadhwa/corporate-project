from typing import Optional, List, Any
from pydantic import BaseModel, Field


class SettingsSummary(BaseModel):
    total_settings: int
    active_settings: int
    last_updated: str
    compliance_score: int
    pending_changes: int


class TypeSummary(BaseModel):
    total: int
    active: int


class SummaryByType(BaseModel):
    verification: Optional[TypeSummary] = None
    credit: Optional[TypeSummary] = None
    security: Optional[TypeSummary] = None
    system: Optional[TypeSummary] = None
    notification: Optional[TypeSummary] = None
    contract: Optional[TypeSummary] = None


class SettingsSummaryResponse(BaseModel):
    summary: SettingsSummary
    by_type: SummaryByType


class ActivityEntry(BaseModel):
    id: str
    setting_type: str
    setting_key: str
    old_value: Optional[Any] = None
    new_value: Optional[Any] = None
    changed_by: int
    changed_by_name: str
    change_reason: str
    created_date: str


class ActivitySummary(BaseModel):
    total_changes: int
    most_active_user: str
    most_changed_type: str


class SettingsActivityResponse(BaseModel):
    activities: List[ActivityEntry]
    summary: ActivitySummary


class ComplianceCheck(BaseModel):
    check_name: str
    status: str  # passed, failed, warning
    requirement: str
    actual_value: str
    regulation: str
    recommendation: Optional[str] = None


class ComplianceOverview(BaseModel):
    overall_compliance: int
    passed_checks: int
    failed_checks: int
    warnings: int


class ComplianceResponse(BaseModel):
    compliance_check: ComplianceOverview
    checks: List[ComplianceCheck]


class SettingsSyncRequest(BaseModel):
    source_property_id: int
    setting_types: List[str] = Field(
        default=[
            "verification",
            "credit",
            "security",
            "system",
            "notification",
            "contract",
        ]
    )
    overwrite_existing: bool = False
    sync_audit_logs: bool = False
    sync_reason: str = Field(..., min_length=5)
