from typing import Optional, Dict
from pydantic import BaseModel, Field, field_validator, ConfigDict


class VerificationPolicyCreateRequest(BaseModel):
    property_id: int
    require_phone_verification: bool = True
    require_company_id_verification: bool = True
    require_address_verification: bool = False
    require_bank_verification: bool = True
    auto_mark_verified: bool = True
    verification_expiry_months: int = Field(12, ge=1, le=36)
    reminder_days_before_expiry: int = Field(30, ge=1, le=90)
    change_reason: str = Field(
        ..., min_length=5, description="Reason for initial verification policy setup"
    )
    model_config = ConfigDict(from_attributes=True)

    @field_validator("verification_expiry_months")
    @classmethod
    def validate_expiry_months(cls, v: int) -> int:
        if not (1 <= v <= 36):
            raise ValueError("verification_expiry_months must be between 1 and 36")
        return v

    @field_validator("reminder_days_before_expiry")
    @classmethod
    def validate_reminder_days(cls, v: int) -> int:
        if not (1 <= v <= 90):
            raise ValueError("reminder_days_before_expiry must be between 1 and 90")
        return v


class VerificationPolicyResponse(BaseModel):
    id: str
    property_id: Optional[int] = None
    require_phone_verification: bool
    require_company_id_verification: bool
    require_address_verification: bool
    require_bank_verification: bool
    auto_mark_verified: bool
    verification_expiry_months: int
    reminder_days_before_expiry: int
    is_active: bool
    model_config = ConfigDict(from_attributes=True)


class VerificationPolicyUpdateRequest(BaseModel):
    property_id: int = Field(..., description="Property ID to update policy for")
    require_phone_verification: Optional[bool] = None
    require_company_id_verification: Optional[bool] = None
    require_address_verification: Optional[bool] = None
    require_bank_verification: Optional[bool] = None
    auto_mark_verified: Optional[bool] = None
    verification_expiry_months: Optional[int] = None
    reminder_days_before_expiry: Optional[int] = None
    change_reason: str = Field(
        ..., min_length=5, description="Reason for changing verification policy"
    )
    model_config = ConfigDict(from_attributes=True)

    @field_validator("verification_expiry_months")
    @classmethod
    def validate_expiry_months(cls, v: Optional[int]) -> Optional[int]:
        if v is not None and not (1 <= v <= 36):
            raise ValueError("verification_expiry_months must be between 1 and 36")
        return v

    @field_validator("reminder_days_before_expiry")
    @classmethod
    def validate_reminder_days(cls, v: Optional[int]) -> Optional[int]:
        if v is not None and not (1 <= v <= 90):
            raise ValueError("reminder_days_before_expiry must be between 1 and 90")
        return v


class VerificationPolicyTestRequest(BaseModel):
    property_id: int
    test_data: Dict[str, bool] = Field(
        ...,
        example={
            "phone_verified": True,
            "company_id_verified": False,
            "address_verified": True,
            "bank_verified": True,
        },
    )
    model_config = ConfigDict(from_attributes=True)


class VerificationPolicyTestResponse(BaseModel):
    is_verified: bool
    missing_requirements: list[str]
    message: str
    model_config = ConfigDict(from_attributes=True)
