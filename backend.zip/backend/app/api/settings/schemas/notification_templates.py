from typing import Any, Optional, List, Dict
from pydantic import BaseModel, Field, field_validator, ConfigDict


class NotificationTemplateResponse(BaseModel):
    id: str
    property_id: Optional[int] = None
    template_name: str
    template_type: str
    notification_event: str
    subject: Optional[str] = None
    body: str
    variables: List[str]
    is_active: bool

    model_config = ConfigDict(from_attributes=True)


class NotificationTemplateListResponse(BaseModel):
    templates: List[NotificationTemplateResponse]
    model_config = ConfigDict(from_attributes=True)


class NotificationTemplateCreateRequest(BaseModel):
    property_id: int
    template_name: str = Field(..., min_length=3, max_length=100)
    template_type: str = Field(..., pattern="^(email|sms|system|push)$")
    notification_event: str = Field(..., min_length=3, max_length=100)
    subject: Optional[str] = None
    body: str = Field(..., min_length=10)
    variables: List[str] = Field(default_factory=list)

    model_config = ConfigDict(from_attributes=True)

    @field_validator("variables")
    @classmethod
    def validate_variables(cls, v: List[str]) -> List[str]:
        if any(not var.strip() for var in v):
            raise ValueError("Variables cannot be empty strings")
        return [var.strip() for var in v]


class NotificationTemplateUpdateRequest(BaseModel):
    template_name: Optional[str] = Field(None, min_length=3, max_length=100)
    subject: Optional[str] = None
    body: Optional[str] = Field(None, min_length=10)
    variables: Optional[List[str]] = None
    is_active: Optional[bool] = None
    change_reason: str = Field(..., min_length=5)

    model_config = ConfigDict(from_attributes=True)


class NotificationPreferencesResponse(BaseModel):
    preferences: Dict[str, Dict[str, bool]]
    recipients: Dict[str, List[str]]

    model_config = ConfigDict(from_attributes=True)


class NotificationPreferencesUpdateRequest(BaseModel):
    property_id: int
    preferences: Dict[str, Dict[str, bool]]
    change_reason: str = Field(..., min_length=5)

    model_config = ConfigDict(from_attributes=True)


class NotificationTestRequest(BaseModel):
    property_id: int
    test_data: Dict[str, Any]
    test_email: Optional[str] = None
    test_phone: Optional[str] = None

    model_config = ConfigDict(from_attributes=True)
