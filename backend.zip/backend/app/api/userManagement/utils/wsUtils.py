
from typing import List
from fastapi import WebSocket
from asyncio import Lock

# A global list to store connected clients
connected_clients: List[WebSocket] = []
# A lock to ensure thread-safety when modifying the clients list
clients_lock = Lock()

async def add_client(client: WebSocket):
    """Add a WebSocket client to the list of connected clients."""
    async with clients_lock:  # Ensure thread-safety when modifying the list
        connected_clients.append(client)

async def remove_client(client: WebSocket):
    """Remove a WebSocket client from the list of connected clients."""
    async with clients_lock:  # Ensure thread-safety when modifying the list
        if client in connected_clients:
            connected_clients.remove(client)

async def broadcast_message(message: str):
    """Broadcast a message to all connected WebSocket clients."""
    async with clients_lock:  # Ensure thread-safety when modifying the list
        # We need to take a copy of the list to avoid modifying it while iterating
        clients_to_send = list(connected_clients)
    
    # Send message to all clients, handle errors gracefully
    for client in clients_to_send:
        try:
            await client.send_text(message)
        except Exception:
            await remove_client(client)

