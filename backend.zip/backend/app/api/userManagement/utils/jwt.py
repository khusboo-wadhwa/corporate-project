# from datetime import datetime, timedelta
# import jwt

# SECRET_KEY = "your_secret_key"
# ALGORITHM = "HS256"

# def generate_jwt_tokens(user):
#     access_exp = datetime.utcnow() + timedelta(minutes=15)
#     refresh_exp = datetime.utcnow() + timedelta(days=7)

#     payload = {
#         "sub": user.email,
#         "user_id": user.id,
#         "first_name": user.first_name,
#         "last_name": user.last_name,
#         "roles": user.role,
#         "exp": access_exp
#     }
#     access_token = jwt.encode(payload, SECRET_KEY, algorithm=ALGORITHM)

#     refresh_payload = {
#         "sub": user.email,
#         "user_id": user.id,
#         "type": "refresh",
#         "exp": refresh_exp
#     }
#     refresh_token = jwt.encode(refresh_payload, SECRET_KEY, algorithm=ALGORITHM)

#     return access_token, refresh_token, access_exp, refresh_exp


# app/api/userManagement/utils/jwt.py

from fastapi import HTTPException
from datetime import datetime, timedelta
import jwt

SECRET_KEY = "Rohit@~123"
ALGORITHM = "HS256"

def generate_jwt_tokens(user_info):
    access_exp = datetime.utcnow() + timedelta(minutes=30)
    refresh_exp = datetime.utcnow() + timedelta(days=7)

    access_payload = {
        "sub": str(user_info["id"]),
        "email": user_info["email"],
        "first_name": user_info["first_name"],
        "last_name": user_info["last_name"],
        "property_id": user_info["property_id"],
        "roles": user_info["roles"],
        "permissions": user_info["permissions"],
        "exp": access_exp
    }

    refresh_payload = {
        "sub": str(user_info["id"]),
        "type": "refresh",
        "exp": refresh_exp
    }

    access_token = jwt.encode(access_payload, SECRET_KEY, algorithm=ALGORITHM)
    refresh_token = jwt.encode(refresh_payload, SECRET_KEY, algorithm=ALGORITHM)

    return access_token, refresh_token, access_exp, refresh_exp


def verify_jwt_token(token: str):
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        
        # Check expiration
        if datetime.utcnow() > datetime.fromtimestamp(payload["exp"]):
            raise HTTPException(status_code=401, detail="Token expired")
            
        return payload
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token expired")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Invalid token")