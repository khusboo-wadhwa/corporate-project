
#09-12-2024
from datetime import datetime, timedelta
# from prisma import Prisma
from firebase_admin import auth
# from apscheduler.schedulers.asyncio import AsyncIOScheduler
# import asyncio


# async def delete_unverified_users(expiration_hours: int):
#     """
#     Deletes users in the `users1` model who have not verified their email or phone 
#     within the given timeframe, and removes them from Firebase.
#     """
#     prisma = Prisma()
#     if not prisma.is_connected():
#         await prisma.connect()

#     try:
#         # Calculate the expiration time
#         expiration_time = datetime.utcnow() - timedelta(hours=expiration_hours)

#         # Find unverified users in the `users1` table
#         unverified_users = await prisma.users1.find_many(
#             where={
#                 "AND": [
#                     {"is_email_verified": False},  # Assuming `is_email_verified` is a boolean field
#                     {"is_phone_verified": False},  # Assuming `is_phone_verified` is a boolean field
#                     {"created_at": {"lt": expiration_time}}
#                 ]
#             }
#         )

#         for user in unverified_users:
#             # Delete user from Firebase Authentication
#             try:
#                 auth.delete_user(user)  # Assuming `firebase_uid` stores Firebase's user UID
#                 print(f"Deleted Firebase user: {user}")
#             except auth.UserNotFoundError:
#                 print(f"User with UID {user.firebase_uid} not found in Firebase.")

#             # Delete user from Prisma database
#             await prisma.users1.delete(where={"id": user.id})

#         print(f"Deleted {len(unverified_users)} unverified users from `users1` table and Firebase.")
#     finally:
#         await prisma.disconnect()

# # APScheduler setup for periodic task execution
# def schedule_task():
#     scheduler = AsyncIOScheduler()

#     # Schedule the job to run every 24 hours
#     scheduler.add_job(
#         lambda: asyncio.run(delete_unverified_users(1)), 
#         'interval', 
#         hours=24
#     )

#     # Start the scheduler
#     scheduler.start()

#     # Keep the script running
#     try:
#         asyncio.get_event_loop().run_forever()
#     except (KeyboardInterrupt, SystemExit):
#         pass

# # Run the task scheduler
# if __name__ == "__main__":
#     print("Starting scheduler to delete unverified users every 24 hours.")
#     schedule_task()


##old code commented
# from datetime import datetime, timedelta
# import logging
# from app.core.database import get_prisma_client  # Ensure to import your `get_prisma_client` if it's in a different module
# from prisma import Prisma  # Import Prisma client

# # Assuming `prisma` client is imported and available
# prisma = Prisma()

# async def fetch_unverified_users(expiration_hours: int):
#     """
#     Fetch users who are unverified and were created more than `expiration_hours` ago.
#     """
#     # Calculate the expiration cutoff datetime
#     expiration_cutoff = datetime.utcnow() - timedelta(hours=expiration_hours)

#     # Ensure Prisma client is connected
#     client = await get_prisma_client()  # Get the connected Prisma client

#     try:
#         # Query the database for unverified users
#         logging.debug(f"Fetching unverified users created before {expiration_cutoff}")
#         unverified_users = await client.aq_users.find_many(
#             where={
#                 "is_email_verified": False,  # User must not have verified their email
#                 "is_phone_verified": False,  # Optionally check phone verification status
#                 "created_at": {"lt": expiration_cutoff}  # Created before the cutoff time
#             }
#         )
#         return unverified_users

#     except Exception as e:
#         logging.error(f"Error fetching unverified users: {str(e)}")
#         return []

#     # No need to disconnect the Prisma client here since we're using get_prisma_client
#     # for management of connection lifecycle. Disconnecting would happen elsewhere.


# async def delete_unverified_users(expiration_hours: int):
#     """
#     Deletes unverified users who were created more than `expiration_hours` ago.
#     """
#     try:
#         # Fetch unverified users based on your criteria (e.g., from the database)
#         unverified_users = await fetch_unverified_users(expiration_hours)

#         for user in unverified_users:
#             try:
#                 # Ensure `user` contains the Firebase UID, not the whole user object
#                 if hasattr(user, 'firebase_uid') and user.firebase_uid:
#                     auth.delete_user(user.firebase_uid)
#                 else:
#                     print(f"User {user.id} does not have a valid Firebase UID.")
#             except Exception as e:
#                 print(f"Error deleting user with Firebase UID {user.firebase_uid}: {str(e)}")
#     except Exception as e:
#         print(f"Error fetching unverified users: {str(e)}")


from datetime import datetime, timedelta
import logging
from app.core.database import get_prisma_client
from prisma import Prisma

# Assuming `prisma` client is imported and available
prisma = Prisma()
logger = logging.getLogger(__name__)  # Add logger

async def fetch_unverified_users(expiration_hours: int):
    """
    Fetch users who are unverified and were created more than `expiration_hours` ago.
    """
    # Calculate the expiration cutoff datetime
    expiration_cutoff = datetime.utcnow() - timedelta(hours=expiration_hours)

    # Ensure Prisma client is connected
    client = await get_prisma_client()  # Get the connected Prisma client

    try:
        # Query the database for unverified users
        logging.debug(f"Fetching unverified users created before {expiration_cutoff}")
        
        # CORRECTED: is_email_verified is in aq_user_verification table, not aq_users
        unverified_users = await client.aq_users.find_many(
            where={
                "aq_user_verification": {
                    "is_email_verified": False,
                    "email_verification_code_sent_at": {
                        "lt": expiration_cutoff
                    }
                }
            },
            include={
                "aq_user_verification": True  # Include the verification record
            }
        )
        return unverified_users

    except Exception as e:
        logging.error(f"Error fetching unverified users: {str(e)}")
        return []


async def delete_unverified_users(expiration_hours: int = 72):  # Default to 72 hours
    """
    Deletes unverified users who were created more than `expiration_hours` ago.
    """
    try:
        # Fetch unverified users based on your criteria
        unverified_users = await fetch_unverified_users(expiration_hours)
        
        logger.info(f"Found {len(unverified_users)} unverified users to delete.")

        deleted_count = 0
        for user in unverified_users:
            try:
                # Get the Prisma client
                client = await get_prisma_client()
                
                # Delete related records first (due to foreign key constraints)
                # Delete from aq_user_verification
                await client.aq_user_verification.delete_many(where={"user_id": user.id})
                
                # Delete from aq_user_security
                await client.aq_user_security.delete_many(where={"user_id": user.id})
                
                # Delete from aq_user_roles
                await client.aq_user_roles.delete_many(where={"user_id": user.id})
                
                # Delete the user
                await client.aq_users.delete(where={"id": user.id})
                
                deleted_count += 1
                logger.info(f"Deleted unverified user: {user.email} (ID: {user.id})")
                
            except Exception as e:
                logger.error(f"Error deleting user {user.email}: {str(e)}")
        
        logger.info(f"Successfully deleted {deleted_count} unverified users.")
        
    except Exception as e:
        logger.error(f"Error in delete_unverified_users: {str(e)}")