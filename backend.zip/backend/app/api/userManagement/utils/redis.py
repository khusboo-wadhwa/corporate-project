import os
from redis.asyncio import Redis
from datetime import datetime,timedelta
import json

# Redis configuration
REDIS_HOST = os.getenv("REDIS_HOST", "localhost")
REDIS_PORT = int(os.getenv("REDIS_PORT", 6379))
REDIS_USERNAME = os.getenv("REDIS_USERNAME", "default")
REDIS_PASSWORD = os.getenv("REDIS_PASSWORD", "")
REDIS_DB = int(os.getenv("REDIS_DB", 0))

# Create Redis connection
redis_client = Redis(
    host=REDIS_HOST,
    port=REDIS_PORT,
    username=REDIS_USERNAME,
    password=REDIS_PASSWORD,
    db=REDIS_DB,
    decode_responses=True
)

# Token Management Functions
async def store_token_in_redis(user_id: int, token: str, token_type: str):
    """
    Store JWT token in Redis with appropriate TTL
    Args:
        user_id: User ID
        token: JWT token string
        token_type: 'access' or 'refresh'
    """
    key = f"tokens:{user_id}:{token_type}"
    ttl = timedelta(minutes=15) if token_type == "access" else timedelta(days=7)
    try:
        await redis_client.setex(key, int(ttl.total_seconds()), token)
    except Exception as e:
        raise Exception(f"Failed to store token: {str(e)}")

async def get_token_from_redis(user_id: int, token_type: str) -> str:
    """Retrieve token from Redis"""
    key = f"tokens:{user_id}:{token_type}"
    return await redis_client.get(key)

async def delete_token_from_redis(user_id: int, token_type: str):
    """Delete token from Redis"""
    key = f"tokens:{user_id}:{token_type}"
    await redis_client.delete(key)

# Session Management Functions
async def store_user_session(user_id: int, session_id: str, expires_at: datetime):
    """
    Store user session in Redis
    Args:
        user_id: User ID
        session_id: Unique session identifier
        expires_at: Expiration datetime
    """
    session_key = f"sessions:{user_id}:{session_id}"
    session_data = {
        "user_id": user_id,
        "created_at": datetime.now().isoformat(),
        "expires_at": expires_at.isoformat(),
        "is_active": True
    }
    ttl = expires_at - datetime.now()
    try:
        await redis_client.setex(
            session_key,
            int(ttl.total_seconds()),
            json.dumps(session_data))
    except Exception as e:
        raise Exception(f"Failed to store session: {str(e)}")

async def get_user_session(user_id: int, session_id: str) -> dict:
    """Retrieve user session data"""
    session_key = f"sessions:{user_id}:{session_id}"
    session_data = await redis_client.get(session_key)
    return json.loads(session_data) if session_data else None

async def revoke_user_session(user_id: int, session_id: str):
    """Mark session as inactive"""
    session = await get_user_session(user_id, session_id)
    if session:
        session["is_active"] = False
        session_key = f"sessions:{user_id}:{session_id}"
        remaining_ttl = await redis_client.ttl(session_key)
        if remaining_ttl > 0:
            await redis_client.setex(
                session_key,
                remaining_ttl,
                json.dumps(session)
            )

async def delete_user_session(user_id: int, session_id: str):
    """Completely remove session from Redis"""
    session_key = f"sessions:{user_id}:{session_id}"
    await redis_client.delete(session_key)

async def close_redis_connection():
    """Close Redis connection"""
    await redis_client.close()