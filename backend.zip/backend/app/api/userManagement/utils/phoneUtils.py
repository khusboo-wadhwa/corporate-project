import secrets
import logging


def generate_verification_code():
    # Generate a random 6-digit code
    return str(secrets.randbelow(10**6)).zfill(6)
from twilio.rest import Client

def send_sms(to, body):
    # Twilio credentials (replace with your actual values)
#     TWILIO_ACCOUNT_SID=ACee704a653f8c5a562f40e8c12ce33110
# TWILIO_AUTH_TOKEN=47b10a501d9d8215e9ae0a5a9d700edd
# TWILIO_PHONE_NUMBER=+15125807506
    account_sid = 'ACee704a653f8c5a562f40e8c12ce33110'
    auth_token = '47b10a501d9d8215e9ae0a5a9d700edd'
    from_ = '+15125807506'

     # Create Twilio client
    client = Client(account_sid, auth_token)

    try:
        # Send SMS
        message = client.messages.create(
            body=body,
            from_=from_,
            to=to
        )
        return message.sid
    except Exception as e:
        logging.error(f"Error sending SMS: {e}")
        raise Exception(f"Error sending SMS: {e}")

