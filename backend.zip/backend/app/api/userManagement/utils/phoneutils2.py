import random
import datetime

# In-memory storage for OTPs
otp_store = {}

def generate_verification_code(length=6):
    """
    Generate a numeric verification code of the specified length.
    Default length is 6.
    """
    return ''.join(random.choices("0123456789", k=length))


def store_otp(phone_number, otp, expires_in=10):
    """
    Store the OTP with an expiration time.
    Args:
        phone_number (str): The phone number to associate the OTP with.
        otp (str): The OTP code to store.
        expires_in (int): Expiration time in minutes.
    """
    expiration_time = datetime.datetime.utcnow() + datetime.timedelta(minutes=expires_in)
    otp_store[phone_number] = {
        "otp": otp,
        "expires_at": expiration_time
    }


def verify_otp(phone_number, otp):
    """
    Verify the OTP for a given phone number.
    Args:
        phone_number (str): The phone number to check the OTP for.
        otp (str): The OTP code to verify.
    Returns:
        bool: True if the OTP is valid, False otherwise.
    """
    if phone_number not in otp_store:
        return False

    stored_data = otp_store[phone_number]
    if datetime.datetime.utcnow() > stored_data["expires_at"]:
        # OTP expired
        del otp_store[phone_number]
        return False

    if stored_data["otp"] == otp:
        # OTP is valid
        del otp_store[phone_number]
        return True

    # OTP does not match
    return False
