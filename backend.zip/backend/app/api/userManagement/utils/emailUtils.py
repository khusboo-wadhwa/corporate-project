

# import secrets
# from mailjet_rest import Client
# import os
# from fastapi import HTTPException
# import logging

# # Configure logging for error tracking
# logging.basicConfig(level=logging.INFO)

# # Mailjet API credentials (set these in your environment variables)
# MAILJET_API_KEY = "7c2ecaea8265a4b003008dbe1f47f19a"
# MAILJET_API_SECRET = "08c84cb73b3480f3efd41b946a300720"
# Company="Ocean Breeze Hotel"

# mailjet = Client(auth=(MAILJET_API_KEY, MAILJET_API_SECRET), version='v3.1')

# def generate_verification_code() -> str:
#     """
#     Generate a 6-digit random verification code.
#     """
#     return str(secrets.randbelow(10**6)).zfill(6)  # Pads with leading zeros if necessary

# def send_verification_email(to_email: str, verification_code: str, email_type: str = "verification"):
#     """
#     Send a verification or password reset email with the given code to the specified email address.
    
#     :param to_email: The recipient's email address
#     :param verification_code: The verification code to be included in the email
#     :param email_type: The type of email ('verification' for first-time verification or 'forgot_password' for password reset)
#     :raises HTTPException: If the email sending fails
#     """
#     # Determine the email subject and body based on the email type
#     if email_type == "forgot_password":
#         subject = "Password Reset Request"
#         text_body = f"Your password reset code is: {verification_code}"
#         html_body = f"<h3>Your password reset code is: <b>{verification_code}</b></h3>"
#     else:
#         subject = "Your Email Verification Code"
#         text_body = f"Your email verification code is: {verification_code}"
#         html_body = f"<h3>Your email verification code is: <b>{verification_code}</b></h3>"

#     # Prepare the email data
#     data = {
#         'Messages': [
#             {
#                 "From": {
#                     "Email": "rohit.pawar@rgs-tech.com",  # Update with your sender email
#                     "Name": "RGS-Tech"  # Update with your app's name
#                 },
#                 "To": [
#                     {
#                         "Email": to_email,
#                         "Name": "User"  # Optionally, include the recipient's name
#                     }
#                 ],
#                 "Subject": subject,
#                 "TextPart": text_body,
#                 "HTMLPart": html_body
#             }
#         ]
#     }

#     try:
#         # Send the email using Mailjet's API
#         result = mailjet.send.create(data=data)
#         if result.status_code == 200:
#             logging.info("Email sent successfully!")
#         else:
#             logging.error(f"Failed to send email: {result.status_code}, {result.json()}")
#             raise HTTPException(
#                 status_code=500,
#                 detail=f"Failed to send email: {result.status_code}, {result.json()}"
#             )
#         return result
#     except Exception as e:
#         logging.error(f"Error while sending email: {e}")
#         raise HTTPException(status_code=500, detail=f"Error while sending email: {e}")


# #forgetpassword for non admin request mail to admin
# # Function to send email via Mailjet
# async def send_email_forgetpass_non_admin(from_email: str, to_email: str, subject: str, body: str):
#     try:
#         # Initialize Mailjet client
#         mailjet = Client(auth=(MAILJET_API_KEY, MAILJET_API_SECRET), version='v3.1')

#         # Create the email payload
#         data = {
#             'Messages': [
#                 {
#                     "From": {
#                         "Email": "rohit.pawar@rgs-tech.com",
#                         "Name": "User"
#                     },
#                     "To": [
#                         {
#                             "Email": to_email,
#                             "Name": "Admin"
#                         }
#                     ],
#                     "Subject": subject,
#                     "TextPart": body
#                 }
#             ]
#         }

#         # Send the email
#         result = mailjet.send.create(data=data)

#         if result.status_code != 200:
#             logging.error(f"Failed to send email via Mailjet: {result.status_code}, {result.json()}")
#             raise HTTPException(status_code=500, detail="Failed to send email")

#         logging.info(f"Email sent to {to_email} via Mailjet")
#     except Exception as e:
#         logging.error(f"Error in sending email via Mailjet: {e}")
#         raise HTTPException(status_code=500, detail="Error in sending email")



# async def send_email_notification(to_email: str, subject: str, user_name: str, email: str, mobile_number: str, role: str, from_email: str = "vaishnavi.bhambure@rgs-tech.com"):
#     """
#     Sends a formatted email notification using Mailjet.
#     Args:
#         to_email (str): Recipient's email address.
#         subject (str): Subject of the email.
#         user_name (str): Name of the user to be included in the email.
#         email (str): The updated email of the user.
#         mobile_number (str): The updated mobile number of the user.
#         role (str): The updated role of the user.
#         from_email (str): Sender's email address (default is set).
#     """
#     mailjet = Client(auth=(MAILJET_API_KEY, MAILJET_API_SECRET), version="v3.1")

#     # HTML email content with placeholders for dynamic values
#     html_content = f"""
#     <html>
#       <body style="font-family: Arial, sans-serif; color: #333;">
#         <div style="max-width: 600px; margin: 0 auto; padding: 20px; background-color: #f9f9f9; border-radius: 8px;">
#           <h2 style="color: #007bff;">Hello, {user_name}</h2>
#           <p style="font-size: 16px;">Your account information has been successfully updated. Please review the details below:</p>

#           <ul style="list-style-type: none; padding-left: 0;">
#             <li><strong>Email:</strong> {email}</li>
#             <li><strong>Phone Number:</strong> {mobile_number}</li>
#             <li><strong>Role:</strong> {role}</li>
#           </ul>

#           <p style="font-size: 16px; color: #333;">If you didn't request this change, please contact your admin immediately.</p>
          
#           <p style="font-size: 14px; color: #888;">Thank you for being a part of our community!</p>
          
#           <div style="border-top: 1px solid #ccc; margin-top: 20px; padding-top: 10px; text-align: center; color: #888;">
#             <p>If you have any questions or need assistance, feel free to contact our support team.</p>
#           </div>
#         </div>
#       </body>
#     </html>
#     """

#     data = {
#         "Messages": [
#             {
#                 "From": {
#                     "Email": from_email,
#                     "Name": "RGS-TECH"
#                 },
#                 "To": [
#                     {
#                         "Email": to_email,
#                         "Name": user_name
#                     }
#                 ],
#                 "Subject": subject,
#                 "HtmlPart": html_content,
#             }
#         ]
#     }

#     try:
#         result = mailjet.send.create(data=data)
#         if result.status_code != 200:
#             raise Exception(f"Failed to send email: {result.json()}")
#         print(f"Email successfully sent to {to_email}")
#     except Exception as e:
#         print(f"Error while sending email to {to_email}: {e}")
#         raise


# def send_user_creation_email(to_email: str, user_details: dict):
#     """
#     Sends an email to the newly created user with their details and instructions to change the password.

#     :param to_email: Email address of the recipient
#     :param user_details: Dictionary containing user details
#     """
#     # Define email content
#     subject = f"Welcome to {Company}! Account Created Successfully"
#     html_content = f"""
#     <html>
#     <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333;">
#         <h1 style="color: #0073e6;">Welcome to {Company}!</h1>
#         <p>Hi {user_details['first_name']},</p>
#         <p>Your account has been successfully created by the administrator. Here are your account details:</p>
#         <table style="border-collapse: collapse; width: 100%; margin: 20px 0;">
#             <tr>
#                 <td style="border: 1px solid #ddd; padding: 8px;">Name:</td>
#                 <td style="border: 1px solid #ddd; padding: 8px;">{user_details['first_name']} {user_details['last_name']}</td>
#             </tr>
#             <tr>
#                 <td style="border: 1px solid #ddd; padding: 8px;">Email:</td>
#                 <td style="border: 1px solid #ddd; padding: 8px;">{user_details['email']}</td>
#             </tr>
#             <tr>
#                 <td style="border: 1px solid #ddd; padding: 8px;">Username:</td>
#                 <td style="border: 1px solid #ddd; padding: 8px;">{user_details['username']}</td>
#             </tr>
#             <tr>
#                 <td style="border: 1px solid #ddd; padding: 8px;">Mobile Number:</td>
#                 <td style="border: 1px solid #ddd; padding: 8px;">{user_details['country_code']} {user_details['mobile_number']}</td>
#             </tr>
#         </table>
#         <p>Your initial password is: <strong>{user_details['password']}</strong></p>
#         <p>
#             For security reasons, we strongly recommend you 
#             <a href="[Your App Link to Change Password]" style="color: #0073e6;">change your password</a> immediately after logging in.
#         </p>
#         <p>Thank you,<br>{Company} Team</p>
#     </body>
#     </html>
#     """

#     # Email payload
#     data = {
#         'Messages': [
#             {
#                 "From": {
#                     "Email": "rohit.pawar@rgs-tech.com",
#                     "Name": "RGS_TECH"
#                 },
#                 "To": [
#                     {
#                         "Email": to_email,
#                         "Name": user_details['first_name']
#                     }
#                 ],
#                 "Subject": subject,
#                 "HTMLPart": html_content
#             }
#         ]
#     }

#     # Send the email
#     try:
#         result = mailjet.send.create(data=data)
#         if result.status_code != 200 and result.status_code != 201:
#             raise Exception(f"Failed to send email. Status code: {result.status_code}, Message: {result.text}")
#     except Exception as e:
#         raise Exception(f"Error sending email: {str(e)}")


import secrets
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from fastapi import HTTPException
import logging

# Configure logging for error tracking
logging.basicConfig(level=logging.INFO)

# SMTP server configuration
SMTP_SERVER = "smtp.gmail.com"  # Change this to your SMTP server
SMTP_PORT = 587  # Change this to your SMTP port
SMTP_USERNAME = "rohukale94458@gmail.com"  # Your email username
SMTP_PASSWORD = "fana viuw bscc enoq"  # Your email password
Company = "Rhombus Global Services"

def generate_verification_code() -> str:
    """
    Generate a 6-digit random verification code.
    """
    return str(secrets.randbelow(10**6)).zfill(6)  # Pads with leading zeros if necessary

def send_verification_email(to_email: str, verification_code: str, email_type: str = "verification"):
    """
    Send a verification or password reset email with the given code to the specified email address.
    
    :param to_email: The recipient's email address
    :param verification_code: The verification code to be included in the email
    :param email_type: The type of email ('verification' for first-time verification or 'forgot_password' for password reset)
    :raises HTTPException: If the email sending fails
    """
    # Determine the email subject and body based on the email type
    if email_type == "forgot_password":
        subject = "Password Reset Request"
        text_body = f"Your password reset code is: {verification_code}"
        html_body = f"<h3>Your password reset code is: <b>{verification_code}</b></h3>"
    else:
        subject = "Your Email Verification Code"
        text_body = f"Your email verification code is: {verification_code}"
        html_body = f"<h3>Your email verification code is: <b>{verification_code}</b></h3>"

    # Create message container
    msg = MIMEMultipart('alternative')
    msg['Subject'] = subject
    msg['From'] = "rohukale94458@gmail.com"
    msg['To'] = to_email

    # Record the MIME types of both parts - text/plain and text/html
    part1 = MIMEText(text_body, 'plain')
    part2 = MIMEText(html_body, 'html')

    # Attach parts into message container
    msg.attach(part1)
    msg.attach(part2)

    try:
        # Send the message via SMTP server
        with smtplib.SMTP(SMTP_SERVER, SMTP_PORT) as server:
            server.starttls()
            server.login(SMTP_USERNAME, SMTP_PASSWORD)
            server.send_message(msg)
            logging.info("Email sent successfully!")
    except Exception as e:
        logging.error(f"Error while sending email: {e}")
        raise HTTPException(status_code=500, detail=f"Error while sending email: {e}")

async def send_email_forgetpass_non_admin(from_email: str, to_email: str, subject: str, body: str):
    try:
        # Create message container
        msg = MIMEMultipart()
        msg['Subject'] = subject
        msg['From'] = "rohukale94458@gmail.com"
        msg['To'] = to_email

        # Add body to email
        msg.attach(MIMEText(body, 'plain'))

        # Send the message via SMTP server
        with smtplib.SMTP(SMTP_SERVER, SMTP_PORT) as server:
            server.starttls()
            server.login(SMTP_USERNAME, SMTP_PASSWORD)
            server.send_message(msg)
            logging.info(f"Email sent to {to_email} via SMTP")

    except Exception as e:
        logging.error(f"Error in sending email via SMTP: {e}")
        raise HTTPException(status_code=500, detail="Error in sending email")

async def send_email_notification(to_email: str, subject: str, user_name: str, email: str, mobile_number: str, role: str, from_email: str = "vaishnavi.bhambure@rgs-tech.com"):
    """
    Sends a formatted email notification using SMTP.
    """
    # HTML email content with placeholders for dynamic values
    html_content = f"""
    <html>
      <body style="font-family: Arial, sans-serif; color: #333;">
        <div style="max-width: 600px; margin: 0 auto; padding: 20px; background-color: #f9f9f9; border-radius: 8px;">
          <h2 style="color: #007bff;">Hello, {user_name}</h2>
          <p style="font-size: 16px;">Your account information has been successfully updated. Please review the details below:</p>

          <ul style="list-style-type: none; padding-left: 0;">
            <li><strong>Email:</strong> {email}</li>
            <li><strong>Phone Number:</strong> {mobile_number}</li>
            <li><strong>Role:</strong> {role}</li>
          </ul>

          <p style="font-size: 16px; color: #333;">If you didn't request this change, please contact your admin immediately.</p>
          
          <p style="font-size: 14px; color: #888;">Thank you for being a part of our community!</p>
          
          <div style="border-top: 1px solid #ccc; margin-top: 20px; padding-top: 10px; text-align: center; color: #888;">
            <p>If you have any questions or need assistance, feel free to contact our support team.</p>
          </div>
        </div>
      </body>
    </html>
    """

    # Create message container
    msg = MIMEMultipart('alternative')
    msg['Subject'] = subject
    msg['From'] = from_email
    msg['To'] = to_email

    # Record the MIME types of both parts - text/plain and text/html
    part1 = MIMEText(html_content, 'html')

    # Attach parts into message container
    msg.attach(part1)

    try:
        # Send the message via SMTP server
        with smtplib.SMTP(SMTP_SERVER, SMTP_PORT) as server:
            server.starttls()
            server.login(SMTP_USERNAME, SMTP_PASSWORD)
            server.send_message(msg)
            print(f"Email successfully sent to {to_email}")
    except Exception as e:
        print(f"Error while sending email to {to_email}: {e}")
        raise

def send_user_creation_email(to_email: str, user_details: dict):
    """
    Sends an email to the newly created user with their details and instructions to change the password.
    """
    # Define email content
    subject = f"Welcome to {Company}! Account Created Successfully"
    html_content = f"""
    <html>
    <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333;">
        <h1 style="color: #0073e6;">Welcome to {Company}!</h1>
        <p>Hi {user_details['first_name']},</p>
        <p>Your account has been successfully created by the administrator. Here are your account details:</p>
        <table style="border-collapse: collapse; width: 100%; margin: 20px 0;">
            <tr>
                <td style="border: 1px solid #ddd; padding: 8px;">Name:</td>
                <td style="border: 1px solid #ddd; padding: 8px;">{user_details['first_name']} {user_details['last_name']}</td>
            </tr>
            <tr>
                <td style="border: 1px solid #ddd; padding: 8px;">Email:</td>
                <td style="border: 1px solid #ddd; padding: 8px;">{user_details['email']}</td>
            </tr>
            <tr>
                <td style="border: 1px solid #ddd; padding: 8px;">Username:</td>
                <td style="border: 1px solid #ddd; padding: 8px;">{user_details['username']}</td>
            </tr>
            <tr>
                <td style="border: 1px solid #ddd; padding: 8px;">Mobile Number:</td>
                <td style="border: 1px solid #ddd; padding: 8px;">{user_details['country_code']} {user_details['mobile_number']}</td>
            </tr>
        </table>
        <p>Your initial password is: <strong>{user_details['password']}</strong></p>
        <p>
            For security reasons, we strongly recommend you 
            <a href="[Your App Link to Change Password]" style="color: #0073e6;">change your password</a> immediately after logging in.
        </p>
        <p>Thank you,<br>{Company} Team</p>
    </body>
    </html>
    """

    # Create message container
    msg = MIMEMultipart('alternative')
    msg['Subject'] = subject
    msg['From'] = "rohukale94458@gmail.com"
    msg['To'] = to_email

    # Record the MIME types of both parts - text/plain and text/html
    part1 = MIMEText(html_content, 'html')

    # Attach parts into message container
    msg.attach(part1)

    try:
        # Send the message via SMTP server
        with smtplib.SMTP(SMTP_SERVER, SMTP_PORT) as server:
            server.starttls()
            server.login(SMTP_USERNAME, SMTP_PASSWORD)
            server.send_message(msg)
    except Exception as e:
        raise Exception(f"Error sending email: {str(e)}")
    


def send_admin_registration_email(to_email: str, first_name: str, verification_code: str):
    """
    Sends a welcome email to the newly registered admin including verification code
    and first login instructions.
    """
    subject = f"Welcome to {Company} - Complete Your Registration"

    html_content = f"""
    <html>
    <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333;">
        <h1 style="color: #0073e6;">Welcome to {Company}, {first_name}!</h1>
        <p>Thank you for registering as an admin with us.</p>
        
        <h2 style="color: #0073e6;">Your Email Verification Code:</h2>
        <p style="font-size: 20px; font-weight: bold;">{verification_code}</p>
        
        <p>Please verify your email address using the above code to activate your account.</p>

        <h3 style="color: #0073e6;">First Login Instructions:</h3>
        <p>After your first login, please make sure to <strong>register your property</strong> to get started with our platform.</p>
        <p>Having your property details registered ensures you can fully access and manage all services without interruptions.</p>
        
        <p>If you have any questions or need assistance, feel free to reach out to our support team.</p>

        <p>Thank you,<br>{Company} Team</p>
    </body>
    </html>
    """

    # Create message container
    msg = MIMEMultipart('alternative')
    msg['Subject'] = subject
    msg['From'] = SMTP_USERNAME
    msg['To'] = to_email

    # Attach parts into message container
    part1 = MIMEText(html_content, 'html')
    msg.attach(part1)

    try:
        with smtplib.SMTP(SMTP_SERVER, SMTP_PORT) as server:
            server.starttls()
            server.login(SMTP_USERNAME, SMTP_PASSWORD)
            server.send_message(msg)
        logging.info(f"Admin registration email sent to {to_email}")
    except Exception as e:
        logging.error(f"Failed to send admin registration email to {to_email}: {e}")
        raise HTTPException(status_code=500, detail="Failed to send registration email")




def send_2fa_email(to_email: str, first_name: str, otp: str):
    """
    Sends a Two-Factor Authentication (2FA) email with an OTP for verifying the hotel staff's login attempt.
    """
    subject = f"Your Hotel Staff Two-Factor Authentication Code"

    html_content = f"""
    <html>
    <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333;">
        <h1 style="color: #0073e6;">Hello, {first_name}!</h1>
        <p>We received a request to log in to your account. Please enter the code below to complete your login:</p>
        
        <h2 style="color: #0073e6;">Your One-Time Password (OTP):</h2>
        <p style="font-size: 20px; font-weight: bold;">{otp}</p>
        
        <p>This code is valid for a short period of time, so please enter it as soon as possible to complete your login.</p>

        <p>If you did not request this login or if you believe someone is attempting to access your account, please contact to {Company} team immediately.</a> for assistance. Our support team is here to help!</p>

        <p>Thank you :) </p>
    </body>
    </html>
    """

    # Create message container
    msg = MIMEMultipart('alternative')
    msg['Subject'] = subject
    msg['From'] = SMTP_USERNAME
    msg['To'] = to_email

    # Attach parts into message container
    part1 = MIMEText(html_content, 'html')
    msg.attach(part1)

    try:
        with smtplib.SMTP(SMTP_SERVER, SMTP_PORT) as server:
            server.starttls()
            server.login(SMTP_USERNAME, SMTP_PASSWORD)
            server.send_message(msg)
        logging.info(f"2FA email sent to {to_email}")
    except Exception as e:
        logging.error(f"Failed to send 2FA email to {to_email}: {e}")
        raise HTTPException(status_code=500, detail="Failed to send 2FA email")
