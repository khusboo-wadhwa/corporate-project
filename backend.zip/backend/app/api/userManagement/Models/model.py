from sqlalchemy import Column, Integer, String, Boolean, Text, TIMESTAMP, ARRAY
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
from datetime import datetime

Base = declarative_base()

class User(Base):
    __tablename__ = 'users'

    # Columns for the users table
    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String, nullable=False)
    username = Column(String, unique=True, nullable=False)
    email = Column(String, unique=True, nullable=False)
    password = Column(String, nullable=False)
    role = Column(ARRAY(Text), nullable=False)  # Role is an array of text
    created_at = Column(TIMESTAMP(timezone=True), default=datetime.utcnow)
    last_password_reset_date = Column(TIMESTAMP(timezone=True), nullable=True)
    is_verified = Column(Boolean, default=False)
    verification_code = Column(String, unique=True, nullable=True)
    verification_code_sent_at = Column(TIMESTAMP(timezone=True), nullable=True)
    verification_code_expires_at = Column(TIMESTAMP(timezone=True), nullable=True)
    company_name = Column(String, nullable=True)
    reset_password_token = Column(String, unique=True, nullable=True)
    reset_password_token_expiry = Column(TIMESTAMP(timezone=True), nullable=True)
    is_admin = Column(Boolean, default=False)

    def __repr__(self):
        return f"<User(name={self.name}, username={self.username}, email={self.email}, role={self.role}, is_admin={self.is_admin})>"


