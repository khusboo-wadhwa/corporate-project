from firebase_admin import auth
from prisma import Prisma
from app.core.auth import create_user_and_register_in_db,login_user,create_user_in_db
from app.core.firebase import verify_admin_claim
client = Prisma()

async def login_user(email: str, password: str) -> dict:
    user = auth.get_user_by_email(email)
    if verify_admin_claim(email):
        return {"is_admin": True}
    return {"is_admin": False}

async def create_user(name: str, username: str, email: str, password: str, is_admin: bool, role: str):
    # Pass all required parameters including role
    firebase_uid = await create_user_and_register_in_db(
        name=name, 
        username=username, 
        email=email, 
        password=password, 
        is_admin=is_admin, 
        role=role  # Adding role parameter
    )
    return firebase_uid  # You can return the firebase_uid or the result as needed
