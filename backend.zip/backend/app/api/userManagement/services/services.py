from mailjet_rest import Client
from app.core.auth import create_access_token, create_session_token

# Mailjet configuration
MAILJET_API_KEY = 'f0c06e424b927d916390ad0d5d382f49' #'f0c06e424b927d916390ad0d5d382f49'
MAILJET_API_SECRET = '767b41930bd69cc978b495c19405cbc9' #'487511c15d7ec2c6fedc33f64872f983'

mailjet = Client(auth=(MAILJET_API_KEY, MAILJET_API_SECRET), version='v3.1')

verification_codes = {}


def send_verification_email(email_id: str, code: str):
    data = {
        'Messages': [
            {
                "From": {"Email": "ketakidesale17@gmail.com", "Name": "Your Name"},
                "To": [{"Email": email_id}],
                "Subject": "Your Verification Code",
                "TextPart": f"Your verification code is: {code}",
                "HTMLPart": f"<h3>Your verification code is: <strong>{code}</strong></h3>",
            }
        ]
    }
    result = mailjet.send.create(data=data)
    if result.status_code != 200:
        raise Exception("Failed to send verification email")
