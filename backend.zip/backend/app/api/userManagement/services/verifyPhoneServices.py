from fastapi import APIRouter, HTTPException, status, Depends
from pydantic import BaseModel
from datetime import datetime, timezone, timedelta
from prisma import Prisma
from app.core.firebase import verify_firebase_token  # Adjust the import based on your structure

class PhoneTokenInput(BaseModel):
    id_token: str
    
prisma=Prisma()
router = APIRouter()

async def get_user_by_mobile(country_code: str, mobile_number: int):
    try:
        # Fetch the user based on country_code and mobile_number
        user = await prisma.users1.find_first(
            where={
                "country_code": country_code,
                "mobile_number": mobile_number  # Updated to match schema
            }
        )
        return user
    except Exception as e:
        print(f"Error fetching user by mobile: {str(e)}")
        return None
async def update_user_verification_status(user_id: int):
    try:
        # Update the user verification status
        updated_user = await prisma.users1.update(
            where={"id": user_id},
            data={
                "is_phone_verified": True,  # Set phone verified status to True
                "phone_verification_code": None,  # Remove the verification code
                "phone_verification_code_expires_at": None  # Clear the expiration date
            }
        )
        return updated_user
    except Exception as e:
        print(f"Error updating user verification status: {str(e)}")
        return None
    


class PhoneTokenInput(BaseModel):
    id_token: str


@router.post("/verify-phone-firebase")
async def verify_phone_via_firebase(input: PhoneTokenInput):
    try:
        # Step 1: Verify the token with Firebase
        phone_number = await verify_firebase_token(input.id_token)
        if not phone_number or len(phone_number) != 10:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid phone number from token")

        # Step 2: Try finding the user with this mobile (assuming +91)
        user = await get_user_by_mobile("+91", int(phone_number))
        if not user:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User not found")

        # Step 3: Update user's verification status
        updated_user = await update_user_verification_status(user["id"])
        if not updated_user:
            raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Failed to update verification")

        return {"message": "Phone verification successful", "user_id": user["id"]}

    except Exception as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))
