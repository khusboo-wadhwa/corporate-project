from app.core.database import get_prisma_client  # Import the connection logic
from datetime import datetime
from app.api.userManagement.schemas.userSchema import UserCreate
import bcrypt  # For password hashing

async def register_admin(user: UserCreate):
    try:
        # Get the Prisma client, ensuring it is connected
        client = await get_prisma_client()

        # Hash the password before saving it (ensure bcrypt is installed)
        hashed_password = bcrypt.hashpw(user.password.encode('utf-8'), bcrypt.gensalt()) if user.password else None

        # Create the admin user in the database
        new_user = await client.aq_users.create(
            data={
                "first_name": user.first_name,
                "last_name": user.last_name,
                "username": user.username,
                "email": user.email,
                "mobile_number": user.mobile_number,
                "password": hashed_password,  # Store the hashed password
                "role": ["Admin"],  # Admin role
                "created_at": datetime.now(),
                "is_admin": True,  # Set is_admin to True
                "first_login": user.first_login,  # Include first login if it's part of the schema
                "company_name": user.company_name,  # Add company name if provided
                "country_code": user.country_code,  # Add country code if provided
            }
        )

        return new_user
    except Exception as e:
        raise Exception(f"Error creating admin: {e}")
