from pydantic import BaseModel


class UserLogin(BaseModel):
    email_id: str
    password: str


class VerificationCode(BaseModel):
    email_id: str
    code: str


class RoleAccessVerification(BaseModel):
    email_id: str
    access_token: str
    session_token: str
    role: str


class UserRegistration(BaseModel):
    first_name: str
    last_name: str
    email_id: str
    password: str
    role: str
