# /app/schemas/user_schema.py
from pydantic import BaseModel,EmailStr,Field
from typing import List, Optional
from fastapi import Query
from datetime import datetime


class UserCreate(BaseModel):
    first_name: str
    last_name: str
    username: str
    mobile_number: Optional[int] = Field(None, description="User's mobile number")
    email: EmailStr
    password: str
    country_code: Optional[str] = Field(None, description="User's country code")
    company_name: Optional[str] = Field("Rgs-tech", description="User's company name")  # Default to "Rgs-tech"
    first_login: Optional[bool] = Field(True, description="Indicates if it's the user's first login")  # Default to True if not provided

    
class LoginRequest(BaseModel):
    email: EmailStr
    password: str


class RegisterUserRequest(BaseModel):
    first_name: str
    last_name: str
    username: str
    email: str
    country_code: str
    mobile_number: int
    password: str
    role: List[str] = Query(..., description="Role of the user (cannot include 'admin')")
    admin_email: str  # <- required field
    firebase_id_token: Optional[str] = None

    
class RegisterUserResponse(BaseModel):
    id: int
    email: EmailStr
    is_admin: bool

# Model for the user verification request
class VerificationRequest(BaseModel):
    mobile_number: int  # Changed to match BigInt
    country_code: str
    verification_code: str



# Schema definitions
class ForgotPasswordRequest(BaseModel):
    email: str

class OTPVerificationRequest(BaseModel):
    email: str
    verification_code: str

class ResetPasswordRequest(BaseModel):
    email: str
    new_password: str
    confirm_password: str

#change password in account 
class ChangePasswordRequest(BaseModel):
    email: EmailStr
    current_password: str
    new_password: str
    confirm_password: str

# In userSchema.py
class RoleRequestPayload(BaseModel):
    requested_permission_id: int
    reason: str
    current_role: str  # Add current role field

# Keep the same for accept/reject
class RoleRequestUpdatePayload(BaseModel):
    admin_comment: Optional[str] = Field(None, description="Optional comment from admin")

# Define the schema for the request payload
class EditUserRequest(BaseModel):
    email: Optional[str]=None
    mobile_number: Optional[str] = None  # Phone number as a string, optional
    role: Optional[List[str]] = None  # Roles should match your UserRoleEnum




# Pydantic schema for hotel_basics model
class HotelBasics(BaseModel):
    city: str
    name: str
    address: str
    phone: Optional[str]
    email: Optional[str]
    location: Optional[str]


#to craete role and assign permissions to the role
class RoleCreate(BaseModel):
    role_name: str
    description: Optional[str]

class PermissionAssign(BaseModel):
    permission_ids: List[int]

class GetRole(BaseModel):
    id: int  # Include role_id
    role_name: str
    description: str | None
    created_at: str | None
    

    class Config:
        orm_mode = True

class GetPermission(BaseModel):
    id: int
    permission_name: str
    description: Optional[str]
    created_at: Optional[datetime]
    parent_id: Optional[int] = None
    permission_type: Optional[str] = "page"
    route_path: Optional[str] = None

class CreatePermission(BaseModel):
    permission_name: str
    description: Optional[str] = None
    parent_id: Optional[int] = None
    permission_type: Optional[str] = "page"
    route_path: Optional[str] = None
    
class RoleUpdate(BaseModel):
    role_name: str
    description: Optional[str] = None