# from fastapi import APIRouter, HTTPException, Depends, status
# from prisma import Prisma
# from app.core.database import get_prisma_client
# from app.core.auth import get_current_user
# from firebase_admin import auth  # Import Firebase auth module

# router = APIRouter()

# @router.delete("/deleteUser", status_code=status.HTTP_200_OK)
# async def delete_user(
#     user_id: int,  # The ID of the user to delete
#     current_user: dict = Depends(get_current_user),  # Get the current authenticated user
#     prisma: Prisma = Depends(get_prisma_client)  # Inject Prisma client here
# ):
#     """
#     Allow admins to delete a user from the database, including deleting related role requests.
#     Prevent deletion of admin users. Also deletes the user's email from Firebase.
#     """
#     # Ensure the current user is an admin
#     if not current_user.is_admin:
#         raise HTTPException(
#             status_code=403,
#             detail="Only admins can delete users."
#         )

#     # Fetch the user from the database
#     user = await prisma.users1.find_unique(where={"id": user_id})
#     if not user:
#         raise HTTPException(
#             status_code=404,
#             detail="User not found."
#         )

#     # Check if the user to be deleted is an admin
#     if user.is_admin:
#         raise HTTPException(
#             status_code=400,
#             detail="Admin users cannot be deleted."
#         )

#     # Delete the user's email from Firebase
#     if user.email:  # Ensure the user has an email stored
#         try:
#             # Get the Firebase user by email
#             firebase_user = auth.get_user_by_email(user.email)
#             # Delete the Firebase user
#             auth.delete_user(firebase_user.uid)
#         except auth.UserNotFoundError:
#             # If the user does not exist in Firebase, log it but do not block
#             pass
#         except Exception as e:
#             raise HTTPException(
#                 status_code=500,
#                 detail=f"Error deleting user from Firebase: {str(e)}"
#             )

#     # Delete the user's related role requests first
#     try:
#         await prisma.rolerequest.delete_many(where={"user_id": user_id})
#     except Exception as e:
#         raise HTTPException(
#             status_code=500,
#             detail=f"Error deleting related role requests: {str(e)}"
#         )

#     # Try deleting the user from the database
#     try:
#         await prisma.users1.delete(where={"id": user_id})
#     except Exception as e:
#         raise HTTPException(
#             status_code=500,
#             detail=f"Error deleting user: {str(e)}"
#         )

#     return {
#         "success": True,
#         "details": f"User with ID {user_id} and related data has been successfully deleted."
#     }



#websocket  and logs
from fastapi import APIRouter, HTTPException, Depends, status, Request
from prisma import Prisma
from app.core.database import get_prisma_client
from app.core.auth import get_current_user
from firebase_admin import auth  # Import Firebase auth module
from app.api.userManagement.utils.wsUtils import broadcast_message  # Import WebSocket utility

router = APIRouter()

@router.delete("/deleteUser", status_code=status.HTTP_200_OK)
async def delete_user(
    user_id: int,request: Request ,  # The ID of the user to delete
    current_user: dict = Depends(get_current_user),  # Get the current authenticated user
    prisma: Prisma = Depends(get_prisma_client)  # Inject Prisma client here
     # Access the request object to get the logger
):
    """
    Allow admins to delete a user from the database, including deleting related role requests.
    Prevent deletion of admin users. Also deletes the user's email from Firebase.
    """
    logger = request.state.logger  # Access the logger from request.state
    logger.info(f"Admin {current_user.username} is attempting to delete user with ID {user_id}.")

    # Ensure the current user is an admin
    if not current_user.is_admin:
        logger.warning(f"Non-admin user {current_user.username} tried to delete user with ID {user_id}.")
        raise HTTPException(
            status_code=403,
            detail="Only admins can delete users."
        )

    # Fetch the user from the database
    user = await prisma.aq_users.find_unique(where={"id": user_id})
    if not user:
        logger.error(f"User with ID {user_id} not found.")
        raise HTTPException(
            status_code=404,
            detail="User not found."
        )

    # Check if the user to be deleted is an admin
    if user.is_admin:
        logger.warning(f"Attempt to delete admin user with ID {user_id}.")
        raise HTTPException(
            status_code=400,
            detail="Admin users cannot be deleted."
        )

    # Delete the user's email from Firebase
    if user.email:  # Ensure the user has an email stored
        try:
            # Get the Firebase user by email
            firebase_user = auth.get_user_by_email(user.email)
            # Delete the Firebase user
            auth.delete_user(firebase_user.uid)
            logger.info(f"Successfully deleted user {user.email} from Firebase.")
        except auth.UserNotFoundError:
            # If the user does not exist in Firebase, log it but do not block
            logger.warning(f"Firebase user with email {user.email} not found, skipping deletion.")
        except Exception as e:
            logger.error(f"Error deleting user from Firebase: {str(e)}")
            raise HTTPException(
                status_code=500,
                detail=f"Error deleting user from Firebase: {str(e)}"
            )

    # Delete the user's related role requests first
    try:
        await prisma.aq_rolerequests.delete_many(where={"user_id": user_id})
        logger.info(f"Successfully deleted related role requests for user with ID {user_id}.")
    except Exception as e:
        logger.error(f"Error deleting related role requests for user with ID {user_id}: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail=f"Error deleting related role requests: {str(e)}"
        )

    # Try deleting the user from the database
    try:
        await prisma.aq_users.delete(where={"id": user_id})
        logger.info(f"Successfully deleted user with ID {user_id} from the database.")
    except Exception as e:
        logger.error(f"Error deleting user with ID {user_id}: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail=f"Error deleting user: {str(e)}"
        )

    # Broadcast the user deletion event to connected WebSocket clients
    try:
        broadcast_message_content = f"User with ID {user_id} has been deleted."
        await broadcast_message(broadcast_message_content)
        logger.info(f"Broadcasted message: {broadcast_message_content}")
    except Exception as e:
        logger.error(f"Error broadcasting message: {str(e)}")

    return {
        "success": True,
        "details": f"User with ID {user_id} and related data has been successfully deleted."
    }
