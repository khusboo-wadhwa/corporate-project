from fastapi import APIRouter, HTTPException, status
from pydantic import BaseModel
from app.core.database import get_prisma_client

router = APIRouter()

class Toggle2FARequest(BaseModel):
    email: str
    enable: bool

@router.post("/toggle-2fa", status_code=status.HTTP_200_OK)
async def toggle_two_factor_auth(request: Toggle2FARequest):

    prisma = await get_prisma_client()
    # 1. Find the user by email
    user = await prisma.aq_users.find_unique(
        where={"email": request.email}
    )

    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found"
        )

    # 2. Check if verification record exists
    verification = await prisma.aq_user_verification.find_unique(
        where={"user_id": user.id}
    )

    if verification:
        # 3a. Update existing verification record
        await prisma.aq_user_verification.update(
            where={"user_id": user.id},
            data={"mfa_enabled": request.enable}
        )
    else:
        # 3b. Create new verification record
        await prisma.aq_user_verification.create(
            data={
                "user_id": user.id,
                "is_phone_verified": False,
                "is_email_verified": False,
                "mfa_enabled": request.enable,
            }
        )

    # 4. Return success
    return {
        "status": "success",
        "mfa_enabled": request.enable
    }



@router.get("/get-2fa-status/{email}", status_code=status.HTTP_200_OK)
async def get_two_factor_status(email: str):
    prisma = await get_prisma_client()

    # 1. Find the user by email
    user = await prisma.aq_users.find_unique(
        where={"email": email}
    )

    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found"
        )

    # 2. Check if verification record exists
    verification = await prisma.aq_user_verification.find_unique(
        where={"user_id": user.id}
    )

    if not verification:
        return {
            "status": "success",
            "mfa_enabled": False  # Default if record not found
        }

    return {
        "status": "success",
        "mfa_enabled": verification.mfa_enabled
    }
