""" This api works after user(non admin) request from is made  
this api send temporary password to the user who made request 
input-user email and admin email so temporary password will send on the email
that temporary pasword should enter will email in the login routes """
# from fastapi import FastAPI, HTTPException, Depends, APIRouter
# from pydantic import BaseModel, EmailStr
# from app.core.database import get_prisma_client
# import secrets
# from app.api.userManagement.utils.emailUtils import send_email_forgetpass_non_admin
# from app.api.userManagement.utils.passwordUtils import hash_password


# # Initialize FastAPI app
# router = APIRouter()

# class ResetPasswordRequest(BaseModel):
#     email: EmailStr
#     admin_email: EmailStr
    

# # Reset password endpoint
# @router.post("/resetPasswordNonaAdmin")
# async def reset_password(request: ResetPasswordRequest, prisma=Depends(get_prisma_client)):
#     # Fetch the user from the database
#     user = await prisma.aq_users.find_first(where={"email": request.email})

#     if not user:
#         raise HTTPException(status_code=404, detail="User not found")

#     # Verify admin email
#     admin_user = await prisma.aq_users.find_first(where={"email": request.admin_email, "is_admin": True})
#     if not admin_user:
#         raise HTTPException(status_code=403, detail="Invalid admin email")

#     # Generate a one-time password
#     one_time_password = secrets.token_urlsafe(8)

#     # Hash the temporary password before storing it
#     hashed_temp_password = hash_password(one_time_password)

#     # Update the user's temp_password field with the hashed one-time password
#     await prisma.aq_users.update(
#         where={"email": user.email},
#         data={"temp_password": hashed_temp_password}
#     )

#     # Prepare the email for the user
#     subject = "Your Temporary Password"
#     body = (
#         f"Your password has been reset by the admin. Use the temporary password below to log in and reset your password:\n\n"
#         f"Temporary Password: {one_time_password}\n\n"
#         f"Please log in and update your password immediately."
#     )

#     # Send email to user
#     await send_email_forgetpass_non_admin(admin_user.email, user.email, subject, body)

#     return {"message": "Temporary password has been sent to the user."}

#logs
from fastapi import FastAPI, HTTPException, Depends, APIRouter, Request
from pydantic import BaseModel, EmailStr
from app.core.database import get_prisma_client
import secrets
from app.api.userManagement.utils.emailUtils import send_email_forgetpass_non_admin
from app.api.userManagement.utils.passwordUtils import hash_password

# Initialize FastAPI app
router = APIRouter()

class ResetPasswordRequest(BaseModel):
    email: EmailStr
    admin_email: EmailStr


# Reset password endpoint
@router.post("/resetPasswordNonAdmin")
async def reset_password(
    request: ResetPasswordRequest,req: Request,
    prisma=Depends(get_prisma_client),
      # Access logger via request state
):
    logger = req.state.logger  # Access logger from request state

    try:
        # Step 1: Fetch the user from the database
        logger.info(f"Fetching user with email: {request.email}")
        user = await prisma.aq_users.find_first(where={"email": request.email})
        if not user:
            logger.warning(f"User with email {request.email} not found.")
            raise HTTPException(status_code=404, detail="User not found")

        # Step 2: Verify admin email
        logger.info(f"Verifying admin email: {request.admin_email}")
        admin_user = await prisma.aq_users.find_first(where={"email": request.admin_email, "is_admin": True})
        if not admin_user:
            logger.warning(f"Invalid admin email: {request.admin_email}")
            raise HTTPException(status_code=403, detail="Invalid admin email")

        # Step 3: Generate a one-time password
        logger.info(f"Generating a one-time password for user: {request.email}")
        one_time_password = secrets.token_urlsafe(8)

        # Step 4: Hash the temporary password
        logger.info("Hashing the temporary password.")
        hashed_temp_password = hash_password(one_time_password)

        # Step 5: Update the user's temp_password field
        logger.info(f"Updating the temporary password in the database for user: {request.email}")
        await prisma.aq_users.update(
            where={"email": user.email},
            data={"temp_password": hashed_temp_password}
        )

        # Step 6: Prepare and send the email to the user
        logger.info(f"Preparing email to user: {request.email}")
        subject = "Your Temporary Password"
        body = (
            f"Your password has been reset by the admin. Use the temporary password below to log in and reset your password:\n\n"
            f"Temporary Password: {one_time_password}\n\n"
            f"Please log in and update your password immediately."
        )
        logger.info(f"Sending email from admin: {request.admin_email} to user: {request.email}")
        await send_email_forgetpass_non_admin(admin_user.email, user.email, subject, body)

        logger.info(f"Temporary password successfully sent to user: {request.email}")
        return {"message": "Temporary password has been sent to the user."}

    except HTTPException as http_exc:
        logger.error(f"HTTPException: {http_exc.detail}")
        raise http_exc

    except Exception as e:
        logger.error(f"Unexpected error during password reset: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Error processing password reset: {str(e)}")
