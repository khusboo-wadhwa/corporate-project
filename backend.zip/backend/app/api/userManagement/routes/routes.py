from fastapi import APIRouter, HTTPException, Depends,Header
from fastapi.security import OAuth2PasswordRequestForm
from app.core.auth import (
    create_access_token,
    create_session_token,
    decode_token,
    oauth2_scheme,
    SECRET_KEY,
    ALGORITHM
)
from app.api.userManagement.schemas.schemas import (
    UserLogin,
    VerificationCode,
    RoleAccessVerification,
    UserRegistration,
)
from app.api.userManagement.services.services import send_verification_email, verification_codes
from app.core.database import prisma
import random
import jwt


router = APIRouter()


@router.post("/register/")
async def register_user(user: UserRegistration):
    existing_user = await prisma.userm.find_first(where={"email_id": user.email_id})
    if existing_user:
        raise HTTPException(status_code=400, detail="Email already registered")
    await prisma.userm.create(
        data={
            "first_name": user.first_name,
            "last_name": user.last_name,
            "email_id": user.email_id,
            "password": user.password,
            "role": user.role,
            "is_verified": False,
        }
    )
    return {"message": "User registered successfully. Verify your email."}


@router.post("/token", response_model=dict)
async def login_for_access_token(form_data: OAuth2PasswordRequestForm = Depends()):
    user_record = await prisma.userm.find_first(where={"email_id": form_data.username})
    if user_record is None or form_data.password != user_record.password:
        raise HTTPException(status_code=401, detail="Invalid credentials")
    access_token = create_access_token({"sub": form_data.username})
    return {"access_token": access_token, "token_type": "bearer"}



@router.post("/verify_credentials/")
async def verify_credentials(user: UserLogin):
    user_record = await prisma.userm.find_first(where={"email_id": user.email_id})
    if not user_record:
        raise HTTPException(status_code=404, detail="User not found")
    if user_record.password != user.password:
        raise HTTPException(status_code=400, detail="Incorrect password")
    code = str(random.randint(100000, 999999))
    verification_codes[user.email_id] = code
    send_verification_email(user.email_id, code)
    return {"message": "Verification code sent"}


@router.post("/verify_code/")
async def verify_code_oauth(data: VerificationCode, token: str = Depends(oauth2_scheme)):
    user_record = await prisma.userm.find_first(where={"email_id": data.email_id})

    if user_record is None:
        raise HTTPException(status_code=404, detail="User not found")

    # If the email is already verified
    if user_record.is_verified:
        # Generate new access and session tokens and return response
        access_token = create_access_token({"sub": data.email_id})
        session_token = create_session_token({"sub": data.email_id})

        # Update the user's tokens in the database even if the account is already verified
        await prisma.userm.update(
            where={"email_id": data.email_id},
            data={
                "access_token": access_token,
                "session_token": session_token,
            }
        )

        return {
            "message": "User is already verified successfully",
            "access_token": access_token,
            "session_token": session_token,
            "token_type": "bearer"
        }

    # Check if the provided verification code matches the stored code
    stored_code = verification_codes.get(data.email_id)
    if stored_code is None or stored_code != data.code:
        raise HTTPException(status_code=400, detail="Invalid or expired verification code")

    # Verification successful, delete the code from temporary storage
    del verification_codes[data.email_id]

    # Generate new access and session tokens
    access_token = create_access_token({"sub": data.email_id})
    session_token = create_session_token({"sub": data.email_id})

    # Update the user record with the new tokens and set is_verified to True
    await prisma.userm.update(
        where={"email_id": data.email_id},
        data={
            "access_token": access_token,
            "session_token": session_token,
            "is_verified": True,  # Set is_verified to True after verification
        }
    )

    return {
        "message": "Code verified successfully",
        "access_token": access_token,
        "session_token": session_token,
        "token_type": "bearer"
    }


@router.post("/role_access/")
async def role_access(data: RoleAccessVerification, token: str = Depends(oauth2_scheme)):
    user_record = await prisma.userm.find_first(where={"email_id": data.email_id})
    
    if user_record is None:
        raise HTTPException(status_code=404, detail="User not found")

    # First, check if the session token matches the one stored in the database
    if user_record.session_token != data.session_token:
        raise HTTPException(status_code=400, detail="Invalid session token")

    # Verify if the session token has expired
    try:
        payload = jwt.decode(user_record.session_token, SECRET_KEY, algorithms=[ALGORITHM])
    except jwt.ExpiredSignatureError:
        # If session token expired, create a new session token (refresh)
        new_session_token = create_session_token({"sub": data.email_id})

        await prisma.userm.update(
            where={"email_id": data.email_id},
            data={"session_token": new_session_token}
        )

        return {
            "message": "Session token is expired. New session token generated.",
            "session_token": new_session_token
        }
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=400, detail="Invalid session token")

    # Verify access token and role
    if user_record.access_token != data.access_token:
        raise HTTPException(status_code=400, detail="Access token is invalid")

    if user_record.role.strip().lower() != data.role.strip().lower():
        raise HTTPException(status_code=403, detail=f"{data.email_id} is not authorized for the role '{data.role}'")

    return {"message": f"{data.email_id} is authorized for role {data.role}"}



@router.get("/logout/")
async def logout(token: str = Depends(oauth2_scheme)):
    # Dcode the session token to extract the email ID
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        email_id = payload.get("sub")
        if email_id is None:
            raise HTTPException(status_code=400, detail="Invalid token")
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=400, detail="Session token has expired. Please log in again.")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=400, detail="Invalid token")

    # Find the user in the database
    user_record = await prisma.userm.find_first(where={"email_id": email_id})

    if user_record is None:
        raise HTTPException(status_code=404, detail="User not found")

    # Clear the access and session tokens from the database
    await prisma.userm.update(
        where={"email_id": email_id},
        data={
            "access_token": None,
            "session_token": None
        }
    )

    return {"message": "Logged out successfully."}
