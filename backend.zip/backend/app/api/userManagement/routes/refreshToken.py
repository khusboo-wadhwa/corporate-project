from fastapi import APIRouter, HTTPException, Request, Response, Body
from app.api.userManagement.utils.jwt import generate_jwt_tokens, SECRET_KEY
from prisma import Prisma
from datetime import datetime, timezone
import jwt
from app.core.database import get_prisma_client

router = APIRouter()
prisma = Prisma()
from fastapi import APIRouter, HTTPException, Request, Response
from app.api.userManagement.utils.jwt import generate_jwt_tokens, SECRET_KEY
from prisma import Prisma
from datetime import datetime, timezone
import jwt

router = APIRouter()
prisma = Prisma()

# @router.post("/refresh_token")
# async def refresh_token(request: Request, response: Response):
#     prisma = await get_prisma_client()
#     # Get the refresh token from cookies
#     refresh_token_cookie = request.cookies.get("refresh_token")
#     if not refresh_token_cookie:
#         raise HTTPException(status_code=400, detail="Missing refresh token")

#     try:
#         # Decode the refresh token to get the user_id and other details
#         payload = jwt.decode(refresh_token_cookie, SECRET_KEY, algorithms=["HS256"])

#         # Ensure the token is of type 'refresh'
#         if payload.get("type") != "refresh":
#             raise HTTPException(status_code=401, detail="Invalid token type")

#         user_id = int(payload["sub"])  # Extract the user_id from the token

#         # Fetch the user from the database
#         user = await prisma.aq_users.find_unique(where={"id": user_id})
#         if not user:
#             raise HTTPException(status_code=404, detail="User not found")

#         # Fetch roles and permissions associated with the user
#         user_roles = await prisma.aq_user_roles.find_many(
#             where={"user_id": user.id},
#             include={"aq_roles": {"include": {"aq_role_permissions": {"include": {"aq_permissions": True}}}}}
#         )

#         roles = [role.aq_roles.role_name for role in user_roles]
#         permissions = list({
#             perm.aq_permissions.permission_name
#             for role in user_roles
#             for perm in role.aq_roles.aq_role_permissions
#         })

#         # Check the expiration of the refresh token
#         now = datetime.now(timezone.utc)
#         stored_token = await prisma.aq_tokens.find_first(
#             where={
#                 "user_id": user_id,
#                 "token": refresh_token_cookie,
#                 "token_type": "refresh",
#                 "is_revoked": False
#             }
#         )

#         if not stored_token or stored_token.expires_at < now:
#             raise HTTPException(status_code=401, detail="Refresh token expired or invalid")

#         # Revoke the old refresh token
#         await prisma.aq_tokens.update_many(
#             where={"token": refresh_token_cookie},
#             data={"is_revoked": True}
#         )

#         # Generate new access and refresh tokens
#         user_info = {
#             "id": user.id,
#             "email": user.email,
#             "first_name": user.first_name,
#             "last_name": user.last_name,
#             "roles": roles,
#             "permissions": permissions
#         }

#         new_access, new_refresh, access_exp, refresh_exp = generate_jwt_tokens(user_info)

#         # Store the new refresh token in the database
#         await prisma.aq_tokens.create(data={
#             "user_id": user.id,
#             "token": new_refresh,
#             "token_type": "refresh",
#             "expires_at": refresh_exp,
#             "is_revoked": False
#         })

#         # Set the new tokens in cookies
#         cookie_settings = {
#             "httponly": True,
#             "path": "/",
#             "samesite": "None",
#             "secure": True
#         }

#         response.set_cookie(
#             key="access_token",
#             value=new_access,
#             max_age=1800,  # 5 minutes
#             **cookie_settings
#         )

#         response.set_cookie(
#             key="refresh_token",
#             value=new_refresh,
#             max_age=604800,  # 7 days
#             **cookie_settings
#         )

#         return {
#             "message": "Tokens refreshed successfully",
#             "user_id": user.id,
#             "permissions": permissions  # Return permissions as part of the response
#         }

#     except jwt.ExpiredSignatureError:
#         raise HTTPException(status_code=401, detail="Refresh token expired")
#     except jwt.InvalidTokenError:
#         raise HTTPException(status_code=401, detail="Invalid refresh token")
#     except Exception as e:
#         raise HTTPException(
#             status_code=500,
#             detail=f"Internal server error: {str(e)}"
#         )
#     finally:
#         await prisma.disconnect()


@router.post("/refresh_token")
async def refresh_token(request: Request, response: Response):
    prisma = await get_prisma_client()
    
    # Check if access token is present
    access_token_cookie = request.cookies.get("access_token")
    if access_token_cookie:
        try:
            # Try decoding the access token
            access_payload = jwt.decode(access_token_cookie, SECRET_KEY, algorithms=["HS256"])
            
            # If decode successful and not expired, no need to refresh
            return {
                "message": "Access token still valid, no refresh needed",
                "user_id": access_payload["sub"],
                "permissions": access_payload.get("permissions", []),
            }
        
        except jwt.ExpiredSignatureError:
            # Access token expired → continue normal refresh process
            pass
        except jwt.InvalidTokenError:
            # Access token invalid → continue normal refresh process
            pass
        except Exception as e:
            # Unexpected decode issue → continue normal refresh process
            pass

    # Now normal refresh flow starts
    refresh_token_cookie = request.cookies.get("refresh_token")
    if not refresh_token_cookie:
        raise HTTPException(status_code=400, detail="Missing refresh token")

    try:
        # Decode the refresh token
        payload = jwt.decode(refresh_token_cookie, SECRET_KEY, algorithms=["HS256"])

        if payload.get("type") != "refresh":
            raise HTTPException(status_code=401, detail="Invalid token type")

        user_id = int(payload["sub"])

        user = await prisma.aq_users.find_unique(where={"id": user_id})
        if not user:
            raise HTTPException(status_code=404, detail="User not found")

        # Roles and permissions fetch
        user_roles = await prisma.aq_user_roles.find_many(
            where={"user_id": user.id},
            include={"aq_roles": {"include": {"aq_role_permissions": {"include": {"aq_permissions": True}}}}}
        )

        roles = [role.aq_roles.role_name for role in user_roles]
        permissions = list({
            perm.aq_permissions.permission_name
            for role in user_roles
            for perm in role.aq_roles.aq_role_permissions
        })

        now = datetime.now(timezone.utc)
        stored_token = await prisma.aq_tokens.find_first(
            where={
                "user_id": user_id,
                "token": refresh_token_cookie,
                "token_type": "refresh",
                "is_revoked": False
            }
        )

        if not stored_token or stored_token.expires_at < now:
            raise HTTPException(status_code=401, detail="Refresh token expired or invalid")

        # Revoke the old refresh token
        await prisma.aq_tokens.update_many(
            where={"token": refresh_token_cookie},
            data={"is_revoked": True}
        )

        # Generate new tokens
        user_info = {
            "id": user.id,
            "email": user.email,
            "first_name": user.first_name,
            "last_name": user.last_name,
            "property_id": user.property_id,
            "roles": roles,
            "permissions": permissions
        }

        new_access, new_refresh, access_exp, refresh_exp = generate_jwt_tokens(user_info)

        await prisma.aq_tokens.create(data={
            "user_id": user.id,
            "token": new_refresh,
            "token_type": "refresh",
            "expires_at": refresh_exp,
            "is_revoked": False
        })

        cookie_settings = {
            "httponly": True,
            "path": "/",
            "samesite": "None",
            "secure": True
        }

        response.set_cookie(
            key="access_token",
            value=new_access,
            max_age=1800,
            **cookie_settings
        )

        response.set_cookie(
            key="refresh_token",
            value=new_refresh,
            max_age=604800,
            **cookie_settings
        )

        return {
            "message": "Tokens refreshed successfully",
            "user_id": user.id,
            "permissions": permissions
        }

    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Refresh token expired")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Invalid refresh token")
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Internal server error: {str(e)}"
        )
    finally:
        await prisma.disconnect()


@router.post("/test_refresh_token")
async def test_refresh_token(
    response: Response,
    user_id: int = Body(..., embed=True),  # Require user_id in request body
    request: Request = None  # Optional for cookie checks
):

    await prisma.connect()
    try:
        user = await prisma.aq_users.find_unique(where={"id": user_id})
        if not user:
            raise HTTPException(status_code=404, detail="User not found")

        # Fetch roles and permissions (same as normal flow)
        user_roles = await prisma.aq_user_roles.find_many(
            where={"user_id": user.id},
            include={"aq_roles": {"include": {"aq_role_permissions": {"include": {"aq_permissions": True}}}}}
        )

        roles = [role.aq_roles.role_name for role in user_roles]
        permissions = list({
            perm.aq_permissions.permission_name
            for role in user_roles
            for perm in role.aq_roles.aq_role_permissions
        })

        user_info = {
            "id": user.id,
            "email": user.email,
            "first_name": user.first_name,
            "last_name": user.last_name,
            "roles": roles,
            "permissions": permissions
        }

        # Generate new tokens
        new_access, new_refresh, access_exp, refresh_exp = generate_jwt_tokens(user_info)

        # Store the refresh token in database
        await prisma.aq_tokens.create(data={
             "user_id": user.id,
             "token": new_refresh,
             "token_type": "refresh",
             "expires_at": refresh_exp,
             "is_revoked": False
        })


        # Set cookies
        response.set_cookie(
            key="access_token",
            value=new_access,
            httponly=True,
            max_age=300,
            path="/",
            secure=False,
            samesite="Strict"
        )
        response.set_cookie(
            key="refresh_token",
            value=new_refresh,
            httponly=True,
            max_age=604800,
            path="/",
            secure=False,
            samesite="Strict"
        )

        return {
            "message": "Test tokens generated",
            "user_id": user.id,
            "permissions": permissions
        }

    finally:
        await prisma.disconnect()