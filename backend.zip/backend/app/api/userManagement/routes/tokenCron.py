from apscheduler.schedulers.asyncio import AsyncIOScheduler
from datetime import datetime, timezone
from app.core.database import get_prisma_client
import asyncio
import logging

scheduler = AsyncIOScheduler()
logger = logging.getLogger(__name__)

async def revoke_expired_tokens():
    prisma = await get_prisma_client()
    try:
        await prisma.connect()
        now = datetime.now(timezone.utc)

        revoked = await prisma.aq_tokens.update_many(
            where={
                "expires_at": {"lt": now},
                "is_revoked": False
            },
            data={"is_revoked": True}
        )

        logger.info(f"Revoked {revoked.count} expired tokens.")

    except Exception as e:
        logger.error(f"Failed to revoke expired tokens: {e}")
    finally:
        await prisma.disconnect()

def start_token_cleanup_job():
    scheduler.add_job(revoke_expired_tokens, "interval", minutes=10)
    scheduler.start()
