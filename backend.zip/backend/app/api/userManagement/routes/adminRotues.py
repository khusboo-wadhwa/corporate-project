# #romve Userroleenum
# from fastapi import APIRouter, HTTPException, BackgroundTasks, Request
# from typing import List
# from datetime import datetime, timedelta
# from app.api.userManagement.schemas.userSchema import UserCreate
# from app.api.userManagement.utils.passwordUtils import hash_password
# from app.api.userManagement.utils.phoneUtils import generate_verification_code
# from app.api.userManagement.utils.emailUtils import generate_verification_code as generate_email_code
# from app.core.auth import (
#     check_if_admin_exists,
#     create_user_and_register_in_db,
#     is_email_taken,
#     is_username_taken,
#     is_mobile_number_taken,
# )
# from app.api.userManagement.utils.timeframe import delete_unverified_users
# from app.core.database import connect_db, disconnect_db
# from app.core.database import prisma
# from app.core.auth import fetch_valid_roles
# import re

# router = APIRouter()

# PASSWORD_REGEX = r"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,16}$"

# @router.post("/register_for_admin")
# async def register_user(user: UserCreate, background_tasks: BackgroundTasks, request: Request):
#     """
#     Endpoint to register a single admin user.
#     Validates inputs and ensures no existing admin users in the system.
#     """
#     logger = request.state.logger  # Access the logger from request.state

#     try:
#         logger.info(f"Admin registration started for user {user.username}")

#         # Ensure a connection to the database
#         await connect_db()

#         # Validate country code for USA and India
#         if user.country_code not in ["+1", "+91"]:
#             logger.error(f"Invalid country code: {user.country_code} for user {user.username}")
#             raise HTTPException(
#                 status_code=400,
#                 detail="Invalid country code. Only USA (+1) and India (+91) are allowed."
#             )

#         # Validate password strength
#         if not re.match(PASSWORD_REGEX, user.password):
#             logger.error(f"Password validation failed for user {user.username}")
#             raise HTTPException(
#                 status_code=400,
#                 detail=("Password must be 8-16 characters long with at least one lowercase letter, "
#                         "one uppercase letter, one number, and one special character.")
#             )

#         # Check if an admin already exists
#         existing_admin = await check_if_admin_exists()
#         if existing_admin:
#             logger.warning(f"An admin already exists. User {user.username} tried to register.")
#             raise HTTPException(
#                 status_code=400,
#                 detail="An admin already exists. Only one admin is allowed."
#             )

#         # Check for unique email, username, and mobile number
#         if await is_email_taken(user.email):
#             logger.error(f"Email {user.email} is already taken.")
#             raise HTTPException(status_code=400, detail="Email is already taken.")
#         if await is_username_taken(user.username):
#             logger.error(f"Username {user.username} is already taken.")
#             raise HTTPException(status_code=400, detail="Username is already taken.")
#         if await is_mobile_number_taken(user.mobile_number):
#             logger.error(f"Mobile number {user.mobile_number} is already taken.")
#             raise HTTPException(status_code=400, detail="Mobile number is already taken.")

#         # Fetch valid roles and ensure 'Admin' exists
#         valid_roles = await fetch_valid_roles()
#         logger.info(f"Valid roles fetched: {valid_roles}")
#         if "Admin" not in valid_roles:
#             logger.error("Admin role is not defined in the database.")
#             raise HTTPException(
#                 status_code=400,
#                 detail="The Admin role is not defined in the database. Please create it first."
#             )

#         # Generate phone and email verification codes
#         phone_verification_code = generate_verification_code()
#         email_verification_code = generate_email_code()
#         verification_expiration_time = datetime.utcnow() + timedelta(minutes=10)
#         verification_code_sent_at = datetime.utcnow()

#         # Hash the password
#         hashed_password = hash_password(user.password)

#         # Register the user in the database
#         created_user = await create_user_and_register_in_db(
#             first_name=user.first_name,
#             last_name=user.last_name,
#             username=user.username,
#             email=user.email,
#             password=hashed_password,
#             is_admin=True,
#             role=["Admin"],  # Assign 'Admin' role to the user
#             mobile_number=user.mobile_number,
#             country_code=user.country_code,
#             phone_verification_code=phone_verification_code,
#             phone_verification_code_sent_at=verification_code_sent_at,
#             phone_verification_code_expires_at=verification_expiration_time,
#             email_verification_code=email_verification_code,
#             email_verification_code_sent_at=verification_code_sent_at,
#             email_verification_code_expires_at=verification_expiration_time
#         )
#         logger.info(f"Admin user {user.username} successfully registered.")

#         # Fetch the role_id for 'Admin'
#         admin_role = await prisma.aq_roles.find_unique(where={"role_name": "Admin"})
#         if not admin_role:
#             raise HTTPException(status_code=400, detail="Admin role not found in the aq_roles table.")
        
#         # Insert user-role mapping into the aq_user_roles table
#         await prisma.aq_user_roles.create(
#             data={
#                 "user_id": created_user.id,
#                 "role_id": admin_role.id
#             }
#         )

#         # Add a background task to clean up unverified users
#         background_tasks.add_task(delete_unverified_users, expiration_hours=72)

#         # Return success response
#         logger.info(f"Admin user {user.username} registered successfully. Verification codes generated.")
#         return {
#             "success": True,
#             "message": "Admin registered successfully. Verification codes have been stored.",
#             "user": {
#                 "name": f"{created_user.first_name} {created_user.last_name}",
#                 "email": created_user.email,
#                 "roles": ["Admin"],
#                 "mobile_number": created_user.mobile_number,
#                 "country_code": created_user.country_code,
#             },
#             "verification_codes": {
#                 "phone_code": phone_verification_code,
#                 "email_code": email_verification_code
#             }
#         }

#     except HTTPException as http_exc:
#         logger.error(f"HTTPException encountered: {http_exc.detail}")
#         raise http_exc
#     except Exception as e:
#         logger.error(f"Unexpected error during admin registration: {str(e)}")
#         return {
#             "success": False,
#             "message": "An error occurred during admin registration.",
#             "error": str(e),
#         }
#     finally:
#         await disconnect_db()



# from fastapi import APIRouter, HTTPException, BackgroundTasks, Request
# from app.api.userManagement.schemas.userSchema import UserCreate
# from app.api.userManagement.utils.passwordUtils import hash_password
# from app.api.userManagement.utils.phoneUtils import generate_verification_code
# from app.api.userManagement.utils.emailUtils import generate_verification_code as generate_email_code
# from app.core.auth import (
#     check_if_admin_exists,
#     create_user_and_register_in_db,
#     is_email_taken,
#     is_username_taken,
#     is_mobile_number_taken,
#     fetch_valid_roles
# )
# from app.api.userManagement.utils.timeframe import delete_unverified_users
# from app.core.database import connect_db, disconnect_db
# from app.core.database import prisma
# from datetime import datetime, timedelta
# import re, redis, os

# router = APIRouter()

# # Password regex rule
# PASSWORD_REGEX = r"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,16}$"

# # Setup Redis
# redis_client = redis.Redis(
#     host=os.getenv("REDIS_HOST", "localhost"),
#     port=int(os.getenv("REDIS_PORT", "6379")),
#     decode_responses=True,
#     username=os.getenv("REDIS_USERNAME", None),
#     password=os.getenv("REDIS_PASSWORD", None),
# )

# @router.post("/register_for_admin")
# async def register_admin(user: UserCreate, background_tasks: BackgroundTasks, request: Request):
#     logger = request.state.logger

#     try:
#         logger.info(f"Admin registration started for user {user.username}")
#         await connect_db()

#         if user.country_code not in ["+1", "+91"]:
#             raise HTTPException(status_code=400, detail="Invalid country code.")

#         if not re.match(PASSWORD_REGEX, user.password):
#             raise HTTPException(status_code=400, detail="Password must be 8-16 chars with upper, lower, digit & symbol.")

#         # Check if admin already exists
#         if await check_if_admin_exists():
#             raise HTTPException(status_code=400, detail="Only one admin is allowed.")

#         if await is_email_taken(user.email):
#             raise HTTPException(status_code=400, detail="Email already taken.")
#         if await is_username_taken(user.username):
#             raise HTTPException(status_code=400, detail="Username already taken.")
#         if await is_mobile_number_taken(user.mobile_number):
#             raise HTTPException(status_code=400, detail="Mobile number already taken.")

#         valid_roles = await fetch_valid_roles()
#         if "Admin" not in valid_roles:
#             raise HTTPException(status_code=400, detail="Admin role not defined. Please create it.")

#         phone_verification_code = generate_verification_code()
#         email_verification_code = generate_email_code()

#         # Store verification in Redis (expires in 10 minutes)
#         redis_client.setex(f"phone_code:{user.email}", timedelta(minutes=10), phone_verification_code)
#         redis_client.setex(f"email_code:{user.email}", timedelta(minutes=10), email_verification_code)

#         hashed_password = hash_password(user.password)

#         # Register in DB
#         created_user = await create_user_and_register_in_db(
#             first_name=user.first_name,
#             last_name=user.last_name,
#             username=user.username,
#             email=user.email,
#             password=hashed_password,
#             is_admin=True,
#             role=["Admin"],
#             mobile_number=user.mobile_number,
#             country_code=user.country_code,
#             phone_verification_code=phone_verification_code,
#             phone_verification_code_sent_at=datetime.utcnow(),
#             phone_verification_code_expires_at=datetime.utcnow() + timedelta(minutes=10),
#             email_verification_code=email_verification_code,
#             email_verification_code_sent_at=datetime.utcnow(),
#             email_verification_code_expires_at=datetime.utcnow() + timedelta(minutes=10)
#         )

#         admin_role = await prisma.aq_roles.find_unique(where={"role_name": "Admin"})
#         if not admin_role:
#             raise HTTPException(status_code=400, detail="Admin role not found in DB.")

#         await prisma.aq_user_roles.create({
#             "user_id": created_user.id,
#             "role_id": admin_role.id
#         })

#         background_tasks.add_task(delete_unverified_users, expiration_hours=72)

#         return {
#             "success": True,
#             "message": "Admin registered successfully.",
#             "user": {
#                 "name": f"{created_user.first_name} {created_user.last_name}",
#                 "email": created_user.email,
#                 "roles": ["Admin"],
#                 "mobile_number": created_user.mobile_number,
#                 "country_code": created_user.country_code,
#             },
#             "verification_codes": {
#                 "phone_code": phone_verification_code,
#                 "email_code": email_verification_code
#             }
#         }

#     except HTTPException as http_exc:
#         raise http_exc
#     except Exception as e:
#         logger.error(f"Registration failed: {str(e)}")
#         return {
#             "success": False,
#             "message": "Error occurred during admin registration.",
#             "error": str(e),
#         }
#     finally:
#         await disconnect_db()


from fastapi import APIRouter, HTTPException, BackgroundTasks, Request, Header
from app.api.userManagement.schemas.userSchema import UserCreate
from app.api.userManagement.utils.passwordUtils import hash_password
from app.api.userManagement.utils.phoneUtils import generate_verification_code
from app.api.userManagement.utils.emailUtils import generate_verification_code as generate_email_code
from app.core.auth import (
    check_if_admin_exists,
    create_user_and_register_in_db,
    is_email_taken,
    is_username_taken,
    is_mobile_number_taken,
    fetch_valid_roles
)
from app.api.userManagement.utils.timeframe import delete_unverified_users
from app.core.database import connect_db, disconnect_db
from app.core.database import prisma
from datetime import datetime, timedelta
import re, redis, os
from pydantic import BaseModel, EmailStr
from app.api.userManagement.utils.emailUtils import send_admin_registration_email
from dotenv import load_dotenv
import os

router = APIRouter()


load_dotenv()

FRONTEND_URL = os.getenv("FRONTEND_BASE_URL", "http://localhost:3000")

# Password regex rule
PASSWORD_REGEX = r"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,16}$"

# Setup Redis
redis_client = redis.Redis(
    host=os.getenv("REDIS_HOST", "localhost"),
    port=int(os.getenv("REDIS_PORT", "6379")),
    decode_responses=True,
    username=os.getenv("REDIS_USERNAME", None),
    password=os.getenv("REDIS_PASSWORD", None),
)
async def connect_prisma():
    if not prisma._connected:
        await prisma.connect()

class OTPVerifySchema(BaseModel):
    email: EmailStr
    verification_code: str

@router.post("/register_for_admin")
async def register_admin(user: UserCreate, background_tasks: BackgroundTasks, request: Request):
    logger = request.state.logger

    try:
        logger.info(f"Admin registration started for user {user.username}")
        
        await connect_db()

        # 1. Check if admin exists (quick check first)
        if await prisma.aq_users.find_first(where={"is_admin": True}):
            raise HTTPException(status_code=400, detail="Admin already exists")

        # 2. Create Super Admin role if needed
        super_admin_role = await prisma.aq_roles.find_unique(where={"role_name": "Super_Admin"})
        if not super_admin_role:
            super_admin_role = await prisma.aq_roles.create(
                data={"role_name": "Super_Admin", "description": "Full access role"}
            )

        # 3. Validate inputs
        if user.country_code not in ["+1", "+91"]:
            raise HTTPException(status_code=400, detail="Invalid country code")
        
        if not re.match(PASSWORD_REGEX, user.password):
            raise HTTPException(status_code=400, detail="Weak password")

        # 4. Check unique fields
        if await prisma.aq_users.find_unique(where={"email": user.email}):
            raise HTTPException(status_code=400, detail="Email taken")
        if await prisma.aq_users.find_unique(where={"username": user.username}):
            raise HTTPException(status_code=400, detail="Username taken")
        if user.mobile_number and await prisma.aq_users.find_unique(where={"mobile_number": user.mobile_number}):
            raise HTTPException(status_code=400, detail="Mobile number taken")

        # 5. Generate verification codes
        email_code = generate_email_code()
        phone_code = generate_verification_code()
        
        redis_client.setex(f"email_code:{user.email}", 600, email_code)
        redis_client.setex(f"phone_code:{user.email}", 600, phone_code)
        
        background_tasks.add_task(
            send_admin_registration_email,
            user.email,
            user.first_name,
            email_code
        )


        # 6. Create user
        hashed_pw = hash_password(user.password)
        new_user = await prisma.aq_users.create(
            data={
                "first_name": user.first_name,
                "last_name": user.last_name,
                "username": user.username,
                "email": user.email,
                "password": hashed_pw,
                "is_admin": True,
                "mobile_number": user.mobile_number,
                "country_code": user.country_code,
                "company_name": user.company_name or "Rgs-tech",
                "role": ["Super_Admin"],
                "first_login": True,
            }
        )

        # 7. Create verification record
        await prisma.aq_user_verification.create(
            data={
                "user_id": new_user.id,
                "phone_verification_code": phone_code,
                "email_verification_code": email_code,
                "phone_verification_code_sent_at": datetime.utcnow(),
                "email_verification_code_sent_at": datetime.utcnow(),
                "phone_verification_code_expires_at": datetime.utcnow() + timedelta(minutes=10),
                "email_verification_code_expires_at": datetime.utcnow() + timedelta(minutes=10),
            }
        )

        # 8. Assign Super Admin role
        await prisma.aq_user_roles.create(
            data={
                "user_id": new_user.id,
                "role_id": super_admin_role.id
            }
        )

        # 9. Assign all permissions
        permissions = await prisma.aq_permissions.find_many()
        for perm in permissions:
            try:
                await prisma.aq_role_permissions.create(
                    data={
                        "role_id": super_admin_role.id,
                        "permission_id": perm.id
                    }
                )
            except:
                continue

        background_tasks.add_task(delete_unverified_users, 72)

        return {
            "success": True,
            "message": "Admin created successfully",
            "user": {
                "name": f"{new_user.first_name} {new_user.last_name}",
                "email": new_user.email
            },
            "verification_codes": {
                "email": email_code,
                "phone": phone_code
            },
            "redirect_url": f"{FRONTEND_URL}/admin-otp-verification"

        }

    except HTTPException as e:
        raise e
    except Exception as e:
        logger.error(f"Registration failed: {str(e)}")
        return {
            "success": False,
            "message": "Registration failed",
            "error": str(e)
        }
    finally:
        await disconnect_db()


@router.post("/adminotp")
async def verify_admin_otp(payload: OTPVerifySchema, request: Request):
    logger = request.state.logger
    try:
        # Connect to the database
        await connect_db()

        otp_key = f"email_code:{payload.email}"
        stored_otp = redis_client.get(otp_key)

        if not stored_otp:
            raise HTTPException(status_code=400, detail="OTP has expired. Please resend OTP.")

        if stored_otp != payload.verification_code:
            raise HTTPException(status_code=400, detail="Invalid OTP. Please try again.")

        # Check if the user exists
        user = await prisma.aq_users.find_unique(where={"email": payload.email})
        if not user:
            raise HTTPException(status_code=404, detail="User not found.")

        # Check if the user has an associated verification record
        user_verification = await prisma.aq_user_verification.find_unique(where={"user_id": user.id})
        if not user_verification:
            raise HTTPException(status_code=404, detail="User verification record not found.")

        # Mark the email as verified in the user verification model
        await prisma.aq_user_verification.update(
            where={"user_id": user.id},
            data={"is_email_verified": True}
        )

        # Delete OTP from Redis
        redis_client.delete(otp_key)

        return {"success": True, "message": "Email verified successfully."}
    except Exception as e:
        logger.error(f"OTP verification failed: {str(e)}")
        raise HTTPException(status_code=500, detail="OTP verification failed.")
    finally:
        # Disconnect from the database
        await disconnect_db()


# The `resendAdminOTP` endpoint
@router.get("/resendAdminOTP")
async def resend_admin_otp(email: str = Header(...), request: Request = None):
    logger = request.state.logger
    try:
        # Connect to the database (though this step is technically not required for just resending OTP)
        await connect_db()

        # Generate new OTP code
        otp_code = generate_email_code()

        # Store OTP code in Redis with a 10-minute expiration
        redis_client.setex(f"email_code:{email}", timedelta(minutes=10), otp_code)

        # Log the OTP code (you would normally send it via email)
        logger.info(f"Resending new OTP {otp_code} to email: {email}")

        # This is where you'd integrate with an actual email service to send the OTP to the user's email
        # Example: send_email_otp(email, otp_code)

        return {"success": True, "detail": "New OTP sent successfully."}
    except Exception as e:
        logger.error(f"Failed to resend OTP: {str(e)}")
        raise HTTPException(status_code=500, detail="Failed to resend OTP.")
    finally:
        # Disconnect from the database
        await disconnect_db()

@router.get("/resendAdminOTP")
async def resend_admin_otp(email: str = Header(...), request: Request = None):
    logger = request.state.logger
    try:
        otp_code = generate_email_code()
        redis_client.setex(f"email_code:{email}", timedelta(minutes=10), otp_code)

        # Log or send actual email here
        logger.info(f"Resending new OTP {otp_code} to email: {email}")

        return {"success": True, "detail": "New OTP sent successfully."}
    except Exception as e:
        logger.error(f"Failed to resend OTP: {str(e)}")
        raise HTTPException(status_code=500, detail="Failed to resend OTP.")

