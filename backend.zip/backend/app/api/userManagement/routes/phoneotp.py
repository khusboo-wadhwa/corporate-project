# otp_auth.py
import os
import httpx
import asyncio
from fastapi import APIRouter, FastAPI, HTTPException, Depends, status
from pydantic import BaseModel, constr
from redis.asyncio import Redis
from dotenv import load_dotenv
import smtplib
import random
from email.message import EmailMessage


load_dotenv()  # Load .env file if available



# Config
GOOGLE_IDENTITY_API_KEY = "AIzaSyDYA1vAh45dU0-uJW-_6WCJetbdMOvl0wI"
OTP_TTL = 180  # 3 minutes
REDIS_URL = os.getenv("REDIS_URL", "redis://localhost:6379")
EMAIL_FROM="rohukale94458@gmail.com"
EMAIL_PASSWORD="fana viuw bscc enoq"
SMTP_HOST="smtp.gmail.com"
SMTP_PORT=587


# Redis client
redis_client = Redis.from_url(REDIS_URL, decode_responses=True)

# FastAPI router
router = APIRouter(prefix="/auth", tags=["OTP Auth"])
app = FastAPI()
app.include_router(router)


# === MODELS ===
class PhoneRequest(BaseModel):
    phone: constr(strip_whitespace=True, min_length=10, max_length=15)

class OTPVerifyRequest(PhoneRequest):
    code: constr(min_length=4, max_length=6)

# === SEND OTP ===
@router.post("/send-otp")
async def send_otp(req: PhoneRequest):
    phone = req.phone

    # Check if already sent (resend protection)
    if await redis_client.exists(f"otp_session:{phone}"):
        ttl = await redis_client.ttl(f"otp_session:{phone}")
        raise HTTPException(
            status_code=429,
            detail=f"OTP already sent. Please wait {ttl} seconds to resend."
        )

    url = f"https://identitytoolkit.googleapis.com/v1/accounts:sendVerificationCode?key={GOOGLE_IDENTITY_API_KEY}"
    payload = {
        "phoneNumber": phone,
        "recaptchaToken": "test",  # You can ignore it unless reCAPTCHA is enforced
    }

    async with httpx.AsyncClient() as client:
        resp = await client.post(url, json=payload)
    
    if resp.status_code != 200:
        raise HTTPException(status_code=400, detail="Failed to send OTP")

    session_info = resp.json().get("sessionInfo")
    if not session_info:
        raise HTTPException(status_code=500, detail="Session info not received")

    # Store session info in Redis with TTL
    await redis_client.setex(f"otp_session:{phone}", OTP_TTL, session_info)

    return {"message": "OTP sent successfully", "expires_in_seconds": OTP_TTL}

# === VERIFY OTP ===
@router.post("/verify-otp")
async def verify_otp(req: OTPVerifyRequest):
    phone, code = req.phone, req.code

    session_info = await redis_client.get(f"otp_session:{phone}")
    if not session_info:
        raise HTTPException(status_code=400, detail="OTP expired or not found")

    url = f"https://identitytoolkit.googleapis.com/v1/accounts:signInWithPhoneNumber?key={GOOGLE_IDENTITY_API_KEY}"
    payload = {
        "sessionInfo": session_info,
        "code": code
    }

    async with httpx.AsyncClient() as client:
        resp = await client.post(url, json=payload)

    if resp.status_code != 200:
        raise HTTPException(status_code=400, detail="Invalid or expired OTP")

    # OTP verified — delete session
    await redis_client.delete(f"otp_session:{phone}")

    # Optional: you can extract phone auth ID token if needed:
    # id_token = resp.json().get("idToken")

    return {"message": "OTP verified successfully", "phone": phone}


##Email Utility Function
def generate_otp():
    return str(random.randint(100000, 999999))

async def send_otp_email(to_email: str, otp: str):
    msg = EmailMessage()
    msg["Subject"] = "Your Verification OTP"
    msg["From"] = os.getenv("EMAIL_FROM")
    msg["To"] = to_email
    msg.set_content(f"Your OTP is: {otp}\nIt will expire in 3 minutes.")

    try:
        with smtplib.SMTP(os.getenv("SMTP_HOST"), int(os.getenv("SMTP_PORT"))) as server:
            server.starttls()
            server.login(os.getenv("EMAIL_FROM"), os.getenv("EMAIL_PASSWORD"))
            server.send_message(msg)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to send email: {str(e)}")


class EmailRequest(BaseModel):
    email: constr(strip_whitespace=True, min_length=5, max_length=100)

class EmailOTPVerifyRequest(EmailRequest):
    code: constr(min_length=4, max_length=6)


@router.post("/send-email-otp")
async def send_email_otp(req: EmailRequest):
    email = req.email.lower()

    # Check if already sent
    if await redis_client.exists(f"email_otp:{email}"):
        ttl = await redis_client.ttl(f"email_otp:{email}")
        raise HTTPException(
            status_code=429,
            detail=f"OTP already sent. Please wait {ttl} seconds to resend."
        )

    otp = generate_otp()
    await redis_client.setex(f"email_otp:{email}", OTP_TTL, otp)
    await send_otp_email(email, otp)

    return {"message": "OTP sent to email", "expires_in_seconds": OTP_TTL}

@router.post("/verify-email-otp")
async def verify_email_otp(req: EmailOTPVerifyRequest):
    email, code = req.email.lower(), req.code

    stored = await redis_client.get(f"email_otp:{email}")
    if not stored:
        raise HTTPException(status_code=400, detail="OTP expired or not found")

    if stored != code:
        raise HTTPException(status_code=400, detail="Invalid OTP")

    await redis_client.delete(f"email_otp:{email}")

    return {"message": "Email OTP verified successfully", "email": email}


@app.get("/ping")
async def ping():
    pong = await redis_client.ping()
    return {"status": "ok", "redis": pong}

