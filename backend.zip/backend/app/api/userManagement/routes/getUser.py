# from fastapi import APIRouter, HTTPException, Depends, status
# from prisma import Prisma
# from app.core.database import get_prisma_client
# from app.core.auth import get_current_user

# router = APIRouter()
# @router.get("/getUsers", status_code=status.HTTP_200_OK)
# async def get_non_admin_users(
#     email: str,  # Email of the current user
#     prisma: Prisma = Depends(get_prisma_client)  # Inject Prisma client
# ):
#     """
#     Fetch details of all non-admin users.
#     Only admins can view these details.
#     """

#     # Fetch the current user from the database using their email
#     current_user = await prisma.users1.find_unique(
#         where={"email": email}
#     )

#     # Check if the user exists
#     if not current_user:
#         raise HTTPException(
#             status_code=status.HTTP_404_NOT_FOUND,
#             detail="User not found."
#         )

#     # Verify if the user is an admin
#     if not current_user.is_admin:
#         raise HTTPException(
#             status_code=status.HTTP_403_FORBIDDEN,
#             detail="You do not have permission to view non-admin users."
#         )

#     # Fetch all non-admin users from the database
#     non_admin_users = await prisma.users1.find_many(
#         where={"is_admin": False}  # Filter for non-admin users
#     )

#     # Return the details of all non-admin users
#     return [
#         {
#             "id": user.id,
#             "first_name": user.first_name,
#             "last_name": user.last_name,
#             "username": user.username,
#             "email": user.email,
#             "mobile_number": user.mobile_number,
#             "roles": user.role,
#             "created_at": user.created_at,
#             "is_admin": user.is_admin,
#         }
#         for user in non_admin_users
#     ]




#websocket
from fastapi import APIRouter, HTTPException, Depends, status
from prisma import Prisma
from app.core.database import get_prisma_client
from app.core.auth import get_current_user
from app.api.userManagement.utils.wsUtils import broadcast_message  # Import the WebSocket utility

router = APIRouter()

@router.get("/getUsers", status_code=status.HTTP_200_OK)
async def get_non_admin_users(
    email: str,  # Email of the current user
    prisma: Prisma = Depends(get_prisma_client)  # Inject Prisma client
):
    """
    Fetch details of all non-admin users.
    Only admins can view these details.
    """

    # Fetch the current user from the database using their email
    current_user = await prisma.aq_users.find_unique(
        where={"email": email}
    )

    # Check if the user exists
    if not current_user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found."
        )

    # Verify if the user is an admin
    if not current_user.is_admin:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="You do not have permission to view non-admin users."
        )

    # Fetch all non-admin users from the database
    non_admin_users = await prisma.aq_users.find_many(
        where={"is_admin": False}  # Filter for non-admin users
    )

    # Broadcast the updated user list to connected WebSocket clients
    try:
        await broadcast_message("Non-admin users list updated")
    except Exception as e:
        # Log the error or handle as needed
        print(f"Error broadcasting message: {str(e)}")

    # Return the details of all non-admin users
    return [
        {
            "id": user.id,
            "first_name": user.first_name,
            "last_name": user.last_name,
            "username": user.username,
            "email": user.email,
            "mobile_number": user.mobile_number,
            "roles": user.role,
            "created_at": user.created_at,
            "is_admin": user.is_admin,
        }
        for user in non_admin_users
    ]



#logsand websocket
from fastapi import APIRouter, HTTPException, Depends, status, Request
from prisma import Prisma
from app.core.database import get_prisma_client
from app.core.auth import get_current_user
from app.api.userManagement.utils.wsUtils import broadcast_message  # Import the WebSocket utility

router = APIRouter()

@router.get("/getUsers", status_code=status.HTTP_200_OK)
async def get_non_admin_users(
    email: str,  # Email of the current user
    request: Request,  # Access to the logger
    prisma: Prisma = Depends(get_prisma_client)  # Inject Prisma client
):
    """
    Fetch details of all non-admin users.
    Only admins can view these details.
    """
    logger = request.state.logger  # Access the logger from request.state

    logger.info(f"Fetching non-admin users for email: {email}")

    # Fetch the current user from the database using their email
    current_user = await prisma.aq_users.find_unique(
        where={"email": email}
    )

    # Check if the user exists
    if not current_user:
        logger.warning(f"User with email {email} not found.")
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found."
        )

    # Verify if the user is an admin
    if not current_user.is_admin:
        logger.warning(f"User {email} does not have permission to view non-admin users.")
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="You do not have permission to view non-admin users."
        )

    # Fetch all non-admin users from the database
    non_admin_users = await prisma.aq_users.find_many(
        where={"is_admin": False}  # Filter for non-admin users
    )

    # Log the number of non-admin users found
    logger.info(f"Found {len(non_admin_users)} non-admin users.")

    # Broadcast the updated user list to connected WebSocket clients
    try:
        await broadcast_message("Non-admin users list updated")
        logger.info("Broadcasted the non-admin users list update.")
    except Exception as e:
        # Log the error or handle as needed
        logger.error(f"Error broadcasting message: {str(e)}")

    # Return the details of all non-admin users
    return [
        {
            "id": user.id,
            "first_name": user.first_name,
            "last_name": user.last_name,
            "username": user.username,
            "email": user.email,
            "mobile_number": user.mobile_number,
            "roles": user.role,
            "created_at": user.created_at,
            "is_admin": user.is_admin,
        }
        for user in non_admin_users
    ]
