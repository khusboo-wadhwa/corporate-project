import logging
from fastapi import APIRouter, HTTPException, Request, Response
from app.api.userManagement.utils.jwt import generate_jwt_tokens
from app.api.userManagement.utils.emailUtils import send_2fa_email, generate_verification_code
from app.core.database import get_prisma_client
from datetime import datetime, timedelta, timezone
from prisma.models import aq_tokens, aq_user_verification
from pydantic import BaseModel
from fastapi import Cookie
from dotenv import load_dotenv
import os
from passlib.context import CryptContext

logger = logging.getLogger(__name__)

load_dotenv()
FRONTEND_URL = os.getenv("FRONTEND_BASE_URL", "http://localhost:3000")

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

router = APIRouter()

class LoginRequest(BaseModel):
    email: str
    password: str

class OTPVerificationRequest(BaseModel):
    user_id: int
    verification_code: str

def safe_verify_password(plain_password: str, hashed_password: str) -> bool:
    """Verify a password against a hashed password with bcrypt 72-byte limit handling."""
    try:
        if not isinstance(plain_password, str):
            logger.warning("Non-string password provided, converting to string")
            plain_password = str(plain_password)
        
        password_bytes = plain_password.encode('utf-8')
        
        if len(password_bytes) > 72:
            logger.warning(f"Password exceeds 72 bytes, truncating: {plain_password[:10]}...")
            password_bytes = password_bytes[:72]
            plain_password = password_bytes.decode('utf-8', errors='ignore')
        
        try:
            result = pwd_context.verify(plain_password, hashed_password)
            if not result:
                logger.debug(f"Password verification failed for input: {plain_password[:10]}...")
            return result
        except ValueError as ve:
            logger.error(f"bcrypt verification error: {str(ve)}")
            return False
    
    except Exception as e:
        logger.error(f"Unexpected error verifying password: {str(e)}")
        return False

def hash_password(password: str) -> str:
    """Hash a password with bcrypt 72-byte limit handling."""
    try:
        if not isinstance(password, str):
            logger.warning("Non-string password provided, converting to string")
            password = str(password)
        
        password_bytes = password.encode('utf-8')
        
        if len(password_bytes) > 72:
            logger.warning(f"Password exceeds 72 bytes, truncating: {password[:10]}...")
            password_bytes = password_bytes[:72]
            password = password_bytes.decode('utf-8', errors='ignore')
        
        return pwd_context.hash(password)
    
    except Exception as e:
        logger.error(f"Error hashing password: {str(e)}")
        raise ValueError(f"Password hashing failed: {str(e)}")

@router.post("/login")
async def login(request_data: LoginRequest, request: Request, response: Response):
    email = request_data.email
    password = request_data.password
    logger = request.state.logger
    prisma = await get_prisma_client()
    
    try:
        logger.info(f"Login attempt for user with email: {email}")
        
        user = await prisma.aq_users.find_unique(
            where={"email": email},
            include={"aq_user_verification": True}
        )
        
        if not user:
            logger.warning(f"User with email {email} not found")
            raise HTTPException(status_code=400, detail="User not found")
        
        if not safe_verify_password(password, user.password):
            logger.warning(f"Invalid password attempt for user {email}")
            raise HTTPException(status_code=400, detail="Invalid credentials")

        user_roles = await prisma.aq_user_roles.find_many(
            where={"user_id": user.id},
            include={"aq_roles": {"include": {"aq_role_permissions": {"include": {"aq_permissions": True}}}}}
        )
        
        if not user_roles:
            raise HTTPException(status_code=400, detail="No valid roles assigned.")

        roles = [role.aq_roles.role_name for role in user_roles]
        permissions = list({
            perm.aq_permissions.permission_name 
            for role in user_roles 
            for perm in role.aq_roles.aq_role_permissions
        })

        user_info = {
            "id": user.id,
            "email": user.email,
            "first_name": user.first_name,
            "last_name": user.last_name,
            "property_id": user.property_id,
            "roles": roles,
            "permissions": permissions
        }

        logger.info(f"User Info: {user_info}")

        access_token, refresh_token, access_expiry, refresh_expiry = generate_jwt_tokens(user_info)
        
        await prisma.aq_tokens.update_many(
            where={"user_id": user.id, "is_revoked": False},
            data={"is_revoked": True}
        )
        
        await prisma.aq_tokens.create(data={
            "user_id": user.id,
            "token": refresh_token,
            "expires_at": refresh_expiry,
            "is_revoked": False,
            "token_type": "refresh"
        })

        response.set_cookie(
            key="access_token",
            value=access_token,
            httponly=True,
            max_age=1800,
            path="/",
            samesite="None",
            secure=True
        )
        response.set_cookie(
            key="refresh_token",
            value=refresh_token,
            httponly=True,
            max_age=604800,
            path="/",
            samesite="None",
            secure=True
        )

        mfa_enabled = user.aq_user_verification.mfa_enabled if user.aq_user_verification else False
        
        if mfa_enabled:
            otp_code = generate_verification_code()
            otp_expiry = datetime.now(timezone.utc) + timedelta(minutes=3)
            
            if user.aq_user_verification:
                await prisma.aq_user_verification.update(
                    where={"user_id": user.id},
                    data={
                        "email_verification_code": otp_code,
                        "email_verification_code_sent_at": datetime.now(timezone.utc),
                        "email_verification_code_expires_at": otp_expiry
                    }
                )
            else:
                await prisma.aq_user_verification.create(
                    data={
                        "user_id": user.id,
                        "email_verification_code": otp_code,
                        "email_verification_code_sent_at": datetime.now(timezone.utc),
                        "email_verification_code_expires_at": otp_expiry,
                        "mfa_enabled": True
                    }
                )
            
            send_2fa_email(
                to_email=email,
                first_name=user.first_name,
                otp=otp_code
            )
            
            return {
                "success": True,
                "message": "OTP sent to registered email",
                "redirect_url": f"{FRONTEND_URL}/two-factor-otp-verification",
                "requires_otp_verification": True,
                "user_id": user.id
            }

        if user.is_admin and user.first_login:
            return {
                "success": True,
                "message": "Redirecting to property registration.",
                "redirect_url": f"{FRONTEND_URL}/register-property",
                "user": {
                    "id": user.id,
                    "email": user.email,
                    "is_admin": user.is_admin,
                    "first_login": user.first_login,
                },
                "requires_property_registration": True
            }

        if user.first_login:
            return {
                "success": True,
                "message": "Please verify your email to continue.",
                "redirect_url": f"{FRONTEND_URL}/verify-email"
            }

        return {
            "success": True,
            "redirect_url": f"{FRONTEND_URL}/dashboard",
            "user": user_info
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error logging in user with email {email}: {str(e)}")
        raise HTTPException(status_code=400, detail=f"Error logging in: {str(e)}")

@router.get("/verify_token")
async def verify_token(request: Request):
    """Verify the presence of the access token cookie."""
    if not request.cookies.get("access_token"):
        raise HTTPException(status_code=401, detail="No access token provided")
    return {"success": True}

@router.post("/logout")
async def logout(
    request: Request,
    response: Response,
    refresh_token: str = Cookie(default=None)
):
    """Log out a user by revoking tokens and clearing cookies."""
    logger = request.state.logger
    prisma = await get_prisma_client()

    try:
        if refresh_token:
            await prisma.aq_tokens.update_many(
                where={"token": refresh_token, "is_revoked": False},
                data={"is_revoked": True}
            )
            logger.info("Refresh token revoked successfully.")

        response.delete_cookie("access_token", path="/")
        response.delete_cookie("refresh_token", path="/")

        return {"success": True, "message": "Logged out successfully."}

    except Exception as e:
        logger.error(f"Logout error: {str(e)}")
        raise HTTPException(status_code=500, detail="Logout failed.")

@router.post("/verify-2fa-otp")
async def verify_2fa_otp(request_data: OTPVerificationRequest, request: Request):
    """Verify the 2FA OTP for a user."""
    prisma = await get_prisma_client()
    logger = request.state.logger

    try:
        user_id = request_data.user_id
        verification_code = request_data.verification_code

        logger.info(f"Verifying OTP for user: {user_id}")

        user_verification = await prisma.aq_user_verification.find_first(where={"user_id": user_id})

        if not user_verification:
            raise HTTPException(status_code=400, detail="Verification record not found.")

        if user_verification.email_verification_code != verification_code:
            raise HTTPException(status_code=400, detail="Invalid OTP.")

        if datetime.now(timezone.utc) > user_verification.email_verification_code_expires_at:
            raise HTTPException(status_code=400, detail="OTP has expired.")

        return {"success": True, "message": "OTP verified successfully."}

    except HTTPException as he:
        logger.error(f"HTTP error verifying OTP: {str(he.detail)}")
        raise he
    except Exception as e:
        logger.error(f"Unexpected error verifying OTP: {str(e)}")
        raise HTTPException(status_code=500, detail="Internal server error")
