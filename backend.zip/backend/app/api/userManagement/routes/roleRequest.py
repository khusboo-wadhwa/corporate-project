# from fastapi import APIRouter, HTTPException, Depends, status, Request
# from prisma import Prisma
# from datetime import datetime
# from app.core.database import get_prisma_client  # Import the Prisma client dependency
# from app.core.auth import get_current_user
# from app.api.userManagement.schemas.userSchema import RoleRequestPayload
# from app.api.userManagement.utils.wsUtils import broadcast_message  # Import the broadcast utility
 
# # Create an instance of APIRouter
# router = APIRouter()
 
# @router.post("/roleRequest", status_code=status.HTTP_201_CREATED)
# async def request_role(
#     payload: RoleRequestPayload,
#     request: Request,
#     current_user: dict = Depends(get_current_user),
#     prisma: Prisma = Depends(get_prisma_client),
# ):
#     """
#     Allow non-admin users to request a role change.
#     """
#     logger = request.state.logger  # Access the logger from request.state
 
#     logger.info(f"User {current_user.username} is attempting to request the role '{payload.requested_role}'.")
 
#     try:
#         # Ensure the user is not an admin
#         if current_user.is_admin:
#             logger.warning(f"User {current_user.username} (Admin) attempted to request a role change.")
#             raise HTTPException(
#                 status_code=400,
#                 detail="Admins cannot request role changes."
#             )
 
#         # Prevent users from requesting the 'admin' role
#         if payload.requested_role.lower() == "admin":
#             logger.warning(f"User {current_user.username} attempted to request the 'admin' role.")
#             raise HTTPException(
#                 status_code=400,
#                 detail="You cannot request the 'admin' role."
#             )
 
#         # Validate the requested role exists in the aq_roles table
#         role = await prisma.aq_roles.find_unique(
#             where={"role_name": payload.requested_role}
#         )
#         if not role:
#             logger.warning(f"Role '{payload.requested_role}' does not exist.")
#             raise HTTPException(
#                 status_code=400,
#                 detail="The requested role does not exist."
#             )
 
#         if payload.requested_role in current_user.role:
#             logger.warning(f"User {current_user.username} already has the '{payload.requested_role}' role.")
#             raise HTTPException(
#                 status_code=400,
#                 detail=f"You already have the '{payload.requested_role}' role."
#             )
 
 
#         # Check for an existing pending request for the same role
#         existing_request = await prisma.aq_rolerequests.find_first(
#             where={
#                 "user_id": current_user.id,
#                 "requested_role": payload.requested_role,  # Validate by role_name
#                 "status": "pending",
#             }
#         )
#         if existing_request:
#             logger.warning(f"User {current_user.username} already has a pending role request for '{payload.requested_role}'.")
#             raise HTTPException(
#                 status_code=400,
#                 detail="You already have a pending request for this role."
#             )
 
#         # Create a new role request
#         role_request = await prisma.aq_rolerequests.create(
#             data={
#                 "user_id": current_user.id,
#                 "requested_role": payload.requested_role,  # Store role_name
#                 "reason": payload.reason,
#                 "timestamp": datetime.utcnow(),
#                 "status": "pending",
#             }
#         )
 
#         logger.info(f"Role request for '{payload.requested_role}' created successfully for user {current_user.username}.")
 
#         # Prepare the confirmation message
#         confirmation_message = (
#             f"Role request for '{payload.requested_role}' has been submitted. "
#             "The admin will review your request soon."
#         )
 
#         # Broadcast the role request creation to all WebSocket clients
#         broadcast_message_content = (
#             f"New role request submitted by user {current_user.username}. "
#             f"Requested Role: {payload.requested_role}. Reason: {payload.reason}."
#         )
#         await broadcast_message(broadcast_message_content)
 
#         return {
#             "success": True,
#             "message": confirmation_message,
#             "role_request_id": role_request.id,
#         }
 
#     except Exception as e:
#         logger.error(f"Error occurred during role request for user {current_user.username}: {str(e)}")
#         raise HTTPException(
#             status_code=500,
#             detail=f"Error creating role request: {str(e)}"
#         )

from fastapi import APIRouter, HTTPException, Depends, status, Request
from prisma import Prisma
from datetime import datetime
from app.core.database import get_prisma_client
from app.core.auth import get_current_user
from app.api.userManagement.schemas.userSchema import RoleRequestPayload, RoleRequestUpdatePayload
from app.api.userManagement.utils.wsUtils import broadcast_message

router = APIRouter()

@router.post("/roleRequest", status_code=status.HTTP_201_CREATED)
async def request_role(
    payload: RoleRequestPayload,
    request: Request,
    current_user: dict = Depends(get_current_user),
    prisma: Prisma = Depends(get_prisma_client),
):
    """
    Allow normal users to request access to specific pages
    Users must provide their current role in the request
    """
    logger = request.state.logger

    logger.info(f"User {current_user.username} is requesting permission access.")

    try:
        # 1. Block admins from making requests
        if current_user.is_admin:
            logger.warning(f"Admin {current_user.username} attempted to request access.")
            raise HTTPException(
                status_code=400,
                detail="Admins already have access to all permissions."
            )

        # 2. Validate the requested permission exists
        permission = await prisma.aq_permissions.find_unique(
            where={"id": payload.requested_permission_id}
        )
        
        if not permission:
            logger.warning(f"Permission ID '{payload.requested_permission_id}' not found.")
            raise HTTPException(
                status_code=404,
                detail="The requested page access does not exist."
            )

        # 3. Validate that the user actually has the current_role they claim
        user_roles = await prisma.aq_user_roles.find_many(
            where={"user_id": current_user.id},
            include={"aq_roles": True}
        )
        
        # Get user's actual role names
        actual_role_names = [ur.aq_roles.role_name for ur in user_roles]
        
        # Check if claimed current_role matches user's actual roles
        if payload.current_role not in actual_role_names:
            logger.warning(f"User {current_user.username} claimed role '{payload.current_role}' but has roles: {actual_role_names}")
            raise HTTPException(
                status_code=400,
                detail=f"Invalid current role. Your roles are: {', '.join(actual_role_names) if actual_role_names else 'None'}"
            )

        # 4. Check if user already has this permission through their current roles
        already_has_permission = False
        for user_role in user_roles:
            role_permission = await prisma.aq_role_permissions.find_first(
                where={
                    "role_id": user_role.role_id,
                    "permission_id": payload.requested_permission_id
                }
            )
            if role_permission:
                already_has_permission = True
                break
        
        if already_has_permission:
            logger.warning(f"User {current_user.username} already has access to '{permission.permission_name}'")
            raise HTTPException(
                status_code=400,
                detail=f"You already have access to '{permission.permission_name}'."
            )

        # 5. Check for existing pending request for same permission
        existing_request = await prisma.aq_rolerequests.find_first(
            where={
                "user_id": current_user.id,
                "requested_permission_id": payload.requested_permission_id,
                "status": "pending",
            }
        )
        if existing_request:
            logger.warning(f"User {current_user.username} already has pending request for '{permission.permission_name}'")
            raise HTTPException(
                status_code=400,
                detail="You already have a pending request for this page access."
            )

        # 6. Create the page access request with current_role as requested_role
        access_request = await prisma.aq_rolerequests.create(
            data={
                "user_id": current_user.id,
                "requested_permission_id": payload.requested_permission_id,
                "requested_role": payload.current_role,  # Store current role here
                "reason": payload.reason,
                "timestamp": datetime.utcnow(),
                "status": "pending",
            }
        )

        logger.info(f"Page access request created: {current_user.username} (Role: {payload.current_role}) -> {permission.permission_name}")

        # 7. Get parent module info for better context
        parent_info = ""
        if permission.parent_id:
            parent = await prisma.aq_permissions.find_unique(
                where={"id": permission.parent_id}
            )
            if parent:
                parent_info = f"\n📁 Parent Module: {parent.permission_name}"

        # 8. Broadcast notification to admins
        broadcast_message_content = (
            f"📋 PAGE ACCESS REQUEST\n"
            f"👤 User: {current_user.username}\n"
            f"🎯 Current Role: {payload.current_role}\n"
            f"📄 Requested Page: {permission.permission_name}{parent_info}\n"
            f"📝 Reason: {payload.reason}\n"
            f"🆔 Request ID: {access_request.id}"
        )

        await broadcast_message(broadcast_message_content)

        return {
            "success": True,
            "message": f"Access request for '{permission.permission_name}' submitted successfully.",
            "request_id": access_request.id,
            "permission_name": permission.permission_name,
            "permission_id": permission.id,
            "current_role": payload.current_role,
            "timestamp": access_request.timestamp.isoformat() if access_request.timestamp else None
        }

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error in roleRequest for user {current_user.username}: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail=f"An error occurred while processing your request: {str(e)}"
        )
    
    
@router.get("/requestablePages")
async def get_requestable_pages(
    request: Request,
    current_user: dict = Depends(get_current_user),
    prisma: Prisma = Depends(get_prisma_client),
):
    """
    Get all pages that a normal user can request access to
    (pages they don't already have through their roles)
    """
    logger = request.state.logger
    
    try:
        # Get all page permissions - SIMPLIFIED VERSION
        all_pages = await prisma.aq_permissions.find_many(
            where={"permission_type": "page"}
        )
        
        # Sort by name client-side
        all_pages.sort(key=lambda x: x.permission_name)

        # Get user's current permissions through their roles
        user_roles = await prisma.aq_user_roles.find_many(
            where={"user_id": current_user.id}
        )
        
        user_permission_ids = set()
        for user_role in user_roles:
            role_perms = await prisma.aq_role_permissions.find_many(
                where={"role_id": user_role.role_id}
            )
            for rp in role_perms:
                user_permission_ids.add(rp.permission_id)

        # Filter out pages user already has
        requestable_pages = []
        for page in all_pages:
            if page.id not in user_permission_ids:
                # Get parent info if needed
                parent_name = None
                if page.parent_id:
                    parent = await prisma.aq_permissions.find_unique(
                        where={"id": page.parent_id}
                    )
                    if parent:
                        parent_name = parent.permission_name
                
                page_data = {
                    "id": page.id,
                    "name": page.permission_name,
                    "description": page.description,
                    "parent": parent_name,
                    "parent_id": page.parent_id,
                    "route_path": page.route_path
                }
                requestable_pages.append(page_data)

        # Group by parent for better organization
        grouped_pages = {}
        for page in requestable_pages:
            parent_name = page["parent"] or "Other"
            if parent_name not in grouped_pages:
                grouped_pages[parent_name] = []
            grouped_pages[parent_name].append(page)

        logger.info(f"User {current_user.username} fetched {len(requestable_pages)} requestable pages")

        return {
            "success": True,
            "pages": requestable_pages,
            "grouped_pages": grouped_pages,
            "count": len(requestable_pages),
            "user_id": current_user.id,
            "username": current_user.username
        }

    except Exception as e:
        logger.error(f"Error fetching requestable pages for user {current_user.username}: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail=f"Error fetching requestable pages: {str(e)}"
        )