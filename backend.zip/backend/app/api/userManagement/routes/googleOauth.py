# from fastapi import APIRouter, Request, HTTPException, status, Depends
# from app.core.database import get_prisma_client
# from app.api.userManagement.utils.jwt import generate_jwt_tokens
# import httpx
# from datetime import datetime, timedelta
# import secrets

# router = APIRouter()

# GOOGLE_CLIENT_ID = "379455138009-gg187pl9mma89mq6417fkij2u5egiu70.apps.googleusercontent.com"

# @router.post("/auth/google/callback")
# async def google_oauth_callback(request: Request, prisma=Depends(get_prisma_client)):
#     data = await request.json()
#     id_token = data.get("id_token")
    
#     if not id_token:
#         raise HTTPException(status_code=400, detail="Missing id_token")

#     # Verify token with Google
#     async with httpx.AsyncClient() as client:
#         resp = await client.get(
#             f"https://oauth2.googleapis.com/tokeninfo?id_token={id_token}"
#         )
#     if resp.status_code != 200:
#         raise HTTPException(status_code=400, detail="Invalid ID token")

#     google_data = resp.json()
#     if google_data.get("aud") != GOOGLE_CLIENT_ID:
#         raise HTTPException(status_code=403, detail="Invalid audience")

#     email = google_data["email"]
#     first_name = google_data.get("given_name", "")
#     last_name = google_data.get("family_name", "")
#     google_id = google_data["sub"]

#     # Check if user exists
#     existing_user = await prisma.aq_users.find_unique(where={"email": email})

#     if not existing_user:
#         # Check or create 'Admin2' role
#         admin2_role = await prisma.aq_roles.find_unique(where={"role_name": "Admin2"})
#         if not admin2_role:
#             admin2_role = await prisma.aq_roles.create(data={
#                 "role_name": "Admin2",
#                 "description": "Secondary Admin role",
#             })

#             permissions = await prisma.aq_permissions.find_many()
#             for perm in permissions:
#                 await prisma.aq_role_permissions.create(data={
#                     "role_id": admin2_role.id,
#                     "permission_id": perm.id
#                 })

#         # Create new user
#         user = await prisma.aq_users.create(data={
#             "first_name": first_name,
#             "last_name": last_name,
#             "username": email.split('@')[0] + secrets.token_hex(2),
#             "email": email,
#             "is_admin": True,
#             "role": ["Admin2"],
#         })

#         # Assign role
#         await prisma.aq_user_roles.create(data={
#             "user_id": user.id,
#             "role_id": admin2_role.id
#         })

#         # OAuth data
#         await prisma.aq_user_oauth.create(data={
#             "user_id": user.id,
#             "oauth_provider": "google",
#             "oauth_provider_id": google_id,
#             "is_oauth_user": True
#         })

#         # Security info
#         await prisma.aq_user_security.create(data={
#             "user_id": user.id
#         })

#         # Verification info
#         await prisma.aq_user_verification.create(data={
#             "user_id": user.id
#         })

#     else:
#         user = existing_user

#     # Generate tokens
#     access_token, refresh_token, access_exp, refresh_exp = generate_jwt_tokens(user)

#     await prisma.aq_tokens.create_many(data=[
#         {
#             "user_id": user.id,
#             "token": access_token,
#             "token_type": "access",
#             "expires_at": access_exp
#         },
#         {
#             "user_id": user.id,
#             "token": refresh_token,
#             "token_type": "refresh",
#             "expires_at": refresh_exp
#         }
#     ])

#     return {
#         "access_token": access_token,
#         "refresh_token": refresh_token,
#         "token_type": "bearer",
#         "user": {
#             "id": user.id,
#             "first_name": user.first_name,
#             "last_name": user.last_name,
#             "email": user.email,
#             "roles": user.role
#         }
#     }



from fastapi import APIRouter, Request, HTTPException, status, Depends
from app.core.database import get_prisma_client
from app.api.userManagement.utils.jwt import generate_jwt_tokens
import httpx
from datetime import datetime, timedelta
import secrets
import logging
from fastapi.responses import RedirectResponse

# Setting up logging
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

# You might want to configure logging to file or console output if necessary
# logging.basicConfig(level=logging.INFO)

router = APIRouter()

GOOGLE_CLIENT_ID = "379455138009-gg187pl9mma89mq6417fkij2u5egiu70.apps.googleusercontent.com"  # Ensure this is set properly

@router.post("/auth/google/callback")
async def google_oauth_callback(request: Request, prisma=Depends(get_prisma_client)):
    logger.info("Google callback route hit")

    data = await request.json()
    id_token = data.get("id_token")

    if not id_token:
        raise HTTPException(status_code=400, detail="Missing id_token")

    try:
        async with httpx.AsyncClient() as client:
            resp = await client.get(f"https://oauth2.googleapis.com/tokeninfo?id_token={id_token}")

        if resp.status_code != 200:
            raise HTTPException(status_code=400, detail="Invalid ID token")

        google_data = resp.json()

        if google_data.get("aud") != GOOGLE_CLIENT_ID:
            raise HTTPException(status_code=403, detail="Invalid audience")

        email = google_data["email"]
        first_name = google_data.get("given_name", "")
        last_name = google_data.get("family_name", "")
        google_id = google_data["sub"]

        existing_user = await prisma.aq_users.find_unique(where={"email": email})

        if not existing_user:
            admin2_role = await prisma.aq_roles.find_unique(where={"role_name": "Admin2"})

            if not admin2_role:
                admin2_role = await prisma.aq_roles.create(data={
                    "role_name": "Admin2",
                    "description": "Secondary Admin role",
                })

                permissions = await prisma.aq_permissions.find_many()
                role_perm_data = [
                    {
                        "role_id": admin2_role.id,
                        "permission_id": perm.id
                    } for perm in permissions
                ]
                await prisma.aq_role_permissions.create_many(data=role_perm_data, skip_duplicates=True)

            user = await prisma.aq_users.create(data={
                "first_name": first_name,
                "last_name": last_name,
                "username": email.split('@')[0] + secrets.token_hex(2),
                "email": email,
                "is_admin": True,
                "role": ["Admin2"],
            })

            await prisma.aq_user_roles.create(data={
                "user_id": user.id,
                "role_id": admin2_role.id
            })

            await prisma.aq_user_oauth.create(data={
                "user_id": user.id,
                "oauth_provider": "google",
                "oauth_provider_id": google_id,
                "is_oauth_user": True
            })

            await prisma.aq_user_security.create(data={"user_id": user.id})
            await prisma.aq_user_verification.create(data={"user_id": user.id})
        else:
            user = existing_user

        # Updated roles and permissions logic (same as /login)
        user_roles = await prisma.aq_user_roles.find_many(
            where={"user_id": user.id},
            include={"aq_roles": {"include": {"aq_role_permissions": {"include": {"aq_permissions": True}}}}}
        )

        if not user_roles:
            logger.warning(f"User {email} does not have valid roles assigned.")
            raise HTTPException(status_code=400, detail="No valid roles assigned to this user.")

        roles = [role.aq_roles.role_name for role in user_roles]
        permissions = list({
            perm.aq_permissions.permission_name
            for role in user_roles
            for perm in role.aq_roles.aq_role_permissions
        })

        user_info = {
            "id": user.id,
            "email": user.email,
            "first_name": user.first_name,
            "last_name": user.last_name,
            "roles": roles,
            "permissions": permissions
        }

        access_token, refresh_token, access_exp, refresh_exp = generate_jwt_tokens(user_info)

        await prisma.aq_tokens.create_many(data=[
            {
                "user_id": user.id,
                "token": access_token,
                "token_type": "access",
                "expires_at": access_exp
            },
            {
                "user_id": user.id,
                "token": refresh_token,
                "token_type": "refresh",
                "expires_at": refresh_exp
            }
        ])

        return {
            "access_token": access_token,
            "refresh_token": refresh_token,
            "token_type": "bearer",
            "redirect_url": "http://localhost:3000/dashboard",
            "user": user_info
        }

    except httpx.RequestError as e:
        logger.error(f"HTTP error: {e}")
        raise HTTPException(status_code=500, detail="Error verifying token")

    except Exception as e:
        logger.error(f"Unexpected error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

