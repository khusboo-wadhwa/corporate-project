


# #websocket and logs

# from fastapi import APIRouter, HTTPException, Depends, status, Request
# from prisma import Prisma
# from app.core.database import get_prisma_client
# from app.core.auth import get_current_user
# from app.api.userManagement.schemas.userSchema import UserRoleEnum  # Assuming you have UserRoleEnum
# from app.api.userManagement.utils.wsUtils import broadcast_message  # Import WebSocket utility

# router = APIRouter()

# @router.delete("/deleteRole", status_code=status.HTTP_200_OK)
# async def delete_role(
#     user_id: int,  # The ID of the user to delete the role from
#     role_to_remove: UserRoleEnum,request: Request,  # The specific role to remove
#     current_user: dict = Depends(get_current_user),  # Get the current authenticated user
#     prisma: Prisma = Depends(get_prisma_client)  # Inject Prisma client here
#       # Access the request object to get the logger
# ):
#     """
#     Allow admins to delete a specific role from a user.
#     This will remove the specified role from the user's role list.
#     """
#     logger = request.state.logger  # Access the logger from request.state
#     logger.info(f"Admin {current_user.username} is attempting to delete role '{role_to_remove}' from user {user_id}.")

#     # Ensure the current user is an admin
#     if not current_user.is_admin:
#         logger.warning(f"Non-admin user {current_user.username} tried to delete a role from user {user_id}.")
#         raise HTTPException(
#             status_code=403,
#             detail="Only admins can delete user roles."
#         )

#     # Fetch the user from the database
#     user = await prisma.aq_users.find_unique(where={"id": user_id})
#     if not user:
#         logger.error(f"User with ID {user_id} not found.")
#         raise HTTPException(
#             status_code=404,
#             detail="User not found."
#         )

#     # Check if the user has the role to delete
#     if role_to_remove not in user.role:
#         logger.warning(f"User {user_id} does not have the role '{role_to_remove}' to delete.")
#         raise HTTPException(
#             status_code=400,
#             detail=f"User does not have the role '{role_to_remove}' to delete."
#         )

#     # Remove the specific role from the user's roles
#     try:
#         updated_user = await prisma.aq_users.update(
#             where={"id": user_id},
#             data={
#                 "role": {"set": [role for role in user.role if role != role_to_remove]}  # Remove only the specified role
#             }
#         )
#         logger.info(f"Successfully removed role '{role_to_remove}' from user {user_id}.")
#     except Exception as e:
#         logger.error(f"Error deleting role '{role_to_remove}' from user {user_id}: {str(e)}")
#         raise HTTPException(
#             status_code=500,
#             detail=f"Error deleting user role: {str(e)}"
#         )

#     # Broadcast the role deletion event to connected WebSocket clients
#     try:
#         broadcast_message_content = f"Role '{role_to_remove}' has been removed from user {user_id}."
#         await broadcast_message(broadcast_message_content)
#         logger.info(f"Broadcasted message: {broadcast_message_content}")
#     except Exception as e:
#         logger.error(f"Error broadcasting message: {str(e)}")

#     return {
#         "success": True,
#         "message": f"Role '{role_to_remove}' has been successfully removed from user {user_id}."
#     }

from fastapi import APIRouter, HTTPException, Depends, status, Request
from prisma import Prisma
from app.core.database import get_prisma_client
from app.core.auth import get_current_user
from app.api.userManagement.utils.wsUtils import broadcast_message  # Import WebSocket utility

router = APIRouter()

@router.delete("/deleteRole", status_code=status.HTTP_200_OK)
async def delete_role(
    user_id: int,  # The ID of the user to delete the role from
    role_name: str,  # The name of the role to remove (instead of using an enum)
    request: Request,  # The request object to access the logger
    current_user: dict = Depends(get_current_user),  # Get the current authenticated user
    prisma: Prisma = Depends(get_prisma_client)  # Inject Prisma client here
):
    """
    Allow admins to delete a specific role from a user.
    This will remove the specified role from the user's role list.
    """
    logger = request.state.logger  # Access the logger from request.state
    logger.info(f"Admin {current_user.username} is attempting to delete role '{role_name}' from user {user_id}.")

    # Ensure the current user is an admin
    if not current_user.is_admin:
        logger.warning(f"Non-admin user {current_user.username} tried to delete a role from user {user_id}.")
        raise HTTPException(
            status_code=403,
            detail="Only admins can delete user roles."
        )

    # Fetch the role from the aq_roles table
    role = await prisma.aq_roles.find_unique(where={"role_name": role_name})
    if not role:
        logger.error(f"Role '{role_name}' not found in 'aq_roles'.")
        raise HTTPException(
            status_code=404,
            detail=f"Role '{role_name}' not found."
        )

    # Fetch the user from the database
    user = await prisma.aq_users.find_unique(where={"id": user_id})
    if not user:
        logger.error(f"User with ID {user_id} not found.")
        raise HTTPException(
            status_code=404,
            detail="User not found."
        )

    # Check if the user has the role to delete
    if role_name not in user.role:
        logger.warning(f"User {user_id} does not have the role '{role_name}' to delete.")
        raise HTTPException(
            status_code=400,
            detail=f"User does not have the role '{role_name}' to delete."
        )

    # Remove the specific role from the user's roles (Update the user's roles list)
    try:
        updated_user = await prisma.aq_users.update(
            where={"id": user_id},
            data={
                "role": {"set": [role for role in user.role if role != role_name]}  # Remove only the specified role
            }
        )
        logger.info(f"Successfully removed role '{role_name}' from user {user_id}.")
    except Exception as e:
        logger.error(f"Error deleting role '{role_name}' from user {user_id}: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail=f"Error deleting user role: {str(e)}"
        )

    # Remove the role from the aq_user_roles table by deleting the relationship
    try:
        # First, find the role_id corresponding to the role_name
        role_record = await prisma.aq_roles.find_unique(where={"role_name": role_name})
        if role_record:
            # Delete the corresponding relationship in aq_user_roles table
            await prisma.aq_user_roles.delete_many(
                where={
                    "user_id": user_id,
                    "role_id": role_record.id
                }
            )
            logger.info(f"Successfully removed role '{role_name}' from aq_user_roles table for user {user_id}.")
    except Exception as e:
        logger.error(f"Error removing role from aq_user_roles table: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail=f"Error removing role from aq_user_roles table: {str(e)}"
        )

    # Broadcast the role deletion event to connected WebSocket clients
    try:
        broadcast_message_content = f"Role '{role_name}' has been removed from user {user_id}."
        await broadcast_message(broadcast_message_content)
        logger.info(f"Broadcasted message: {broadcast_message_content}")
    except Exception as e:
        logger.error(f"Error broadcasting message: {str(e)}")

    return {
        "success": True,
        "message": f"Role '{role_name}' has been successfully removed from user {user_id}."
    }
