
# from fastapi import APIRouter, HTTPException
# from prisma import Prisma

# router = APIRouter()

# @router.post("/check_email_verification")
# async def check_email_verification(email: str):
#     """
#     Check if the email exists in the database and verify its status.
    
#     Args:
#         email (str): The email address to check.

#     Returns:
#         dict: A message indicating the email's verification status.
#     """
#     prisma = Prisma()
#     if not prisma.is_connected():
#         await prisma.connect()

#     try:
#         # Check if the user exists in the database
#         user = await prisma.aq_users.find_unique(where={"email": email})
#         if not user:
#             raise HTTPException(status_code=200, detail="Email does not exist in the database")

#         # Check if the email is already verified
#         if user.is_email_verified:
#             return {
#                 "success": True,
#                 "message": "Email is already verified",
#                 "email": email
#             }

#         # Check if the verification code is set
#         if user.email_verification_code is None:
#             raise HTTPException(
#                 status_code=200,
#                 detail="Verification code is not set for this email"
#             )

#         # If verification code exists and email is not verified
#         return {
#             "success": True,
#             "message": "Verification code is present for this email",
#             "email": email,
#             "verification_code": user.email_verification_code
#         }

#     except HTTPException as http_exc:
#         raise http_exc
#     except Exception as e:
#         raise HTTPException(
#             status_code=500,
#             detail=f"An error occurred while checking email verification: {str(e)}"
#         )
#     finally:
#         await prisma.disconnect()



# #logs
# from fastapi import APIRouter, HTTPException, Request
# from prisma import Prisma

# router = APIRouter()

# @router.post("/check_email_verification")
# async def check_email_verification(
#     email: str,
#     request: Request  # Access the logger from request.state
# ):
#     """
#     Check if the email exists in the database and verify its status.
    
#     Args:
#         email (str): The email address to check.

#     Returns:
#         dict: A message indicating the email's verification status.
#     """
#     logger = request.state.logger  # Access the logger from request.state

#     prisma = Prisma()
#     if not prisma.is_connected():
#         await prisma.connect()

#     try:
#         logger.info(f"Checking verification status for email: {email}")

#         # Check if the user exists in the database
#         user = await prisma.aq_users.find_unique(where={"email": email})
#         if not user:
#             logger.warning(f"Email {email} not found in the database.")
#             raise HTTPException(status_code=200, detail="Email does not exist in the database")

#         # Check if the email is already verified
#         if user.is_email_verified:
#             logger.info(f"Email {email} is already verified.")
#             return {
#                 "success": True,
#                 "message": "Email is already verified",
#                 "email": email
#             }

#         # Check if the verification code is set
#         if user.email_verification_code is None:
#             logger.warning(f"No verification code set for email {email}.")
#             raise HTTPException(
#                 status_code=200,
#                 detail="Verification code is not set for this email"
#             )

#         # If verification code exists and email is not verified
#         logger.info(f"Verification code exists for email {email}.")
#         return {
#             "success": True,
#             "message": "Verification code is present for this email",
#             "email": email,
#             "verification_code": user.email_verification_code
#         }

#     except HTTPException as http_exc:
#         logger.error(f"HTTPException occurred: {http_exc.detail}")
#         raise http_exc
#     except Exception as e:
#         logger.error(f"An error occurred while checking email verification for {email}: {str(e)}")
#         raise HTTPException(
#             status_code=500,
#             detail=f"An error occurred while checking email verification: {str(e)}"
#         )
#     finally:
#         await prisma.disconnect()
#         logger.info(f"Disconnected from Prisma client after checking email {email}.")



from fastapi import APIRouter, HTTPException, Request
from prisma import Prisma

router = APIRouter()

@router.post("/check_email_verification")
async def check_email_verification(
    email: str,
    request: Request
):
    """
    Check if the email exists and whether the email is verified.
    """
    logger = request.state.logger
    prisma = Prisma()

    if not prisma.is_connected():
        await prisma.connect()

    try:
        logger.info(f"Checking verification status for email: {email}")

        # ✅ Fetch user and include the related verification data
        user = await prisma.aq_users.find_unique(
            where={"email": email},
            include={"aq_user_verification": True}
        )

        if not user:
            logger.warning(f"Email {email} not found in the database.")
            raise HTTPException(status_code=200, detail="Email does not exist in the database")

        verification = user.aq_user_verification

        # ✅ Handle if verification info is missing
        if not verification:
            logger.warning(f"No verification info found for email {email}.")
            raise HTTPException(status_code=200, detail="Verification data not found for this user")

        if verification.is_email_verified:
            logger.info(f"Email {email} is already verified.")
            return {
                "success": True,
                "message": "Email is already verified",
                "email": email
            }

        if not verification.email_verification_code:
            logger.warning(f"No verification code set for email {email}.")
            raise HTTPException(
                status_code=200,
                detail="Verification code is not set for this email"
            )

        # ✅ Code exists and not yet verified
        logger.info(f"Verification code exists for email {email}.")
        return {
            "success": True,
            "message": "Verification code is present for this email",
            "email": email,
            "verification_code": verification.email_verification_code
        }

    except HTTPException as http_exc:
        logger.error(f"HTTPException occurred: {http_exc.detail}")
        raise http_exc
    except Exception as e:
        logger.error(f"An error occurred while checking email verification for {email}: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail=f"An error occurred while checking email verification: {str(e)}"
        )
    finally:
        await prisma.disconnect()
        logger.info(f"Disconnected from Prisma client after checking email {email}.")
