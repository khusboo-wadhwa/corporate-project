"""after login with temp password ,users use this api for the reset new password
input in  email of user  and new password and confirm passwoord"""
# from fastapi import APIRouter, HTTPException, Depends
# from pydantic import BaseModel, EmailStr, Field, validator
# from app.core.database import get_prisma_client
# from app.api.userManagement.utils.passwordUtils import hash_password
# from app.core.auth import get_current_user  # Assumes you have a JWT dependency

# # Define password regex
# PASSWORD_REGEX = r"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,16}$"

# router = APIRouter()

# class ResetNewPasswordRequest(BaseModel):
#     new_password: str = Field(..., min_length=8, max_length=16, description="The new password")
#     confirm_password: str = Field(..., min_length=8, max_length=16, description="The confirmation of the new password")

#     @validator("new_password")
#     def validate_password(cls, value):
#         import re
#         if not re.match(PASSWORD_REGEX, value):
#             raise ValueError(
#                 "Password must be 8-16 characters long, include at least one uppercase letter, one lowercase letter, one number, and one special character (@$!%*?&)."
#             )
#         return value


# @router.post("/resetNewPasswordNonAdmin")
# async def reset_new_password(
#     request: ResetNewPasswordRequest,
#     current_user: dict = Depends(get_current_user),  # Fetch the current user
#     prisma=Depends(get_prisma_client)
# ):
#     """
#     Allows a logged-in user to reset their password.
#     The user must log in with a temporary password to use this endpoint.
#     """
#     try:
#         # Step 1: Fetch the user
#         user = await prisma.aq_users.find_first(where={"email": current_user.email})
#         if not user:
#             raise HTTPException(status_code=404, detail="User not found")

#         # Step 2: Check if the user logged in with a temporary password
#         if not user.temp_password:
#             raise HTTPException(
#                 status_code=400, detail="Temporary password not detected. Cannot reset password."
#             )

#         # Step 3: Validate new passwords match
#         if request.new_password != request.confirm_password:
#             raise HTTPException(status_code=400, detail="Passwords do not match")

#         # Step 4: Hash the new password
#         hashed_new_password = hash_password(request.new_password)

#         # Step 5: Update the user's password and clear the temp_password
#         await prisma.aq_users.update(
#             where={"email": user.email},
#             data={"password": hashed_new_password, "temp_password": None}
#         )

#         return {"success": True, "message": "Password has been successfully updated"}

#     except Exception as e:
#         raise HTTPException(status_code=400, detail=f"Error resetting password: {str(e)}")



#logs
from fastapi import APIRouter, HTTPException, Depends, Request
from pydantic import BaseModel, Field, validator
from app.core.database import get_prisma_client
from app.api.userManagement.utils.passwordUtils import hash_password
from app.core.auth import get_current_user  # Assumes you have a JWT dependency

# Define password regex
PASSWORD_REGEX = r"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,16}$"

router = APIRouter()

class ResetNewPasswordRequest(BaseModel):
    new_password: str = Field(..., min_length=8, max_length=16, description="The new password")
    confirm_password: str = Field(..., min_length=8, max_length=16, description="The confirmation of the new password")

    @validator("new_password")
    def validate_password(cls, value):
        import re
        if not re.match(PASSWORD_REGEX, value):
            raise ValueError(
                "Password must be 8-16 characters long, include at least one uppercase letter, one lowercase letter, one number, and one special character (@$!%*?&)."
            )
        return value


@router.post("/resetNewPasswordNonAdmin")
async def reset_new_password(
    request: ResetNewPasswordRequest,req: Request, 
    current_user: dict = Depends(get_current_user),  # Fetch the current user
    prisma=Depends(get_prisma_client)
     # Access logger via request state
):
    """
    Allows a logged-in user to reset their password.
    The user must log in with a temporary password to use this endpoint.
    """
    logger = req.state.logger  # Access logger from request state

    try:
        # Step 1: Fetch the user
        logger.info(f"Fetching user with email: {current_user.email}")
        user = await prisma.aq_users.find_first(where={"email": current_user.email})
        if not user:
            logger.warning(f"User with email {current_user.email} not found.")
            raise HTTPException(status_code=404, detail="User not found")

        # Step 2: Check if the user logged in with a temporary password
        if not user.temp_password:
            logger.warning(f"User {current_user.email} attempted to reset password without a temporary password.")
            raise HTTPException(
                status_code=400, detail="Temporary password not detected. Cannot reset password."
            )

        # Step 3: Validate new passwords match
        if request.new_password != request.confirm_password:
            logger.warning(f"Password mismatch for user {current_user.email}.")
            raise HTTPException(status_code=400, detail="Passwords do not match")

        # Step 4: Hash the new password
        logger.info(f"Hashing new password for user {current_user.email}.")
        hashed_new_password = hash_password(request.new_password)

        # Step 5: Update the user's password and clear the temp_password
        logger.info(f"Updating password for user {current_user.email}.")
        await prisma.aq_users.update(
            where={"email": user.email},
            data={"password": hashed_new_password, "temp_password": None}
        )

        logger.info(f"Password successfully updated for user {current_user.email}.")
        return {"success": True, "message": "Password has been successfully updated"}

    except HTTPException as http_exc:
        logger.error(f"HTTPException: {http_exc.detail}")
        raise http_exc

    except Exception as e:
        logger.error(f"Unexpected error resetting password for user {current_user.email}: {str(e)}")
        raise HTTPException(status_code=400, detail=f"Error resetting password: {str(e)}")
