# import re
# from fastapi import APIRouter
# from app.api.userManagement.utils.passwordUtils import hash_password, verify_password
# from app.core.auth import get_user_by_email, update_user_password
# from app.api.userManagement.schemas.userSchema import ChangePasswordRequest

# # Regular expression for password validation
# PASSWORD_REGEX = r"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,16}$"

# router = APIRouter()

# @router.post("/updatePassword")
# async def change_password(request: ChangePasswordRequest):
#     try:
#         # Retrieve user by email
#         user = await get_user_by_email(request.email)
#         if not user:
#             return {
#                 "success": False,
#                 "message": "User with the provided email does not exist."
#             }

#         # Verify current password
#         if not verify_password(request.current_password, user.password):
#             return {
#                 "success": False,
#                 "message": "The current password is incorrect."
#             }

#         # Check if the new password matches the confirmation
#         if request.new_password != request.confirm_password:
#             return {
#                 "success": False,
#                 "message": "The new password and confirm password do not match."
#             }

#         # Validate the new password strength
#         if not re.match(PASSWORD_REGEX, request.new_password):
#             return {
#                 "success": False,
#                 "message": (
#                     "Password does not meet the criteria. "
#                     "It must be 8-16 characters long and include at least one lowercase letter, "
#                     "one uppercase letter, one number, and one special character."
#                 )
#             }

#         # Hash the new password
#         hashed_password = hash_password(request.new_password)

#         # Update the password in the database
#         await update_user_password(request.email, hashed_password)

#         return {
#             "success": True,
#             "message": "Password has been updated successfully."
#         }

#     except Exception as e:
#         return {
#             "success": False,
#             "message": "An error occurred while updating the password.",
#             "error": str(e)
#         }



#logs
import re
from fastapi import APIRouter, HTTPException, Request
from app.api.userManagement.utils.passwordUtils import hash_password, verify_password
from app.core.auth import get_user_by_email, update_user_password
from app.api.userManagement.schemas.userSchema import ChangePasswordRequest
from app.api.userManagement.utils.wsUtils import broadcast_message  # Import WebSocket utility

# Regular expression for password validation
PASSWORD_REGEX = r"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,16}$"

router = APIRouter()

@router.post("/updatePassword")
async def change_password(request: ChangePasswordRequest, req: Request):
    logger = req.state.logger  # Access logger from request.state

    try:
        # Retrieve user by email
        user = await get_user_by_email(request.email)
        if not user:
            logger.warning(f"Attempt to update password for non-existent user with email: {request.email}")
            return {
                "success": False,
                "message": "User with the provided email does not exist."
            }

        logger.info(f"Password update requested for user with email: {request.email}")

        # Verify current password
        if not verify_password(request.current_password, user.password):
            logger.warning(f"Incorrect current password for user with email: {request.email}")
            return {
                "success": False,
                "message": "The current password is incorrect."
            }

        # Check if the new password matches the confirmation
        if request.new_password != request.confirm_password:
            logger.warning(f"New password and confirmation do not match for user with email: {request.email}")
            return {
                "success": False,
                "message": "The new password and confirm password do not match."
            }

        # Validate the new password strength
        if not re.match(PASSWORD_REGEX, request.new_password):
            logger.warning(f"Password validation failed for user with email: {request.email}")
            return {
                "success": False,
                "message": (
                    "Password does not meet the criteria. "
                    "It must be 8-16 characters long and include at least one lowercase letter, "
                    "one uppercase letter, one number, and one special character."
                )
            }

        # Hash the new password
        hashed_password = hash_password(request.new_password)
        logger.info(f"Password for user with email: {request.email} will be updated.")

        # Update the password in the database
        await update_user_password(request.email, hashed_password)

        # Broadcast the password update event
        broadcast_message_content = f"User with email {request.email} has updated their password."
        try:
            await broadcast_message(broadcast_message_content)
            logger.info(f"Broadcasted password update message: {broadcast_message_content}")
        except Exception as e:
            logger.error(f"Error broadcasting password update message: {str(e)}")

        return {
            "success": True,
            "message": "Password has been updated successfully."
        }

    except Exception as e:
        logger.error(f"Error occurred while updating password for user with email {request.email}: {str(e)}")
        return {
            "success": False,
            "message": "An error occurred while updating the password.",
            "error": str(e)
        }
