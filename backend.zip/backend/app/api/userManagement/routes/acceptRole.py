from fastapi import APIRouter, HTTPException, Depends, status, Request
from prisma import Prisma
from datetime import datetime
from app.core.database import get_prisma_client
from app.core.auth import get_current_user
from app.api.userManagement.schemas.userSchema import RoleRequestUpdatePayload
from app.api.userManagement.utils.wsUtils import broadcast_message

router = APIRouter()

@router.post("/roleAccept", status_code=status.HTTP_200_OK)
async def accept_permission_request(
    role_request_id: int,
    payload: RoleRequestUpdatePayload,
    request: Request,
    current_user: dict = Depends(get_current_user),
    prisma: Prisma = Depends(get_prisma_client),
):
    """
    Admin accepts permission request
    Adds the requested permission to user's role in aq_role_permissions table
    """
    logger = request.state.logger

    logger.info(f"Admin {current_user.username} is attempting to accept permission request ID {role_request_id}.")

    if not current_user.is_admin:
        logger.warning(f"Non-admin user {current_user.username} tried to accept a permission request.")
        raise HTTPException(
            status_code=403,
            detail="Only admins can accept permission requests."
        )

    # 1. Get the request with user, permission, and role details
    role_request = await prisma.aq_rolerequests.find_unique(
        where={"id": role_request_id},
        include={
            "aq_users": True,
            "aq_permissions": True  # Get permission details
        }
    )
    
    if not role_request:
        logger.error(f"Permission request ID {role_request_id} not found.")
        raise HTTPException(
            status_code=404,
            detail="Permission request not found."
        )

    if role_request.status != "pending":
        logger.warning(f"Attempt to accept request ID {role_request_id}, but it's not in 'pending' state.")
        raise HTTPException(
            status_code=400,
            detail="Only pending permission requests can be accepted."
        )

    # Check if requested permission exists
    if not role_request.requested_permission_id or not role_request.aq_permissions:
        logger.error(f"Permission request ID {role_request_id} has no valid permission.")
        raise HTTPException(
            status_code=400,
            detail="Invalid permission request. No permission specified."
        )

    # Check if user exists
    if not role_request.user_id or not role_request.aq_users:
        logger.error(f"Permission request ID {role_request_id} has no valid user.")
        raise HTTPException(
            status_code=400,
            detail="Invalid permission request. No user specified."
        )

    try:
        # 2. Get the user's role from aq_user_roles table
        # First, get the requested role (this is the role the permission will be added to)
        requested_role = await prisma.aq_roles.find_unique(
            where={"role_name": role_request.requested_role}
        )
        
        if not requested_role:
            logger.error(f"Role '{role_request.requested_role}' not found.")
            raise HTTPException(
                status_code=404,
                detail=f"Role '{role_request.requested_role}' not found."
            )
        
        # 3. Check if user has this role in aq_user_roles table
        user_role = await prisma.aq_user_roles.find_first(
            where={
                "user_id": role_request.user_id,
                "role_id": requested_role.id
            }
        )
        
        if not user_role:
            logger.error(f"User ID {role_request.user_id} does not have role '{role_request.requested_role}'.")
            raise HTTPException(
                status_code=400,
                detail=f"User does not have the role '{role_request.requested_role}'."
            )
        
        # 4. Check if permission already exists for this role in aq_role_permissions
        existing_permission = await prisma.aq_role_permissions.find_first(
            where={
                "role_id": requested_role.id,
                "permission_id": role_request.requested_permission_id
            }
        )
        
        if existing_permission:
            logger.warning(f"Permission ID {role_request.requested_permission_id} already exists for role '{role_request.requested_role}'.")
            # Still update the request status, but don't add duplicate permission
            success_message = f"Permission '{role_request.aq_permissions.permission_name}' was already assigned to role '{role_request.requested_role}'."
        else:
            # 5. Add the permission to the role in aq_role_permissions table
            await prisma.aq_role_permissions.create(
                data={
                    "role_id": requested_role.id,
                    "permission_id": role_request.requested_permission_id
                }
            )
            logger.info(f"Permission ID {role_request.requested_permission_id} added to role '{role_request.requested_role}' (ID: {requested_role.id})")
            success_message = f"Permission '{role_request.aq_permissions.permission_name}' has been granted to role '{role_request.requested_role}' for user {role_request.aq_users.email}."

        # 6. Update request status to 'approved'
        updated_request = await prisma.aq_rolerequests.update(
            where={"id": role_request_id},
            data={
                "status": "approved",
                "updated_date": datetime.utcnow(),
                "admin_comment": payload.admin_comment
            }
        )
        logger.info(f"Permission request ID {role_request_id} status updated to 'approved'.")

        # 7. Broadcast success
        broadcast_message_content = f"Permission request ID {role_request_id} approved by admin {current_user.username}. {success_message}"
        if payload.admin_comment:
            broadcast_message_content += f" Admin comment: {payload.admin_comment}"
        
        await broadcast_message(broadcast_message_content)
        logger.info(f"Success message broadcasted: {broadcast_message_content}")

        return {
            "success": True,
            "message": success_message,
            "permission_name": role_request.aq_permissions.permission_name,
            "user_email": role_request.aq_users.email,
            "role_name": role_request.requested_role,
            "permission_id": role_request.requested_permission_id
        }

    except Exception as e:
        logger.error(f"Error occurred while accepting permission request ID {role_request_id}: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail=f"Error accepting permission request: {str(e)}"
        )
# from fastapi import APIRouter, HTTPException, Depends, status, Request
# from prisma import Prisma
# from datetime import datetime
# from app.core.database import get_prisma_client
# from app.core.auth import get_current_user
# from app.api.userManagement.schemas.userSchema import RoleRequestUpdatePayload
# from app.api.userManagement.utils.wsUtils import broadcast_message  # Import the broadcast utility

# router = APIRouter()

# @router.post("/roleAccept", status_code=status.HTTP_200_OK)
# async def accept_role_request(
#     role_request_id: int,
#     payload: RoleRequestUpdatePayload,
#     request: Request,
#     current_user: dict = Depends(get_current_user),
#     prisma: Prisma = Depends(get_prisma_client),
# ):
#     """
#     Allow admins to accept a role request and append the role to the user's existing roles.
#     """
#     logger = request.state.logger  # Access the logger from request.state

#     # Log the role acceptance attempt
#     logger.info(f"Admin {current_user.username} is attempting to accept role request ID {role_request_id}.")

#     # Ensure the current user is an admin
#     if not current_user.is_admin:
#         logger.warning(f"Non-admin user {current_user.username} tried to accept a role request.")
#         raise HTTPException(
#             status_code=403,
#             detail="Only admins can accept role requests."
#         )

#     # Fetch the role request from the database
#     role_request = await prisma.aq_rolerequests.find_unique(
#         where={"id": role_request_id},
#         include={"aq_users": True}  # Include user details if needed
#     )
#     if not role_request:
#         logger.error(f"Role request ID {role_request_id} not found.")
#         raise HTTPException(
#             status_code=404,
#             detail="Role request not found."
#         )

#     # Ensure the role request is in a "pending" state
#     if role_request.status != "pending":
#         logger.warning(f"Attempt to accept role request ID {role_request_id}, but it's not in 'pending' state.")
#         raise HTTPException(
#             status_code=400,
#             detail="Only pending role requests can be accepted."
#         )

#     # Check if the requested role is already assigned to the user
#     user = await prisma.aq_users.find_unique(where={"id": role_request.user_id})
#     if role_request.requested_role in user.role:
#         logger.warning(f"Role '{role_request.requested_role}' already assigned to user ID {role_request.user_id}.")
#         raise HTTPException(
#             status_code=400,
#             detail="Role already assigned to the user."
#         )

#     # Update the role request status to "accepted"
#     try:
#         updated_request = await prisma.aq_rolerequests.update(
#             where={"id": role_request_id},
#             data={
#                 "status": "accepted",
#                 "timestamp": datetime.utcnow(),
#                 "admin_comment": payload.admin_comment
#             }
#         )
#         logger.info(f"Role request ID {role_request_id} status updated to 'accepted'.")
#     except Exception as e:
#         logger.error(f"Error occurred while updating role request ID {role_request_id}: {str(e)}")
#         raise HTTPException(
#             status_code=500,
#             detail=f"Error updating role request status: {str(e)}"
#         )

#     # Append the new role to the user's existing roles
#     try:
#         await prisma.aq_users.update(
#             where={"id": role_request.user_id},
#             data={"role": {"push": role_request.requested_role}}
#         )
#         logger.info(f"Role '{role_request.requested_role}' appended to user ID {role_request.user_id}.")
#     except Exception as e:
#         logger.error(f"Error occurred while appending role to user ID {role_request.user_id}: {str(e)}")
#         raise HTTPException(
#             status_code=500,
#             detail=f"Error appending user role: {str(e)}"
#         )

#     # Fetch the role_id for the requested role
#     role = await prisma.aq_roles.find_unique(where={"role_name": role_request.requested_role})
#     if not role:
#         logger.error(f"Role '{role_request.requested_role}' not found in 'aq_roles'.")
#         raise HTTPException(
#             status_code=404,
#             detail=f"Role '{role_request.requested_role}' not found."
#         )

#     # Insert a new record into the aq_user_roles table
#     try:
#         await prisma.aq_user_roles.create(
#             data={
#                 "user_id": role_request.user_id,
#                 "role_id": role.id
#             }
#         )
#         logger.info(f"Role ID {role.id} assigned to User ID {role_request.user_id} in 'aq_user_roles'.")
#     except Exception as e:
#         logger.error(f"Error occurred while inserting role assignment: {str(e)}")
#         raise HTTPException(
#             status_code=500,
#             detail=f"Error inserting role assignment: {str(e)}"
#         )

#     # Broadcast the success message to all WebSocket clients
#     success_message = f"Role request ID {role_request_id} accepted. Role '{role_request.requested_role}' appended to user roles. Reason: {payload.admin_comment}"
#     await broadcast_message(success_message)
#     logger.info(f"Success message broadcasted: {success_message}")

#     return {
#         "success": True,
#         "message": success_message,
#     }

