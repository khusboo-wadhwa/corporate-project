from fastapi import APIRouter, HTTPException, Request
import logging

# Create a new router
router = APIRouter()

# Create a logging instance for this file (optional, but good practice)
logger = logging.getLogger(__name__)

# Example data structure to simulate saving or returning the name
users = {}

@router.get("/firstname-lastname/{user_id}")
async def get_name(user_id: int, request: Request):
    logger.info(f"Request to get user {user_id} - {request.method} {request.url}")

    user = users.get(user_id)
    if not user:
        logger.error(f"User {user_id} not found")
        raise HTTPException(status_code=404, detail="User not found")

    logger.info(f"User {user_id} found: {user}")
    return {"user_id": user_id, "firstname": user['firstname'], "lastname": user['lastname']}

@router.post("/firstname-lastname/")
async def create_name(request: Request):
    body = await request.json()
    user_id = len(users) + 1
    firstname = body.get("firstname")
    lastname = body.get("lastname")

    if not firstname or not lastname:
        logger.error(f"Invalid data: firstname or lastname missing")
        raise HTTPException(status_code=400, detail="firstname and lastname are required")

    users[user_id] = {"firstname": firstname, "lastname": lastname}
    logger.info(f"User created with ID: {user_id}")
    return {"user_id": user_id, "firstname": firstname, "lastname": lastname}
