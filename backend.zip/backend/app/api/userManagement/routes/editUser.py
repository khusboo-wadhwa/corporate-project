# #websocket and logs
# from fastapi import APIRouter, HTTPException, Depends, status, Request
# from prisma import Prisma
# from firebase_admin import auth
# from app.core.database import get_prisma_client
# from app.core.auth import get_current_user
# from app.api.userManagement.schemas.userSchema import EditUserRequest
# from app.api.userManagement.utils.emailUtils import send_email_notification
# from app.api.userManagement.utils.wsUtils import broadcast_message

# router = APIRouter()

# @router.post("/editUser/{user_id}", status_code=status.HTTP_200_OK)
# async def edit_user(
#     user_id: int,
#     request: EditUserRequest,req: Request,
#     current_user: dict = Depends(get_current_user),
#     prisma: Prisma = Depends(get_prisma_client),
#       # Add Request dependency to access logger
# ):
#     """
#     Allow admins to edit a user's email, phone, or role in the database individually.
#     Enforces:
#       - Resets email/phone verification on update.
#       - Updates email in Firebase if changed.
#     """
#     logger = req.state.logger  # Access the logger from request state

#     # Ensure the current user is an admin
#     if not current_user.is_admin:
#         logger.warning(f"Unauthorized attempt by {current_user.email} to edit user {user_id}.")
#         raise HTTPException(
#             status_code=403,
#             detail="Only admins can edit user details."
#         )

#     logger.info(f"Admin {current_user.email} is attempting to edit user {user_id}.")

#     # Fetch the user from the database
#     user = await prisma.aq_users.find_unique(where={"id": user_id})
#     if not user:
#         logger.warning(f"User with ID {user_id} not found.")
#         raise HTTPException(
#             status_code=404,
#             detail="User not found."
#         )

#     if user.role and "Admin" in user.role:
#         logger.warning(f"Attempt to edit admin user with ID {user_id}.")
#         raise HTTPException(
#             status_code=400,
#             detail="Cannot edit users with the 'Admin' role."
#         )

#     update_data = {}

#     # Update email and handle Firebase email
#     if request.email:
#         try:
#             logger.info(f"Updating email for user {user_id} to {request.email}.")
#             # Remove the old email from Firebase
#             if user.email:
#                 user_record = auth.get_user_by_email(user.email)
#                 auth.delete_user(user_record.uid)

#             # Add the new email to Firebase
#             auth.create_user(email=request.email)

#             # Update Prisma data
#             update_data["email"] = request.email
#             update_data["is_email_verified"] = False
#         except Exception as e:
#             logger.error(f"Error updating email in Firebase for user {user_id}: {str(e)}")
#             raise HTTPException(
#                 status_code=500,
#                 detail=f"Error updating email in Firebase: {str(e)}"
#             )

#     # Update phone number
#     if request.mobile_number:
#         logger.info(f"Updating phone number for user {user_id} to {request.mobile_number}.")
#         update_data["mobile_number"] = request.mobile_number
#         update_data["is_phone_verified"] = False

#     # Update role only if explicitly provided and contains valid entries
#     if request.role is not None:  # Ensure the role field is present in the request
#         # Remove empty strings or invalid roles from the list
#         filtered_roles = [role for role in request.role if role.strip()]

#         if filtered_roles:  # Only process if there are valid roles after filtering
#             try:
#                 # Validate and format role input
#                 valid_roles = [
#                     "General_Manager", "Front_Office_Manager", 
#                     "Food_and_Beverage_Manager", "Sales_and_Marketing_Manager", 
#                     "Kitchen_Manager", "Floor_Manager"
#                 ]  # Replace with actual roles from your schema
#                 if any(role not in valid_roles for role in filtered_roles):
#                     logger.warning(f"Invalid role(s) provided for user {user_id}: {filtered_roles}")
#                     raise HTTPException(
#                         status_code=400,
#                         detail=f"Invalid roles provided. Allowed roles are: {', '.join(valid_roles)}."
#                     )
#                 update_data["role"] = filtered_roles
#             except Exception as e:
#                 logger.error(f"Error updating role for user {user_id}: {str(e)}")
#                 raise HTTPException(
#                     status_code=500,
#                     detail=f"Error updating role: {str(e)}"
#                 )

#     try:
#         # Update the user in the database if there is data to update
#         if update_data:
#             updated_user = await prisma.aq_users.update(
#                 where={"id": user_id},
#                 data=update_data
#             )
#             logger.info(f"User {user_id} has been successfully updated.")

#             # Send email notification to the user about the changes
#             if "email" in update_data or "mobile_number" in update_data or "role" in update_data:
#                 await send_email_notification(
#                     to_email=updated_user.email,
#                     subject="Your Account Information has been Updated",
#                     user_name=updated_user.first_name,  # Assuming you have the user's name in the updated_user object
#                     email=updated_user.email,
#                     mobile_number=updated_user.mobile_number,
#                     role=", ".join(updated_user.role) if updated_user.role else "None"  # Join roles if available
#                 )

#             # Broadcast a message to connected WebSocket clients
#             broadcast_message_content = f"User with ID {user_id} has been updated."
#             await broadcast_message(broadcast_message_content)
#             logger.info(f"Broadcasted message: {broadcast_message_content}")

#         else:
#             logger.warning(f"No valid fields provided for user {user_id} update.")
#             raise HTTPException(
#                 status_code=400,
#                 detail="No valid fields provided for update."
#             )

#     except Exception as e:
#         logger.error(f"Error occurred while updating user {user_id}: {str(e)}")
#         raise HTTPException(
#             status_code=500,
#             detail=f"Error updating user in the database: {str(e)}"
#         )

#     return {
#         "success": True,
#         "message": f"User with ID {user_id} has been successfully updated.",
#         "updated_user": updated_user
#     }




from fastapi import APIRouter, HTTPException, Depends, status, Request
from prisma import Prisma
from firebase_admin import auth
from app.core.database import get_prisma_client
from app.core.auth import get_current_user, fetch_valid_roles  # Import fetch_valid_roles
from app.api.userManagement.schemas.userSchema import EditUserRequest
from app.api.userManagement.utils.emailUtils import send_email_notification
from app.api.userManagement.utils.wsUtils import broadcast_message

router = APIRouter()

@router.post("/editUser/{user_id}", status_code=status.HTTP_200_OK)
async def edit_user(
    user_id: int,
    request: EditUserRequest, req: Request,
    current_user: dict = Depends(get_current_user),
    prisma: Prisma = Depends(get_prisma_client),
):
    """
    Allow admins to edit a user's email, phone, or role in the database individually.
    Updates roles in `aq_user_roles` and ensures roles are fetched dynamically from `aq_roles`.
    """
    logger = req.state.logger  # Access the logger from request state

    # Ensure the current user is an admin
    if not current_user.is_admin:
        logger.warning(f"Unauthorized attempt by {current_user.email} to edit user {user_id}.")
        raise HTTPException(
            status_code=403,
            detail="Only admins can edit user details."
        )

    logger.info(f"Admin {current_user.email} is attempting to edit user {user_id}.")

    # Fetch the user from the database
    user = await prisma.aq_users.find_unique(where={"id": user_id})
    if not user:
        logger.warning(f"User with ID {user_id} not found.")
        raise HTTPException(
            status_code=404,
            detail="User not found."
        )

    update_data = {}

    # Update email and handle Firebase email
    if request.email:
        try:
            logger.info(f"Updating email for user {user_id} to {request.email}.")
            if user.email:
                user_record = auth.get_user_by_email(user.email)
                auth.delete_user(user_record.uid)
            auth.create_user(email=request.email)
            update_data["email"] = request.email
            update_data["is_email_verified"] = False
        except Exception as e:
            logger.error(f"Error updating email in Firebase for user {user_id}: {str(e)}")
            raise HTTPException(
                status_code=500,
                detail=f"Error updating email in Firebase: {str(e)}"
            )

    # Update phone number
    if request.mobile_number:
        logger.info(f"Updating phone number for user {user_id} to {request.mobile_number}.")
        update_data["mobile_number"] = request.mobile_number
        update_data["is_phone_verified"] = False

    # Update roles
    if request.role:
        try:
            valid_roles = await fetch_valid_roles()
            filtered_roles = [role for role in request.role if role in valid_roles]

            if not filtered_roles:
                logger.warning(f"No valid roles provided for user {user_id}.")
                raise HTTPException(
                    status_code=400,
                    detail="No valid roles provided."
                )

            # Update the role in `aq_user_roles` table
            await prisma.aq_user_roles.delete_many(where={"user_id": user_id})  # Remove old roles
            for role_name in filtered_roles:
                role = await prisma.aq_roles.find_unique(where={"role_name": role_name})
                if role:
                    await prisma.aq_user_roles.create(data={"user_id": user_id, "role_id": role.id})

            logger.info(f"Updated roles for user {user_id}: {filtered_roles}")
        except Exception as e:
            logger.error(f"Error updating roles for user {user_id}: {str(e)}")
            raise HTTPException(
                status_code=500,
                detail=f"Error updating roles: {str(e)}"
            )

    # Apply updates
    if update_data:
        try:
            updated_user = await prisma.aq_users.update(
                where={"id": user_id},
                data=update_data
            )
        except Exception as e:
            logger.error(f"Error updating user {user_id}: {str(e)}")
            raise HTTPException(
                status_code=500,
                detail=f"Error updating user in the database: {str(e)}"
            )
    else:
        logger.warning(f"No valid fields provided for user {user_id} update.")
        raise HTTPException(
            status_code=400,
            detail="No valid fields provided for update."
        )

    # Notify the user and broadcast
    try:
        if "email" in update_data or "mobile_number" in update_data or request.role:
            await send_email_notification(
                to_email=updated_user.email,
                subject="Your Account Information has been Updated",
                user_name=updated_user.first_name,
                email=updated_user.email,
                mobile_number=updated_user.mobile_number,
                role=", ".join(request.role) if request.role else "None"
            )
            broadcast_message_content = f"User with ID {user_id} has been updated."
            await broadcast_message(broadcast_message_content)
            logger.info(f"Broadcasted message: {broadcast_message_content}")
    except Exception as e:
        logger.error(f"Error sending notification or broadcasting message for user {user_id}: {str(e)}")

    return {
        "success": True,
        "message": f"User with ID {user_id} has been successfully updated.",
        "updated_user": updated_user
    }
