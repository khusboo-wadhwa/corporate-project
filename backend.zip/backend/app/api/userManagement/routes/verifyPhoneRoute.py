# from fastapi import APIRouter, HTTPException, Depends, status
# from app.core.database import get_prisma_client
# from prisma import Prisma
# from datetime import datetime, timezone
# from app.api.userManagement.schemas.userSchema import VerificationRequest
# from app.api.userManagement.services.verifyPhoneServices import get_user_by_mobile, update_user_verification_status

# # Initialize the APIRouter
# router = APIRouter()

# @router.post("/verifyPhone")
# async def verify_phone(
#     request: VerificationRequest,
#     prisma: Prisma = Depends(get_prisma_client)  # Ensure Prisma client is passed here
# ):
#     # Retrieve the user by mobile number and country code
#     user = await prisma.aq_users.find_first(
#         where={
#             "country_code": request.country_code,
#             "mobile_number": request.mobile_number
#         }
#     )
#     if not user:
#         raise HTTPException(
#             status_code=status.HTTP_404_NOT_FOUND,
#             detail="User not found with the given mobile number."
#         )

#     # Check if the verification code matches
#     if user.phone_verification_code != request.verification_code:
#         raise HTTPException(
#             status_code=status.HTTP_400_BAD_REQUEST,
#             detail="Invalid verification code."
#         )

#     # Use timezone-aware datetime for comparison
#     current_time = datetime.now(timezone.utc)
#     if user.phone_verification_code_expires_at and current_time > user.phone_verification_code_expires_at:
#         raise HTTPException(
#             status_code=status.HTTP_400_BAD_REQUEST,
#             detail="Verification code has expired."
#         )

#     # Update the user's verification status to verified
#     await prisma.aq_users.update(
#         where={"id": user.id},
#         data={
#             "is_phone_verified": True,
#             "phone_verification_code": None,
#             "phone_verification_code_expires_at": None
#         }
#     )

#     return {"message": "Phone number verified successfully."}


#logs
from fastapi import APIRouter, HTTPException, Depends, status, Request
from app.core.database import get_prisma_client
from prisma import Prisma
from datetime import datetime, timezone
from app.api.userManagement.schemas.userSchema import VerificationRequest  # Renamed to verification_request
from app.api.userManagement.services.verifyPhoneServices import get_user_by_mobile, update_user_verification_status

# Initialize the APIRouter
router = APIRouter()

@router.post("/verifyPhone")
async def verify_phone(
    verification_request: VerificationRequest,request: Request,  # Renamed this to avoid conflict
    prisma: Prisma = Depends(get_prisma_client)  # Ensure Prisma client is passed here
      # Access the logger from the request state
):
    logger = request.state.logger  # Access the logger from request.state

    try:
        logger.info(f"Starting phone verification for {verification_request.country_code} {verification_request.mobile_number}")

        # Retrieve the user by mobile number and country code
        user = await prisma.aq_users.find_first(
            where={
                "country_code": verification_request.country_code,
                "mobile_number": verification_request.mobile_number
            }
        )

        if not user:
            logger.warning(f"User with mobile number {verification_request.mobile_number} not found.")
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="User not found with the given mobile number."
            )

        # Check if the verification code matches
        if user.phone_verification_code != verification_request.verification_code:
            logger.warning(f"Invalid verification code for user with mobile number {verification_request.mobile_number}.")
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid verification code."
            )

        # Use timezone-aware datetime for comparison
        current_time = datetime.now(timezone.utc)

        # Check if the verification code has expired
        if user.phone_verification_code_expires_at and current_time > user.phone_verification_code_expires_at:
            logger.warning(f"Verification code has expired for {verification_request.mobile_number}.")
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Verification code has expired."
            )

        # Update the user's verification status to verified
        await prisma.aq_users.update(
            where={"id": user.id},
            data={
                "is_phone_verified": True,
                "phone_verification_code": None,
                "phone_verification_code_expires_at": None
            }
        )

        logger.info(f"Phone number {verification_request.mobile_number} successfully verified.")
        return {"message": "Phone number verified successfully."}

    except HTTPException as e:
        logger.error(f"HTTPException occurred: {e.detail}")
        raise e

    except Exception as e:
        logger.error(f"An unexpected error occurred while verifying phone number {verification_request.mobile_number}: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"An error occurred while verifying the phone number: {str(e)}"
        )
