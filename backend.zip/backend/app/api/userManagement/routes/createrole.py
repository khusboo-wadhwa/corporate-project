 
from fastapi import APIRouter, HTTPException, Depends, status,Request
from app.api.userManagement.schemas.userSchema import RoleCreate, PermissionAssign, GetRole, GetPermission,CreatePermission,RoleUpdate
from app.core.database import get_prisma_client
from prisma import Prisma
from app.core.auth import get_current_user  # Import the dependency to get the current user
from typing import List
from datetime import datetime

 
 
router = APIRouter(prefix="/roles", tags=["Roles"])
 
# Dependency to check if the current user is an admin
async def admin_only(current_user: dict = Depends(get_current_user)):
    """
    Ensure the current user is an admin.
    """
    if not current_user.is_admin:  # Directly access the is_admin attribute
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Only admins can access this resource."
        )
 
@router.post("/CreateRole", status_code=status.HTTP_201_CREATED)
async def create_role(role: RoleCreate, request: Request, db=Depends(get_prisma_client)):
    logger = request.state.logger  # Access the logger
    logger.info(f"Creating role with name: {role.role_name}")
 
    # Check if role already exists
    existing_role = await db.aq_roles.find_unique(where={"role_name": role.role_name})
    if existing_role:
        logger.warning(f"Role creation failed: Role '{role.role_name}' already exists.")
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Role with this name already exists"
        )
 
    # Create the role
    new_role = await db.aq_roles.create(
        data={
            "role_name": role.role_name,
            "description": role.description
        }
    )
    logger.info(f"Role '{role.role_name}' created successfully.")
    return {"message": "Role created successfully", "role": new_role}




@router.put("/updateRole/{role_id}", status_code=status.HTTP_200_OK)
async def update_role(
    role_id: int,
    updated_role: RoleUpdate,
    request: Request,
    db: Prisma = Depends(get_prisma_client),
    current_user: dict = Depends(get_current_user)
):
    logger = request.state.logger
    logger.info(f"User {current_user.id} attempting to update role ID {role_id}")

    # Check if user is admin
    if not current_user.is_admin:
        logger.warning(f"Unauthorized update attempt by user {current_user.id}")
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Only admins can update roles")

    # Check if role exists
    role = await db.aq_roles.find_unique(where={"id": role_id})
    if not role:
        logger.warning(f"Role ID {role_id} not found")
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Role not found")

    # Update the role
    updated = await db.aq_roles.update(
        where={"id": role_id},
        data={
            "role_name": updated_role.role_name,
            "description": updated_role.description,
            "updated_at": datetime.now()
        }
    )
    logger.info(f"Role ID {role_id} updated successfully")
    return {"message": "Role updated successfully", "role": updated}


@router.delete("/deleteRole/{role_id}", status_code=status.HTTP_200_OK)
async def delete_role(
    role_id: int,
    request: Request,
    db: Prisma = Depends(get_prisma_client),
    current_user: dict = Depends(get_current_user)
):
    logger = request.state.logger
    logger.info(f"User {current_user.id} attempting to delete role ID {role_id}")

    # Check if user is admin
    if not current_user.is_admin:
        logger.warning(f"Unauthorized delete attempt by user {current_user.id}")
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Only admins can delete roles")

    # Check if role exists
    role = await db.aq_roles.find_unique(where={"id": role_id})
    if not role:
        logger.warning(f"Role ID {role_id} not found")
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Role not found")

    # Delete the role
    await db.aq_roles.delete(where={"id": role_id})
    logger.info(f"Role ID {role_id} deleted successfully")
    return {"message": "Role deleted successfully"}


# @router.post("/CreatePermission", status_code=status.HTTP_201_CREATED)
# async def create_permission(
#     permission: CreatePermission,  # Assuming you use the same schema for creation
#     request: Request,
#     db: Prisma = Depends(get_prisma_client),
#     current_user: dict = Depends(get_current_user)
# ):
#     """
#     Create a new permission in the aq_permissions table.
#     Only accessible by admins.
#     """
#     logger = request.state.logger  # Access the logger
#     logger.info(f"Attempting to create permission '{permission.permission_name}' by user {current_user.id}")
 
#     # Ensure the user is an admin
#     if not current_user.is_admin:
#         logger.error(f"Permission creation denied: User {current_user.id} is not an admin.")
#         raise HTTPException(
#             status_code=status.HTTP_403_FORBIDDEN,
#             detail="Only admins can create permissions."
#         )
 
#     # Check if permission already exists
#     existing_permission = await db.aq_permissions.find_unique(where={"permission_name": permission.permission_name})
#     if existing_permission:
#         logger.warning(f"Permission creation failed: Permission '{permission.permission_name}' already exists.")
#         raise HTTPException(
#             status_code=status.HTTP_400_BAD_REQUEST,
#             detail="Permission with this name already exists"
#         )
 
#     # Create the new permission
#     new_permission = await db.aq_permissions.create(
#         data={
#             "permission_name": permission.permission_name,
#             "description": permission.description,
#             "created_at": datetime.now(),  # Ensure the current timestamp is stored
#         }
#     )
#     logger.info(f"Permission '{permission.permission_name}' created successfully.")
#     return {"message": "Permission created successfully", "permission": new_permission}

@router.post("/CreatePermission", status_code=status.HTTP_201_CREATED)
async def create_permission(
    permission: CreatePermission,
    request: Request,
    db: Prisma = Depends(get_prisma_client),
    current_user: dict = Depends(get_current_user)
):
    """
    Create a new permission in the aq_permissions table.
    Only accessible by admins.
    Now supports hierarchical permissions.
    """
    logger = request.state.logger
    logger.info(f"Attempting to create permission '{permission.permission_name}' by user {current_user.id}")
 
    # Ensure the user is an admin
    if not current_user.is_admin:
        logger.error(f"Permission creation denied: User {current_user.id} is not an admin.")
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Only admins can create permissions."
        )
 
    # Check if permission already exists
    existing_permission = await db.aq_permissions.find_unique(
        where={"permission_name": permission.permission_name}
    )
    if existing_permission:
        logger.warning(f"Permission creation failed: Permission '{permission.permission_name}' already exists.")
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Permission with this name already exists"
        )
 
    # Validate parent_id if provided
    if permission.parent_id:
        parent_permission = await db.aq_permissions.find_unique(
            where={"id": permission.parent_id}
        )
        if not parent_permission:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Parent permission not found"
            )
 
    # Create the new permission with ALL fields
    new_permission = await db.aq_permissions.create(
        data={
            "permission_name": permission.permission_name,
            "description": permission.description,
            "parent_id": permission.parent_id,
            "permission_type": permission.permission_type,
            "route_path": permission.route_path,
            "created_at": datetime.utcnow(),
        }
    )
    
    logger.info(f"Permission '{permission.permission_name}' created successfully with ID {new_permission.id}.")
    
    return {
        "message": "Permission created successfully", 
        "permission": {
            "id": new_permission.id,
            "permission_name": new_permission.permission_name,
            "description": new_permission.description,
            "parent_id": new_permission.parent_id,
            "permission_type": new_permission.permission_type,
            "route_path": new_permission.route_path,
            "created_at": new_permission.created_at
        }
    }

 
# @router.post("/{role_id}/AssignPermissions")
# async def assign_permissions_to_role(
#     role_id: int,
#     payload: PermissionAssign,
#     request: Request,
#     db: Prisma = Depends(get_prisma_client),
#     current_user: dict = Depends(get_current_user)
# ):
#     logger = request.state.logger  # Access the logger
#     logger.info(f"Assigning permissions {payload.permission_ids} to role {role_id} by user {current_user.id}")
 
#     # Check if the current user is an admin
#     if not current_user.is_admin:
#         logger.error(f"Permission assignment failed: User {current_user.id} is not an admin.")
#         raise HTTPException(
#             status_code=status.HTTP_403_FORBIDDEN,
#             detail="Only admins can assign permissions."
#         )
 
#     # Check if role exists
#     role = await db.aq_roles.find_unique(where={"id": role_id})
#     if not role:
#         logger.error(f"Permission assignment failed: Role ID {role_id} not found.")
#         raise HTTPException(
#             status_code=status.HTTP_404_NOT_FOUND,
#             detail="Role not found"
#         )
 
#     # Assign permissions
#     for perm_id in payload.permission_ids:
#         # Check if the permission is already assigned to the role
#         existing_permission = await db.aq_role_permissions.find_first(
#             where={
#                 "role_id": role_id,
#                 "permission_id": perm_id
#             }
#         )
#         if existing_permission:
#             logger.warning(f"Permission {perm_id} is already assigned to role {role_id}. Skipping.")
#             continue
 
#         # Add the permission to the role
#         await db.aq_role_permissions.create(
#             data={
#                 "role_id": role_id,
#                 "permission_id": perm_id
#             }
#         )
#         logger.info(f"Permission {perm_id} successfully assigned to role {role_id}.")
 
#     logger.info(f"Finished assigning permissions {payload.permission_ids} to role {role_id}.")
#     return {"message": "Permissions assigned successfully"}




@router.post("/{role_id}/AssignPermissions")
async def assign_permissions_to_role(
    role_id: int,
    payload: PermissionAssign,
    request: Request,
    db: Prisma = Depends(get_prisma_client),
    current_user: dict = Depends(get_current_user)
):
    logger = request.state.logger
    logger.info(f"Syncing permissions for role {role_id} by user {current_user.id}: {payload.permission_ids}")

    if not current_user.is_admin:
        logger.error(f"User {current_user.id} is not authorized to modify permissions.")
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Only admins can assign permissions."
        )

    role = await db.aq_roles.find_unique(where={"id": role_id})
    if not role:
        logger.error(f"Role ID {role_id} not found.")
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Role not found"
        )

    # Get current permissions
    current_permissions = await db.aq_role_permissions.find_many(
        where={"role_id": role_id}
    )
    current_permission_ids = {rp.permission_id for rp in current_permissions}
    new_permission_ids = set(payload.permission_ids)

    # Find to add and to remove
    to_add = new_permission_ids - current_permission_ids
    to_remove = current_permission_ids - new_permission_ids

    # Remove permissions
    for perm_id in to_remove:
        await db.aq_role_permissions.delete_many(
            where={"role_id": role_id, "permission_id": perm_id}
        )
        logger.info(f"Removed permission {perm_id} from role {role_id}")

    # Add new permissions
    for perm_id in to_add:
        await db.aq_role_permissions.create(
            data={"role_id": role_id, "permission_id": perm_id}
        )
        logger.info(f"Added permission {perm_id} to role {role_id}")

    return {"message": "Permissions synced successfully"}

 
# @router.get("/getAllRoles", response_model=List[GetRole])
# async def get_all_roles(
#     request: Request,
#     db: Prisma = Depends(get_prisma_client),
#     current_user: dict = Depends(get_current_user)
# ):
#     logger = request.state.logger  # Access the logger
#     logger.info(f"Fetching all roles by user {current_user.id}")
 
#     # Ensure the user is an admin
#     if not current_user.is_admin:
#         logger.error(f"Access denied: User {current_user.id} is not an admin.")
#         raise HTTPException(
#             status_code=status.HTTP_403_FORBIDDEN,
#             detail="Only admins can access this resource."
#         )
 
#     # Retrieve all roles
#     roles = await db.aq_roles.find_many()
#     roles_dicts = [{
#         "id": role.id,
#         "role_name": role.role_name,
#         "description": role.description,
#          "created_at": role.created_at or datetime.utcnow() # Ensure this field is present
#     } for role in roles]
 
#     logger.info(f"Fetched {len(roles)} roles.")
#     return [GetRole(**role) for role in roles_dicts]
 
@router.get("/getAllRoles", response_model=List[GetRole])
async def get_all_roles(
    request: Request,
    db: Prisma = Depends(get_prisma_client),
    current_user: dict = Depends(get_current_user)  # Still keeping authentication
):
    logger = request.state.logger  # Access the logger
    logger.info(f"Fetching all roles by user {current_user.id}")
 
    # Retrieve all roles EXCEPT Super_Admin
    roles = await db.aq_roles.find_many(
        where={
            "role_name": {
                "not": "Super_Admin"  # Exclude Super_Admin role
            }
        }
    )
    
    roles_dicts = [
        {
            "id": role.id,
            "role_name": role.role_name,
            "description": role.description,
            "created_at": role.created_at.isoformat() if role.created_at else None,
        }
        for role in roles
    ]
 
    logger.info(f"Fetched {len(roles)} roles (excluding Super_Admin).")
    return [GetRole(**role) for role in roles_dicts]

@router.get("/getAllPermissions")
async def get_all_permissions(
    request: Request,
    db: Prisma = Depends(get_prisma_client),
    current_user: dict = Depends(get_current_user)
):
    """
    Get all permissions categorized by type (main, sub, page)
    Returns structured data for frontend display
    """
    logger = request.state.logger
    logger.info(f"Fetching all categorized permissions by user {current_user.id}")
 
    # Ensure the user is an admin
    if not current_user.is_admin:
        logger.error(f"Access denied: User {current_user.id} is not an admin.")
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Only admins can access this resource."
        )
 
    try:
        # Retrieve all permissions with parent information
        permissions = await db.aq_permissions.find_many(
            include={
                "aq_permissions": True  # Include parent permission
            }
        )
        
        # Categorize permissions
        main_modules = []
        sub_modules = []
        pages = []
        
        for permission in permissions:
            perm_data = {
                "id": permission.id,
                "permission_name": permission.permission_name,
                "description": permission.description,
                "permission_type": permission.permission_type,
                "route_path": permission.route_path,
                "parent_id": permission.parent_id,
                "parent_name": permission.aq_permissions.permission_name if permission.aq_permissions else None,
                "created_at": permission.created_at.isoformat() if permission.created_at else None,
                "updated_date": permission.updated_date.isoformat() if permission.updated_date else None
            }
            
            # Categorize by permission_type
            if permission.permission_type == "main":
                main_modules.append(perm_data)
            elif permission.permission_type == "sub":
                sub_modules.append(perm_data)
            elif permission.permission_type == "page":
                pages.append(perm_data)
            else:
                # Default to page if type not specified
                pages.append(perm_data)
        
        logger.info(f"Fetched {len(permissions)} permissions: {len(main_modules)} main, {len(sub_modules)} sub, {len(pages)} pages")
        
        return {
            "success": True,
            "data": {
                "main_modules": main_modules,
                "sub_modules": sub_modules,
                "pages": pages,
                "total_count": len(permissions),
                "counts": {
                    "main": len(main_modules),
                    "sub": len(sub_modules),
                    "page": len(pages)
                }
            }
        }
        
    except Exception as e:
        logger.error(f"Error fetching permissions: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail=f"Error retrieving permissions: {str(e)}"
        )
    
# Endpoint to get permissions for a specific role
@router.get("/{role_id}/getRolePermissions", response_model=List[dict])
async def get_role_permissions(
    role_id: int,
    db: Prisma = Depends(get_prisma_client),
    current_user: dict = Depends(get_current_user)
):
    # Ensure the user is an admin
    if not current_user.is_admin:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Only admins can access this resource."
        )
 
    # Fetch the permissions assigned to the role
    role_permissions = await db.aq_role_permissions.find_many(
        where={"role_id": role_id}
    )
 
    # Return the permission_ids of the assigned permissions
    return [{"permission_id": rp.permission_id} for rp in role_permissions]
 
 