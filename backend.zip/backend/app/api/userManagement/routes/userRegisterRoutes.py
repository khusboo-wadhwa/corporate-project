# import re
# from fastapi import APIRouter, HTTPException, BackgroundTasks, Request
# from datetime import datetime, timedelta
# from app.api.userManagement.utils.passwordUtils import hash_password
# from app.api.userManagement.utils.emailUtils import send_verification_email, send_user_creation_email, generate_verification_code as generate_email_code
# from app.core.auth import (register_non_admin_user, is_email_taken, is_mobile_number_taken, is_username_taken)
# from app.api.userManagement.utils.timeframe import delete_unverified_users
# from app.api.userManagement.schemas.userSchema import RegisterUserRequest
# from app.core.database import prisma  # Import prisma client
# from app.api.userManagement.utils.phoneUtils import generate_verification_code

# router = APIRouter()

# # Helper function to validate password
# def validate_password(password: str, logger):
#     password_regex = r'^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,16}$'
#     if not re.match(password_regex, password):
#         logger.warning("Password validation failed. Password must be 8-16 characters, include at least one uppercase, one lowercase, one digit, and one special character.")
#         raise HTTPException(status_code=400, detail="Password must be 8-16 characters, include at least one uppercase, one lowercase, one digit, and one special character.") 

# @router.post("/createUser")
# async def register_user(user: RegisterUserRequest, background_tasks: BackgroundTasks, request: Request):
#     """
#     Endpoint for registering a new user. Prevents assigning the 'admin' role,
#     validates country code, hashes the password, and sends a verification code.
#     Also schedules a task to delete unverified users after 72 hours.
#     """
#     logger = request.state.logger  # Use the centralized logger
#     logger.debug("Starting user registration process for email: %s", user.email)
    
#     # Step 1: Validate password complexity BEFORE attempting any user creation
#     try:
#         validate_password(user.password, logger)
#     except HTTPException as e:
#         logger.error(f"Password validation failed for user {user.email}: {str(e.detail)}")
#         raise e

#     # Step 2: Validate country code (only +1 and +91 are allowed)
#     if user.country_code not in ["+1", "+91"]:
#         logger.warning("Invalid country code for user %s. Only +1 (USA) and +91 (India) are allowed.", user.email)
#         raise HTTPException(
#             status_code=200,
#             detail="Invalid country code. Only +1 (USA) and +91 (India) are allowed."
#         )

#     # Step 3: Prevent assigning the 'admin' role
#     if "Admin" in user.role:
#         logger.warning("Attempt to assign 'admin' role to user %s.", user.email)
#         raise HTTPException(
#             status_code=200,
#             detail="Cannot assign 'admin' role using this endpoint."
#         )

#     # Step 4: Validate Unique Fields (Email, Username, Mobile Number)
#     if await is_email_taken(user.email):
#         logger.warning("Email %s is already taken.", user.email)
#         raise HTTPException(status_code=200, detail="Email is already taken.")
    
#     if await is_username_taken(user.username):
#         logger.warning("Username %s is already taken.", user.username)
#         raise HTTPException(status_code=200, detail="Username is already taken.")
    
#     if await is_mobile_number_taken(user.mobile_number):
#         logger.warning("Mobile number %s is already taken.", user.mobile_number)
#         raise HTTPException(status_code=200, detail="Mobile number is already taken.")

#     # Step 5: Hash the password
#     hashed_password = hash_password(user.password)
#     logger.debug("Password hashed successfully for user %s.", user.email)

#     # Step 6: Generate Verification Codes
#     phone_verification_code = generate_verification_code()
#     email_verification_code = generate_email_code()
#     verification_expiration_time = datetime.utcnow() + timedelta(minutes=10)
#     verification_code_sent_at = datetime.utcnow()
#     logger.debug(f"Generated verification codes for user {user.email}: Phone {phone_verification_code}, Email {email_verification_code}")

#     # Step 7: Prepare user data (without Firebase user creation yet)
#     user_data = {
#         "first_name": user.first_name,
#         "last_name": user.last_name,
#         "username": user.username,
#         "email": user.email,
#         "password": hashed_password,
#         "role": user.role,  # Pass role names as strings
#         "mobile_number": user.mobile_number,
#         "country_code": user.country_code,
#         "phone_verification_code": phone_verification_code,
#         "phone_verification_code_sent_at": verification_code_sent_at,
#         "phone_verification_code_expires_at": verification_expiration_time,
#         "email_verification_code": email_verification_code,
#         "email_verification_code_sent_at": verification_code_sent_at,
#         "email_verification_code_expires_at": verification_expiration_time,
#     }

#     # Step 8: Register User in the Database (Prisma)
#     try:
#         created_user = await register_non_admin_user(**user_data)
#         logger.debug(f"User created successfully: {created_user.email}")
#     except Exception as e:
#         logger.error(f"Error registering user in database for email {user.email}: {str(e)}")
#         raise HTTPException(status_code=500, detail=f"Error registering user in database: {str(e)}")

#     # Step 9: Assign roles to user by inserting into the user-role mapping table
#     for role_name in user.role:
#         # Fetch the role ID from the roles table using role name
#         role = await prisma.aq_roles.find_unique(where={"role_name": role_name})

#         if not role:
#             # Handle case where the role does not exist in the roles table
#             logger.error(f"Invalid role: {role_name} for user {user.email}")
#             raise HTTPException(status_code=400, detail=f"Invalid role: {role_name}.")

#         # Insert user-role mapping into the aq_user_roles table
#         await prisma.aq_user_roles.create(
#             data={
#                 "user_id": created_user.id,
#                 "role_id": role.id  # Use the fetched role ID
#             }
#         )
#         logger.debug(f"Assigned role {role_name} (ID: {role.id}) to user {user.email}")

#     # Step 10: Send Verification Email
#     try:
#         logger.debug(f"Sending verification email to {user.email} with code {email_verification_code}")
#         send_verification_email(user.email, email_verification_code)
#     except Exception as e:
#         logger.error(f"Error sending verification email to {user.email}: {str(e)}")
#         raise HTTPException(status_code=500, detail=f"Error sending verification email: {str(e)}")

#     # Step 11: Send User Details Email
#     try:
#         user_details = {
#             "first_name": created_user.first_name,
#             "last_name": created_user.last_name,
#             "username": created_user.username,
#             "email": created_user.email,
#             "password": user.password,  # Send unhashed password for initial login
#             "mobile_number": created_user.mobile_number,
#             "country_code": created_user.country_code,
#         }
#         logger.debug(f"Sending user creation email to {created_user.email}")
#         send_user_creation_email(created_user.email, user_details)
#     except Exception as e:
#         logger.error(f"Error sending user creation email to {created_user.email}: {str(e)}")
#         raise HTTPException(status_code=500, detail=f"Error sending user creation email: {str(e)}")

#     # Step 12: Schedule Task to Delete Unverified Users
#     background_tasks.add_task(delete_unverified_users, expiration_hours=72)
#     logger.debug("Scheduled task to delete unverified users after 72 hours.")

#     # Step 13: Return Response
#     logger.info(f"User {user.email} registered successfully.")
#     return {
#         "success": True,
#         "message": "User registered successfully. Verification code and account details sent via email.",
#         "user": {
#             "name": f"{created_user.first_name} {created_user.last_name}",
#             "email": created_user.email,
#             "roles": user.role,  # Return role names as strings
#             "mobile_number": created_user.mobile_number,
#             "country_code": created_user.country_code
#         }
#     }



# import re
# from fastapi import APIRouter, HTTPException, BackgroundTasks, Request
# from datetime import datetime, timedelta
# from app.api.userManagement.utils.passwordUtils import hash_password
# from app.api.userManagement.utils.emailUtils import send_verification_email, send_user_creation_email, generate_verification_code as generate_email_code
# from app.core.auth import (is_email_taken, is_mobile_number_taken, is_username_taken)
# from app.api.userManagement.utils.timeframe import delete_unverified_users
# from app.api.userManagement.schemas.userSchema import RegisterUserRequest
# from app.core.database import prisma
# from app.api.userManagement.utils.phoneUtils import generate_verification_code

# router = APIRouter()

# def validate_password(password: str, logger):
#     password_regex = r'^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,16}$'
#     if not re.match(password_regex, password):
#         logger.warning("Password validation failed. Password must be 8-16 characters, include at least one uppercase, one lowercase, one digit, and one special character.")
#         raise HTTPException(status_code=400, detail="Password must be 8-16 characters, include at least one uppercase, one lowercase, one digit, and one special character.")

# async def register_non_admin_user(
#     first_name: str,
#     last_name: str,
#     username: str,
#     email: str,
#     password: str,
#     mobile_number: int,
#     country_code: str,
#     role: list[str]
# ):
#     """Helper function to create a non-admin user in the database"""
#     return await prisma.aq_users.create(
#         data={
#             "first_name": first_name,
#             "last_name": last_name,
#             "username": username,
#             "email": email,
#             "password": password,
#             "mobile_number": mobile_number,
#             "country_code": country_code,
#             "role": role,
#         }
#     )

# @router.post("/createUser")
# async def register_user(user: RegisterUserRequest, background_tasks: BackgroundTasks, request: Request):
#     """
#     Endpoint for registering a new user. Prevents assigning the 'admin' role,
#     validates country code, hashes the password, and sends a verification code.
#     Also schedules a task to delete unverified users after 72 hours.
#     """
#     logger = request.state.logger
#     logger.debug("Starting user registration process for email: %s", user.email)
    
#     # Step 1: Validate password complexity
#     try:
#         validate_password(user.password, logger)
#     except HTTPException as e:
#         logger.error(f"Password validation failed for user {user.email}: {str(e.detail)}")
#         raise e

#     # Step 2: Validate country code
#     if user.country_code not in ["+1", "+91"]:
#         logger.warning("Invalid country code for user %s. Only +1 (USA) and +91 (India) are allowed.", user.email)
#         raise HTTPException(
#             status_code=400,
#             detail="Invalid country code. Only +1 (USA) and +91 (India) are allowed."
#         )

#     # Step 3: Prevent assigning the 'admin' role
#     if "Admin" in user.role:
#         logger.warning("Attempt to assign 'admin' role to user %s.", user.email)
#         raise HTTPException(
#             status_code=403,
#             detail="Cannot assign 'admin' role using this endpoint."
#         )

#     # Step 4: Validate Unique Fields
#     if await is_email_taken(user.email):
#         logger.warning("Email %s is already taken.", user.email)
#         raise HTTPException(status_code=409, detail="Email is already taken.")
    
#     if await is_username_taken(user.username):
#         logger.warning("Username %s is already taken.", user.username)
#         raise HTTPException(status_code=409, detail="Username is already taken.")
    
#     if await is_mobile_number_taken(user.mobile_number):
#         logger.warning("Mobile number %s is already taken.", user.mobile_number)
#         raise HTTPException(status_code=409, detail="Mobile number is already taken.")

#     # Step 5: Hash the password
#     hashed_password = hash_password(user.password)
#     logger.debug("Password hashed successfully for user %s.", user.email)

#     # Step 6: Generate Verification Codes
#     phone_verification_code = generate_verification_code()
#     email_verification_code = generate_email_code()
#     verification_expiration_time = datetime.utcnow() + timedelta(minutes=10)
#     verification_code_sent_at = datetime.utcnow()

#     # Step 7: Create user in database
#     try:
#         # Create user record
#         created_user = await prisma.aq_users.create(
#             data={
#                 "first_name": user.first_name,
#                 "last_name": user.last_name,
#                 "username": user.username,
#                 "email": user.email,
#                 "password": hashed_password,
#                 "role": user.role,
#                 "mobile_number": user.mobile_number,
#                 "country_code": user.country_code,
#                 "first_login": True,
#                 "is_admin": False
#             }
#         )
#         logger.debug(f"User created successfully: {created_user.email}")

#         # Create verification record
#         await prisma.aq_user_verification.create(
#             data={
#                 "user_id": created_user.id,
#                 "phone_verification_code": phone_verification_code,
#                 "phone_verification_code_sent_at": verification_code_sent_at,
#                 "phone_verification_code_expires_at": verification_expiration_time,
#                 "email_verification_code": email_verification_code,
#                 "email_verification_code_sent_at": verification_code_sent_at,
#                 "email_verification_code_expires_at": verification_expiration_time,
#                 "country_code": user.country_code,
#             }
#         )
#         logger.debug(f"Verification records created for user {created_user.email}")

#         # Create security record
#         await prisma.aq_user_security.create(
#             data={
#                 "user_id": created_user.id,
#                 "force_password_reset": True,
#                 "login_attempts": 0
#             }
#         )
#         logger.debug(f"Security record created for user {created_user.email}")

#     except Exception as e:
#         logger.error(f"Error registering user in database for email {user.email}: {str(e)}")
#         raise HTTPException(status_code=500, detail=f"Error registering user in database: {str(e)}")

#     # Step 8: Assign roles to user
#     for role_name in user.role:
#         try:
#             role = await prisma.aq_roles.find_unique(where={"role_name": role_name})
#             if not role:
#                 logger.error(f"Invalid role: {role_name} for user {user.email}")
#                 continue  # Skip invalid roles rather than failing entire registration

#             await prisma.aq_user_roles.create(
#                 data={
#                     "user_id": created_user.id,
#                     "role_id": role.id
#                 }
#             )
#             logger.debug(f"Assigned role {role_name} (ID: {role.id}) to user {user.email}")
#         except Exception as e:
#             logger.error(f"Error assigning role {role_name} to user {user.email}: {str(e)}")

#     # Step 9: Send Verification Email
#     try:
#         send_verification_email(user.email, email_verification_code)
#         logger.debug(f"Verification email sent to {user.email}")
#     except Exception as e:
#         logger.error(f"Error sending verification email to {user.email}: {str(e)}")
#         # Don't fail the registration if email sending fails

#     # Step 10: Send User Details Email
#     try:
#         user_details = {
#             "first_name": user.first_name,
#             "last_name": user.last_name,
#             "username": user.username,
#             "email": user.email,
#             "password": user.password,  # Send plain password only in initial email
#             "mobile_number": user.mobile_number,
#             "country_code": user.country_code,
#         }
#         send_user_creation_email(user.email, user_details)
#         logger.debug(f"User creation email sent to {user.email}")
#     except Exception as e:
#         logger.error(f"Error sending user creation email to {user.email}: {str(e)}")

#     # Step 11: Schedule cleanup task
#     background_tasks.add_task(delete_unverified_users, expiration_hours=72)
#     logger.debug("Scheduled task to delete unverified users after 72 hours.")

#     # Step 12: Return success response
#     logger.info(f"User {user.email} registered successfully.")
#     return {
#         "success": True,
#         "message": "User registered successfully. Verification code and account details sent via email.",
#         "user": {
#             "name": f"{user.first_name} {user.last_name}",
#             "email": user.email,
#             "roles": user.role,
#             "mobile_number": user.mobile_number,
#             "country_code": user.country_code
#         }
#     }


# import re
# from fastapi import APIRouter, HTTPException, BackgroundTasks, Request, Depends
# from datetime import datetime, timedelta
# from app.api.userManagement.utils.passwordUtils import hash_password
# from app.api.userManagement.utils.emailUtils import send_verification_email, send_user_creation_email, generate_verification_code as generate_email_code
# from app.core.auth import (is_email_taken, is_mobile_number_taken, is_username_taken)
# from app.api.userManagement.utils.timeframe import delete_unverified_users
# from app.api.userManagement.routes.decodeToken import get_current_user
# from app.api.userManagement.schemas.userSchema import RegisterUserRequest
# from app.core.database import prisma
# from app.api.userManagement.utils.phoneUtils import generate_verification_code
# from app.core.firebase import verify_firebase_token  # Firebase phone verification

# router = APIRouter()


# def validate_password(password: str, logger):
#     password_regex = r'^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,16}$'
#     if not re.match(password_regex, password):
#         logger.warning("Password validation failed. Password must be 8-16 characters, include at least one uppercase, one lowercase, one digit, and one special character.")
#         raise HTTPException(status_code=400, detail="Password must be 8-16 characters, include at least one uppercase, one lowercase, one digit, and one special character.")

# async def register_non_admin_user(
#     first_name: str,
#     last_name: str,
#     username: str,
#     email: str,
#     password: str,
#     mobile_number: int,
#     country_code: str,
#     role: list[str],
#     property_id: int,
# ):
#     """Helper function to create a non-admin user in the database"""
#     return await prisma.aq_users.create(
#         data={
#             "first_name": first_name,
#             "last_name": last_name,
#             "username": username,
#             "email": email,
#             "password": password,
#             "mobile_number": mobile_number,
#             "country_code": country_code,
#             "role": role,
#             "property_id": property_id,
#         }
#     )
# @router.post("/createUser")
# async def register_user(user: RegisterUserRequest, background_tasks: BackgroundTasks, request: Request):
#     """
#     Endpoint for registering a new user. Prevents assigning the 'admin' role,
#     validates country code, hashes the password, and sends a verification code.
#     Also schedules a task to delete unverified users after 72 hours.
#     """
#     logger = request.state.logger
#     logger.debug("Starting user registration process for email: %s", user.email)

#     # Step 0: Get the current admin user
#     current_user = await get_current_user(request)

#     if not current_user.is_admin:
#         logger.warning("Unauthorized user %s attempted to create a user.", current_user.email)
#         raise HTTPException(status_code=403, detail="Only admins can create new users.")

#     property_id = current_user.property_id
#     if property_id is None:
#         logger.warning("Admin user %s has no associated property_id.", current_user.email)
#         raise HTTPException(status_code=400, detail="Admin user has no associated property_id.")

#     # Step 1: Validate password complexity
#     try:
#         validate_password(user.password, logger)
#     except HTTPException as e:
#         logger.error(f"Password validation failed for user {user.email}: {str(e.detail)}")
#         raise e

#     # Step 2: Validate country code
#     if user.country_code not in ["+1", "+91"]:
#         logger.warning("Invalid country code for user %s. Only +1 (USA) and +91 (India) are allowed.", user.email)
#         raise HTTPException(
#             status_code=400,
#             detail="Invalid country code. Only +1 (USA) and +91 (India) are allowed."
#         )

#     # Step 3: Prevent assigning the 'admin' role
#     if "Admin" in user.role:
#         logger.warning("Attempt to assign 'admin' role to user %s.", user.email)
#         raise HTTPException(
#             status_code=403,
#             detail="Cannot assign 'admin' role using this endpoint."
#         )

#     # Step 4: Validate Unique Fields
#     if await is_email_taken(user.email):
#         logger.warning("Email %s is already taken.", user.email)
#         raise HTTPException(status_code=409, detail="Email is already taken.")

#     if await is_username_taken(user.username):
#         logger.warning("Username %s is already taken.", user.username)
#         raise HTTPException(status_code=409, detail="Username is already taken.")

#     if await is_mobile_number_taken(user.mobile_number):
#         logger.warning("Mobile number %s is already taken.", user.mobile_number)
#         raise HTTPException(status_code=409, detail="Mobile number is already taken.")

#     # Step 5: Verify phone number using Firebase (if provided)
#     try:
#         phone_number = await verify_firebase_token(user.firebase_id_token)
#         is_phone_verified = True
#         logger.debug(f"Phone number {phone_number} verified successfully.")
#     except Exception as e:
#         is_phone_verified = False
#         logger.warning(f"Phone number verification failed for {user.email}: {str(e)}")

#     # Step 6: Hash the password
#     hashed_password = hash_password(user.password)
#     logger.debug("Password hashed successfully for user %s.", user.email)

#     # Step 7: Generate Verification Codes
#     phone_verification_code = generate_verification_code()
#     email_verification_code = generate_email_code()
#     verification_expiration_time = datetime.utcnow() + timedelta(minutes=10)
#     verification_code_sent_at = datetime.utcnow()

#     # Step 8: Create user in database
#     try:
#         created_user = await register_non_admin_user(
#             first_name=user.first_name,
#             last_name=user.last_name,
#             username=user.username,
#             email=user.email,
#             password=hashed_password,
#             mobile_number=user.mobile_number,
#             country_code=user.country_code,
#             role=user.role,
#             property_id=property_id  # <-- Pass here
#         )
#         logger.debug(f"User created successfully: {created_user.email}")

#         # Create verification record
#         await prisma.aq_user_verification.create(
#             data={
#                 "user_id": created_user.id,
#                 "is_phone_verified": is_phone_verified,
#                 "phone_verification_code": phone_verification_code,
#                 "phone_verification_code_sent_at": verification_code_sent_at,
#                 "phone_verification_code_expires_at": verification_expiration_time,
#                 "email_verification_code": email_verification_code,
#                 "email_verification_code_sent_at": verification_code_sent_at,
#                 "email_verification_code_expires_at": verification_expiration_time,
#             }
#         )
#         logger.debug(f"Verification records created for user {created_user.email}")

#         # Create security record
#         await prisma.aq_user_security.create(
#             data={
#                 "user_id": created_user.id,
#                 "force_password_reset": True,
#                 "login_attempts": 0
#             }
#         )
#         logger.debug(f"Security record created for user {created_user.email}")

#     except Exception as e:
#         logger.error(f"Error registering user in database for email {user.email}: {str(e)}")
#         raise HTTPException(status_code=500, detail=f"Error registering user in database: {str(e)}")

#     # Step 9: Assign roles to user
#     for role_name in user.role:
#         try:
#             role = await prisma.aq_roles.find_unique(where={"role_name": role_name})
#             if not role:
#                 logger.error(f"Invalid role: {role_name} for user {user.email}")
#                 continue

#             await prisma.aq_user_roles.create(
#                 data={
#                     "user_id": created_user.id,
#                     "role_id": role.id
#                 }
#             )
#             logger.debug(f"Assigned role {role_name} (ID: {role.id}) to user {user.email}")
#         except Exception as e:
#             logger.error(f"Error assigning role {role_name} to user {user.email}: {str(e)}")

#     # Step 10: Send Verification Email
#     try:
#         send_verification_email(user.email, email_verification_code)
#         logger.debug(f"Verification email sent to {user.email}")
#     except Exception as e:
#         logger.error(f"Error sending verification email to {user.email}: {str(e)}")

#     # Step 11: Send User Details Email
#     try:
#         user_details = {
#             "first_name": user.first_name,
#             "last_name": user.last_name,
#             "username": user.username,
#             "email": user.email,
#             "password": user.password,
#             "mobile_number": user.mobile_number,
#             "country_code": user.country_code,
#         }
#         send_user_creation_email(user.email, user_details)
#         logger.debug(f"User creation email sent to {user.email}")
#     except Exception as e:
#         logger.error(f"Error sending user creation email to {user.email}: {str(e)}")

#     # Step 12: Schedule cleanup task
#     background_tasks.add_task(delete_unverified_users, expiration_hours=72)
#     logger.debug("Scheduled task to delete unverified users after 72 hours.")

#     # Step 13: Return success response
#     logger.info(f"User {user.email} registered successfully.")
#     return {
#         "success": True,
#         "message": "User registered successfully. Verification code and account details sent via email.",
#         "user": {
#             "name": f"{user.first_name} {user.last_name}",
#             "email": user.email,
#             "roles": user.role,
#             "mobile_number": user.mobile_number,
#             "country_code": user.country_code
#         }
#     }



##Correct code start here 
# import re
# from fastapi import APIRouter, HTTPException, BackgroundTasks, Request
# from datetime import datetime, timedelta
# from app.api.userManagement.utils.passwordUtils import hash_password
# from app.api.userManagement.utils.emailUtils import (
#     send_verification_email,
#     send_user_creation_email,
#     generate_verification_code as generate_email_code
# )
# from app.core.auth import (
#     is_email_taken,
#     is_mobile_number_taken,
#     is_username_taken
# )
# from app.api.userManagement.utils.timeframe import delete_unverified_users
# from app.api.userManagement.schemas.userSchema import RegisterUserRequest
# from app.core.database import prisma
# from app.api.userManagement.utils.phoneUtils import generate_verification_code
# from app.core.firebase import verify_firebase_token  # Firebase phone verification

# router = APIRouter()


# def validate_password(password: str, logger):
#     password_regex = (
#         r'^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,16}$'
#     )
#     if not re.match(password_regex, password):
#         logger.warning(
#             "Password validation failed. Password must be 8-16 characters, "
#             "include at least one uppercase, one lowercase, one digit, and one special character."
#         )
#         raise HTTPException(
#             status_code=400,
#             detail="Password must be 8-16 characters, include at least one uppercase, one lowercase, one digit, and one special character."
#         )


# async def register_non_admin_user(
#     first_name: str,
#     last_name: str,
#     username: str,
#     email: str,
#     password: str,
#     mobile_number: int,
#     country_code: str,
#     role: list[str],
#     property_id: int
# ):
#     """Helper function to create a non-admin user in the database."""
#     return await prisma.aq_users.create(
#         data={
#             "first_name": first_name,
#             "last_name": last_name,
#             "username": username,
#             "email": email,
#             "password": password,
#             "mobile_number": mobile_number,
#             "country_code": country_code,
#             "role": role,
#             "property_id": property_id,
#         }
#     )


# @router.post("/createUser")
# async def register_user(
#     user: RegisterUserRequest,
#     background_tasks: BackgroundTasks,
#     request: Request
# ):
#     """
#     Endpoint for registering a new user.
#     Only the admin can create new users.
#     Admin email must be provided in the request body as `admin_email`.
#     """
#     logger = request.state.logger
#     logger.debug("Starting user registration process for email: %s", user.email)

#     await prisma.connect()

#     # Step 0: Get admin email from request body
#     admin_email = user.admin_email
#     if not admin_email:
#         logger.error("Admin email missing in request body.")
#         raise HTTPException(
#             status_code=400,
#             detail="Admin email is required in the request body."
#         )

#     # Step 1: Verify admin user
#     admin_user = await prisma.aq_users.find_unique(where={"email": admin_email})
#     if not admin_user:
#         logger.error(f"No user found with email {admin_email}")
#         raise HTTPException(status_code=404, detail="Admin user not found.")

#     if not admin_user.is_admin:
#         logger.warning(f"User {admin_email} is not an admin.")
#         raise HTTPException(status_code=403, detail="Only admins can create new users.")

#     property_id = admin_user.property_id
#     if property_id is None:
#         logger.warning(f"Admin user {admin_email} has no associated property_id.")
#         raise HTTPException(
#             status_code=400,
#             detail="Admin user has no associated property_id."
#         )

#     # Step 2: Validate password
#     try:
#         validate_password(user.password, logger)
#     except HTTPException as e:
#         logger.error(f"Password validation failed for user {user.email}: {str(e.detail)}")
#         raise e

#     # Step 3: Validate country code
#     if user.country_code not in ["+1", "+91"]:
#         logger.warning(
#             "Invalid country code for user %s. Only +1 (USA) and +91 (India) are allowed.",
#             user.email,
#         )
#         raise HTTPException(
#             status_code=400,
#             detail="Invalid country code. Only +1 (USA) and +91 (India) are allowed.",
#         )

#     # Step 4: Prevent assigning 'Admin' role
#     if "Admin" in user.role:
#         logger.warning("Attempt to assign 'Admin' role to user %s.", user.email)
#         raise HTTPException(
#             status_code=403,
#             detail="Cannot assign 'Admin' role using this endpoint.",
#         )

#     # Step 5: Validate unique fields
#     if await is_email_taken(user.email):
#         logger.warning("Email %s is already taken.", user.email)
#         raise HTTPException(status_code=409, detail="Email is already taken.")

#     if await is_username_taken(user.username):
#         logger.warning("Username %s is already taken.", user.username)
#         raise HTTPException(status_code=409, detail="Username is already taken.")

#     if await is_mobile_number_taken(user.mobile_number):
#         logger.warning("Mobile number %s is already taken.", user.mobile_number)
#         raise HTTPException(status_code=409, detail="Mobile number is already taken.")

#     # Step 6: Verify phone number using Firebase
#     try:
#         phone_number = await verify_firebase_token(user.firebase_id_token)
#         is_phone_verified = True
#         logger.debug(f"Phone number {phone_number} verified successfully.")
#     except Exception as e:
#         is_phone_verified = False
#         logger.warning(f"Phone number verification failed for {user.email}: {str(e)}")

#     # Step 7: Hash the password
#     hashed_password = hash_password(user.password)
#     logger.debug("Password hashed successfully for user %s.", user.email)

#     # Step 8: Generate verification codes
#     phone_verification_code = generate_verification_code()
#     email_verification_code = generate_email_code()
#     verification_expiration_time = datetime.utcnow() + timedelta(minutes=10)
#     verification_code_sent_at = datetime.utcnow()

#     # Step 9: Create user in database
#     try:
#         created_user = await register_non_admin_user(
#             first_name=user.first_name,
#             last_name=user.last_name,
#             username=user.username,
#             email=user.email,
#             password=hashed_password,
#             mobile_number=user.mobile_number,
#             country_code=user.country_code,
#             role=user.role,
#             property_id=property_id,
#         )
#         logger.debug(f"User created successfully: {created_user.email}")

#         # Create verification record
#         await prisma.aq_user_verification.create(
#             data={
#                 "user_id": created_user.id,
#                 "is_phone_verified": is_phone_verified,
#                 "phone_verification_code": phone_verification_code,
#                 "phone_verification_code_sent_at": verification_code_sent_at,
#                 "phone_verification_code_expires_at": verification_expiration_time,
#                 "email_verification_code": email_verification_code,
#                 "email_verification_code_sent_at": verification_code_sent_at,
#                 "email_verification_code_expires_at": verification_expiration_time,
#             }
#         )
#         logger.debug(f"Verification records created for user {created_user.email}")

#         # Create security record
#         await prisma.aq_user_security.create(
#             data={
#                 "user_id": created_user.id,
#                 "force_password_reset": True,
#                 "login_attempts": 0,
#             }
#         )
#         logger.debug(f"Security record created for user {created_user.email}")

#     except Exception as e:
#         logger.error(
#             f"Error registering user in database for email {user.email}: {str(e)}"
#         )
#         raise HTTPException(
#             status_code=500, detail=f"Error registering user in database: {str(e)}"
#         )

#     # Step 10: Assign roles to user
#     for role_name in user.role:
#         try:
#             role = await prisma.aq_roles.find_unique(where={"role_name": role_name})
#             if not role:
#                 logger.error(f"Invalid role: {role_name} for user {user.email}")
#                 continue

#             await prisma.aq_user_roles.create(
#                 data={"user_id": created_user.id, "role_id": role.id}
#             )
#             logger.debug(f"Assigned role {role_name} to user {user.email}")
#         except Exception as e:
#             logger.error(
#                 f"Error assigning role {role_name} to user {user.email}: {str(e)}"
#             )

#     # Step 11: Send verification email
#     try:
#         send_verification_email(user.email, email_verification_code)
#         logger.debug(f"Verification email sent to {user.email}")
#     except Exception as e:
#         logger.error(f"Error sending verification email to {user.email}: {str(e)}")

#     # Step 12: Send user details email
#     try:
#         user_details = {
#             "first_name": user.first_name,
#             "last_name": user.last_name,
#             "username": user.username,
#             "email": user.email,
#             "password": user.password,
#             "mobile_number": user.mobile_number,
#             "country_code": user.country_code,
#         }
#         send_user_creation_email(user.email, user_details)
#         logger.debug(f"User creation email sent to {user.email}")
#     except Exception as e:
#         logger.error(f"Error sending user creation email to {user.email}: {str(e)}")

#     # Step 13: Schedule cleanup task
#     background_tasks.add_task(delete_unverified_users, expiration_hours=72)
#     logger.debug("Scheduled task to delete unverified users after 72 hours.")

#     # Step 14: Return success response
#     logger.info(f"User {user.email} registered successfully.")
#     return {
#         "success": True,
#         "message": "User registered successfully. Verification code and account details sent via email.",
#         "user": {
#             "name": f"{user.first_name} {user.last_name}",
#             "email": user.email,
#             "roles": user.role,
#             "mobile_number": user.mobile_number,
#             "country_code": user.country_code,
#         },
#     }
##Correct code end here 

import re
from fastapi import APIRouter, HTTPException, BackgroundTasks, Request
from datetime import datetime, timedelta
from app.api.userManagement.utils.passwordUtils import hash_password
from app.api.userManagement.utils.emailUtils import (
    send_verification_email,
    send_user_creation_email,
    generate_verification_code as generate_email_code
)
from app.core.auth import (
    is_email_taken,
    is_mobile_number_taken,
    is_username_taken
)
from app.api.userManagement.utils.timeframe import delete_unverified_users
from app.api.userManagement.schemas.userSchema import RegisterUserRequest
from app.core.database import prisma
from app.api.userManagement.utils.phoneUtils import generate_verification_code
from app.core.firebase import verify_firebase_token
import traceback
import logging
router = APIRouter()


def validate_password(password: str, logger):
    password_regex = (
        r'^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,16}$'
    )
    if not re.match(password_regex, password):
        logger.warning(
            "Password validation failed. Password must be 8-16 characters, "
            "include at least one uppercase, one lowercase, one digit, and one special character."
        )
        raise HTTPException(
            status_code=400,
            detail="Password must be 8-16 characters, include at least one uppercase, one lowercase, one digit, and one special character."
        )


async def register_non_admin_user(
    first_name: str,
    last_name: str,
    username: str,
    email: str,
    password: str,
    mobile_number: int,
    country_code: str,
    role: list[str],
    property_id: int,
    logger
):
    """Helper function to create a non-admin user in the database."""
    try:
        return await prisma.aq_users.create(
            data={
                "first_name": first_name,
                "last_name": last_name,
                "username": username,
                "email": email,
                "password": password,
                "mobile_number": mobile_number,
                "country_code": country_code,
                "role": role,
                "property_id": property_id,
            }
        )
    except Exception as e:
        logger.error(f"Error creating user in database: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail=f"Database error while creating user: {str(e)}"
        )

@router.post("/createUser")
async def register_user(
    user: RegisterUserRequest,
    background_tasks: BackgroundTasks,
    request: Request
):
    """
    Endpoint for registering a new user.
    Only users with Super_Admin or Admin role can create new users.
    Admin email must be provided in the request body as `admin_email`.
    """
    logger = request.state.logger
    logger.debug("Starting user registration process for email: %s", user.email)

    try:
        # Step 0: Get admin email from request body
        admin_email = user.admin_email
        if not admin_email:
            logger.error("Admin email missing in request body.")
            raise HTTPException(
                status_code=400,
                detail="Admin email is required in the request body. Please provide the email of the admin creating this user."
            )

        # Step 1: Verify admin user exists
        admin_user = await prisma.aq_users.find_unique(where={"email": admin_email})
        if not admin_user:
            logger.error(f"No user found with email {admin_email}")
            raise HTTPException(status_code=404, detail="Admin user not found.")

        # Step 2: Check if the requesting user has Super_Admin or Admin role
        admin_user_roles = await prisma.aq_user_roles.find_many(
            where={"user_id": admin_user.id},
            include={"aq_roles": True}  # FIXED: Changed from "role" to "aq_roles"
        )
        
        # Extract role names
        admin_role_names = []
        for user_role in admin_user_roles:
            if user_role.aq_roles and user_role.aq_roles.role_name:  # FIXED: Changed from user_role.role to user_role.aq_roles
                admin_role_names.append(user_role.aq_roles.role_name)  # FIXED: Changed here too
        
        # Check if user has Super_Admin or Admin role
        has_admin_access = False
        for role_name in admin_role_names:
            if role_name in ["Super_Admin", "Admin"]:
                has_admin_access = True
                break
        
        if not has_admin_access:
            logger.warning(f"User {admin_email} does not have Super_Admin or Admin role. Their roles: {admin_role_names}")
            raise HTTPException(
                status_code=403, 
                detail="Only users with Super_Admin or Admin role can create new users."
            )

        # Step 3: Get property_id from admin user
        property_id = getattr(admin_user, 'property_id', None)
        if property_id is None:
            logger.warning(f"Admin user {admin_email} has no associated property_id.")
            raise HTTPException(
                status_code=400,
                detail="Admin user has no associated property_id."
            )

        # Step 4: Validate password
        try:
            validate_password(user.password, logger)
        except HTTPException as e:
            logger.error(f"Password validation failed for user {user.email}: {str(e.detail)}")
            raise e

        # Step 5: Validate country code
        if user.country_code not in ["+1", "+91"]:
            logger.warning(
                "Invalid country code for user %s. Only +1 (USA) and +91 (India) are allowed.",
                user.email,
            )
            raise HTTPException(
                status_code=400,
                detail="Invalid country code. Only +1 (USA) and +91 (India) are allowed.",
            )

        # Step 6: Prevent assigning 'Admin' or 'Super_Admin' roles
        forbidden_roles = ["Admin", "Super_Admin"]
        for forbidden_role in forbidden_roles:
            if forbidden_role in user.role:
                logger.warning(f"Attempt to assign '{forbidden_role}' role to user %s.", user.email)
                raise HTTPException(
                    status_code=403,
                    detail=f"Cannot assign '{forbidden_role}' role using this endpoint.",
                )

        # Step 7: Validate unique fields
        if await is_email_taken(user.email):
            logger.warning("Email %s is already taken.", user.email)
            raise HTTPException(status_code=409, detail="Email is already taken.")

        if await is_username_taken(user.username):
            logger.warning("Username %s is already taken.", user.username)
            raise HTTPException(status_code=409, detail="Username is already taken.")

        if await is_mobile_number_taken(user.mobile_number):
            logger.warning("Mobile number %s is already taken.", user.mobile_number)
            raise HTTPException(status_code=409, detail="Mobile number is already taken.")

        # Step 8: Phone verification (optional - only if firebase token provided)
        is_phone_verified = False
        firebase_id_token = user.firebase_id_token
        if firebase_id_token:
            try:
                phone_number = await verify_firebase_token(firebase_id_token)
                is_phone_verified = True
                logger.debug(f"Phone number {phone_number} verified successfully.")
            except Exception as e:
                logger.warning(f"Phone number verification failed for {user.email}: {str(e)}")
        else:
            logger.info(f"No Firebase token provided for user {user.email}. Phone will not be pre-verified.")

        # Step 9: Hash the password
        hashed_password = hash_password(user.password)
        logger.debug("Password hashed successfully for user %s.", user.email)

        # Step 10: Generate verification codes
        phone_verification_code = generate_verification_code()
        email_verification_code = generate_email_code()
        verification_expiration_time = datetime.utcnow() + timedelta(minutes=10)
        verification_code_sent_at = datetime.utcnow()

        # Step 11: Create user in database
        try:
            created_user = await register_non_admin_user(
                first_name=user.first_name,
                last_name=user.last_name,
                username=user.username,
                email=user.email,
                password=hashed_password,
                mobile_number=user.mobile_number,
                country_code=user.country_code,
                role=user.role,
                property_id=property_id,
                logger=logger
            )
            logger.debug(f"User created successfully: {created_user.email}")

            # Create verification record
            await prisma.aq_user_verification.create(
                data={
                    "user_id": created_user.id,
                    "is_phone_verified": is_phone_verified,
                    "phone_verification_code": phone_verification_code,
                    "phone_verification_code_sent_at": verification_code_sent_at,
                    "phone_verification_code_expires_at": verification_expiration_time,
                    "email_verification_code": email_verification_code,
                    "email_verification_code_sent_at": verification_code_sent_at,
                    "email_verification_code_expires_at": verification_expiration_time,
                }
            )
            logger.debug(f"Verification records created for user {created_user.email}")

            # Create security record
            await prisma.aq_user_security.create(
                data={
                    "user_id": created_user.id,
                    "force_password_reset": True,
                    "login_attempts": 0,
                }
            )
            logger.debug(f"Security record created for user {created_user.email}")

        except HTTPException:
            raise
        except Exception as e:
            logger.error(
                f"Error registering user in database for email {user.email}: {str(e)}"
            )
            raise HTTPException(
                status_code=500, detail=f"Error registering user in database: {str(e)}"
            )

        # Step 12: Assign roles to user
        for role_name in user.role:
            try:
                role = await prisma.aq_roles.find_unique(where={"role_name": role_name})
                if not role:
                    logger.error(f"Invalid role: {role_name} for user {user.email}")
                    raise HTTPException(
                        status_code=400,
                        detail=f"Invalid role: {role_name}"
                    )

                await prisma.aq_user_roles.create(
                    data={"user_id": created_user.id, "role_id": role.id}
                )
                logger.debug(f"Assigned role {role_name} to user {user.email}")
            except Exception as e:
                logger.error(
                    f"Error assigning role {role_name} to user {user.email}: {str(e)}"
                )
                raise HTTPException(
                    status_code=500,
                    detail=f"Error assigning role {role_name}: {str(e)}"
                )

        # Step 13: Send verification email
        try:
            send_verification_email(user.email, email_verification_code)
            logger.debug(f"Verification email sent to {user.email}")
        except Exception as e:
            logger.error(f"Error sending verification email to {user.email}: {str(e)}")

        # Step 14: Send user details email
        try:
            user_details = {
                "first_name": user.first_name,
                "last_name": user.last_name,
                "username": user.username,
                "email": user.email,
                "password": user.password,
                "mobile_number": user.mobile_number,
                "country_code": user.country_code,
            }
            send_user_creation_email(user.email, user_details)
            logger.debug(f"User creation email sent to {user.email}")
        except Exception as e:
            logger.error(f"Error sending user creation email to {user.email}: {str(e)}")

        # Step 15: Schedule cleanup task
        background_tasks.add_task(delete_unverified_users, expiration_hours=72)
        logger.debug("Scheduled task to delete unverified users after 72 hours.")

        # Step 16: Return success response
        logger.info(f"User {user.email} registered successfully by admin {admin_email}.")
        return {
            "success": True,
            "message": "User registered successfully. Verification code and account details sent via email.",
            "user": {
                "name": f"{user.first_name} {user.last_name}",
                "email": user.email,
                "roles": user.role,
                "mobile_number": user.mobile_number,
                "country_code": user.country_code,
                "created_by": admin_email
            },
        }

    except HTTPException as he:
        logger.error(f"HTTPException in register_user: {str(he.detail)}")
        raise he
    except Exception as e:
        logger.error(f"Unexpected error in register_user: {str(e)}")
        logger.error(f"Full error traceback:\n{traceback.format_exc()}")
        raise HTTPException(
            status_code=500,
            detail="Internal server error. Please try again later."
        )