# from fastapi import APIRouter, HTTPException, Depends, status
# from prisma import Prisma
# from datetime import datetime
# from app.core.database import get_prisma_client
# from app.core.auth import get_current_user
# from app.api.userManagement.schemas.userSchema import RoleRequestUpdatePayload  # Define as needed

# router = APIRouter()

# @router.post("/roleReject", status_code=status.HTTP_200_OK)
# async def reject_role_request(
#     role_request_id: int,
#     payload: RoleRequestUpdatePayload,  # Admin comment for rejection
#     current_user: dict = Depends(get_current_user),  # Get the current user
#     prisma: Prisma = Depends(get_prisma_client)  # Inject the Prisma client
# ):
#     """
#     Allow admins to reject a role request and update the status.
#     """
#     # Ensure the current user is an admin
#     if not current_user.is_admin:
#         raise HTTPException(
#             status_code=403,
#             detail="Only admins can reject role requests."
#         )

#     # Fetch the role request from the database
#     role_request = await prisma.rolerequest.find_unique(
#         where={"id": role_request_id},
#         include={"users1": True}  # Include user details if needed
#     )
#     if not role_request:
#         raise HTTPException(
#             status_code=404,
#             detail="Role request not found."
#         )

#     # Ensure the role request is in a "pending" state
#     if role_request.status != "pending":
#         raise HTTPException(
#             status_code=400,
#             detail="Only pending role requests can be rejected."
#         )

#     # Get the rejection reason or comment from the admin
#     rejection_reason = payload.admin_comment if payload.admin_comment else "No reason provided"

#     # Update the role request status to "rejected" and store the rejection reason
#     try:
#         updated_request = await prisma.rolerequest.update(
#             where={"id": role_request_id},
#             data={
#                 "status": "rejected",
#                 "timestamp": datetime.utcnow(),  # Optionally update the timestamp
#                 "admin_comment": rejection_reason  # Store the admin comment (rejection reason)
#             }
#         )
#     except Exception as e:
#         raise HTTPException(
#             status_code=500,
#             detail=f"Error updating role request status: {str(e)}"
#         )

#     return {
#         "success": True,
#         "message": f"Role request ID {role_request_id} rejected. Reason: {rejection_reason}",
#     }



#Web Socket Implemention
#logs

from fastapi import APIRouter, HTTPException, Depends, status, Request
from prisma import Prisma
from datetime import datetime
from app.core.database import get_prisma_client
from app.core.auth import get_current_user
from app.api.userManagement.schemas.userSchema import RoleRequestUpdatePayload
from app.api.userManagement.utils.wsUtils import broadcast_message  # Import the broadcast utility

router = APIRouter()

@router.post("/roleReject", status_code=status.HTTP_200_OK)
async def reject_role_request(
    role_request_id: int,
    payload: RoleRequestUpdatePayload,request: Request,  # Admin comment for rejection
    current_user: dict = Depends(get_current_user),  # Get the current user
    prisma: Prisma = Depends(get_prisma_client),  # Inject the Prisma client
      # Access the request object to get the logger
):
    """
    Allow admins to reject a role request and update the status.
    """
    logger = request.state.logger  # Access the logger from request.state

    # Log the rejection attempt
    logger.info(f"Admin {current_user.username} is attempting to reject role request ID {role_request_id}.")

    # Ensure the current user is an admin
    if not current_user.is_admin:
        logger.warning(f"Non-admin user {current_user.username} tried to reject a role request.")
        raise HTTPException(
            status_code=403,
            detail="Only admins can reject role requests."
        )

    # Fetch the role request from the database
    role_request = await prisma.aq_rolerequests.find_unique(
        where={"id": role_request_id},
        include={"aq_users": True}  # Include user details if needed
    )
    if not role_request:
        logger.error(f"Role request ID {role_request_id} not found.")
        raise HTTPException(
            status_code=404,
            detail="Role request not found."
        )

    # Ensure the role request is in a "pending" state
    if role_request.status != "pending":
        logger.warning(f"Attempt to reject role request ID {role_request_id}, but it's not in 'pending' state.")
        raise HTTPException(
            status_code=400,
            detail="Only pending role requests can be rejected."
        )

    # Get the rejection reason or comment from the admin
    rejection_reason = payload.admin_comment if payload.admin_comment else "No reason provided"
    logger.info(f"Role request ID {role_request_id} rejected with reason: {rejection_reason}.")

    # Update the role request status to "rejected" and store the rejection reason
    try:
        updated_request = await prisma.aq_rolerequests.update(
            where={"id": role_request_id},
            data={
                "status": "rejected",
                "timestamp": datetime.utcnow(),  # Optionally update the timestamp
                "admin_comment": rejection_reason  # Store the admin comment (rejection reason)
            }
        )
        logger.info(f"Role request ID {role_request_id} status updated to 'rejected'.")
    except Exception as e:
        logger.error(f"Error occurred while updating role request ID {role_request_id}: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail=f"Error updating role request status: {str(e)}"
        )

    # Broadcast the rejection message to all WebSocket clients
    rejection_message = f"Role request ID {role_request_id} rejected. Reason: {rejection_reason}"
    await broadcast_message(rejection_message)
    logger.info(f"Rejection message broadcasted: {rejection_message}")

    return {
        "success": True,
        "message": rejection_message,
    }
