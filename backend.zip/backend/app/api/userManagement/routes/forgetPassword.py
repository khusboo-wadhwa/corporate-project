# from fastapi import APIRouter, HTTPException, Depends, status
# from datetime import datetime, timedelta, timezone
# from fastapi.responses import JSONResponse
# from pydantic import BaseModel
# import re

# from app.api.userManagement.utils.emailUtils import send_verification_email, generate_verification_code
# from app.core.auth import get_user_by_email, update_user_password, update_user_email_verification_code
# from app.api.userManagement.utils.passwordUtils import hash_password
# from app.api.userManagement.schemas.userSchema import (ForgotPasswordRequest,OTPVerificationRequest,ResetPasswordRequest)

# # Router instance
# router = APIRouter()

# # Regular expression for password validation
# PASSWORD_REGEX = r"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,16}$"

# # Temporary in-memory storage for email and OTP (replace with database in production)
# otp_cache = {}



# # Endpoint: Forgot Password
# @router.post("/forgotPassword")
# async def forgot_password(request: ForgotPasswordRequest):
#     """
#     Endpoint to initiate the forgot password process by sending an OTP.
#     """
#     try:
#         # Check if the user exists
#         user = await get_user_by_email(request.email)
#         if not user:
#             raise HTTPException(
#                 status_code=status.HTTP_404_NOT_FOUND,
#                 detail="User with the provided email does not exist."
#             )

#         # Check if the user is an admin
#         if not user.is_admin:
#             raise HTTPException(
#                 status_code=status.HTTP_403_FORBIDDEN,
#                 detail="Only admins can reset their own password. Please contact your domain admin for assistance."
#             )

#         # Generate verification code and expiration time
#         verification_code = generate_verification_code()
#         expiration_time = datetime.now(timezone.utc) + timedelta(minutes=1)

#         # Save the verification code and email in in-memory storage
#         otp_cache[verification_code] = {
#             "email": request.email,
#             "expires_at": expiration_time
#         }

#         # Send the verification code via email
#         send_verification_email(request.email, verification_code, email_type="forgot_password")

#         # Return success response
#         return JSONResponse(
#             status_code=status.HTTP_200_OK,
#             content={
#                 "success": True,
#                 "message": "A verification code has been sent to your email."
#             }
#         )

#     except Exception as e:
#         raise HTTPException(
#             status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
#             detail=f"An error occurred: {str(e)}"
#         )


# # Endpoint: Verify OTP
# @router.post("/verifyOTP")
# async def verify_otp(request: OTPVerificationRequest):
#     """
#     Endpoint to verify the OTP sent during the forgot password process.
#     """
#     global otp_cache  # Ensure this uses the global variable

#     try:
#         # Fetch the email and expiration time associated with the OTP
#         otp_data = otp_cache.get(request.verification_code)
#         if not otp_data:
#             raise HTTPException(
#                 status_code=status.HTTP_400_BAD_REQUEST,
#                 detail="Invalid verification code."
#             )

#         # Check if the OTP is expired
#         if otp_data["expires_at"] < datetime.now(timezone.utc):
#             # Mark OTP as expired (do not delete yet)
#             otp_data["expired"] = True
#             raise HTTPException(
#                 status_code=status.HTTP_400_BAD_REQUEST,
#                 detail="Verification code is expired."
#             )

#         # If OTP is valid, return a success response
#         return JSONResponse(
#             status_code=status.HTTP_200_OK,
#             content={
#                 "success": True,
#                 "message": "OTP verified successfully. You can now reset your password."
#             }
#         )

#     except Exception as e:
#         raise HTTPException(
#             status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
#             detail=f"An error occurred: {str(e)}"
#         )

# #Endpoint:resendOTP 
# @router.get("/resendOTP")
# async def resend_otp():
#     """
#     Endpoint to resend the OTP for the forgot password process.
#     Considers the most recent email used for generating the OTP.
#     """
#     global otp_cache  # Ensure this uses the global variable

#     try:
#         # Identify the most recent expired or unverified OTP
#         recent_expired_entry = None
#         for code, data in otp_cache.items():
#             if "expired" in data and data["expired"]:  # Check if OTP is explicitly marked as expired
#                 recent_expired_entry = data
#                 break

#         if not recent_expired_entry:
#             raise HTTPException(
#                 status_code=status.HTTP_400_BAD_REQUEST,
#                 detail="No expired OTP found. Please initiate forgot password first."
#             )

#         email = recent_expired_entry["email"]

#         # Generate new verification code and expiration time
#         verification_code = generate_verification_code()
#         expiration_time = datetime.now(timezone.utc) + timedelta(minutes=3)

#         # Save the new verification code in in-memory storage
#         otp_cache[verification_code] = {
#             "email": email,
#             "expires_at": expiration_time
#         }

#         # Delete the previous expired OTP
#         otp_cache = {k: v for k, v in otp_cache.items() if k != recent_expired_entry}

#         # Send the new verification code via email
#         send_verification_email(email, verification_code, email_type="resend_otp")

#         # Return success response
#         return JSONResponse(
#             status_code=status.HTTP_200_OK,
#             content={
#                 "success": True,
#                 "message": f"A new verification code has been sent to the email: {email}."
#             }
#         )

#     except Exception as e:
#         raise HTTPException(
#             status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
#             detail=f"An error occurred: {str(e)}"
#         )

# # Endpoint: Reset Password
# @router.post("/resetPassword")
# async def reset_password(request: ResetPasswordRequest):
#     """
#     Endpoint to reset the password after OTP verification.
#     """
#     global otp_cache  # Reference the global otp_cache

#     try:
#         # Check if there is an OTP in the cache
#         otp_email = None
#         for code, data in otp_cache.items():
#             if data["expires_at"] >= datetime.now(timezone.utc):
#                 otp_email = data["email"]
#                 break

#         if not otp_email:
#             raise HTTPException(
#                 status_code=status.HTTP_400_BAD_REQUEST,
#                 detail="OTP verification is required before resetting the password."
#             )

#         # Validate password strength
#         if not re.match(PASSWORD_REGEX, request.new_password):
#             raise HTTPException(
#                 status_code=status.HTTP_400_BAD_REQUEST,
#                 detail=(
#                     "Password must be 8-16 characters long, including at least one uppercase letter, "
#                     "one lowercase letter, one number, and one special character."
#                 )
#             )

#         # Check if the new password matches the confirmation password
#         if request.new_password != request.confirm_password:
#             raise HTTPException(
#                 status_code=status.HTTP_400_BAD_REQUEST,
#                 detail="New password and confirmation password do not match."
#             )

#         # Hash and update the password
#         hashed_password = hash_password(request.new_password)
#         await update_user_password(otp_email, hashed_password)

#         # Remove the OTP associated with the email
#         otp_cache = {code: data for code, data in otp_cache.items() if data["email"] != otp_email}

#         # Return success response
#         return JSONResponse(
#             status_code=status.HTTP_200_OK,
#             content={
#                 "success": True,
#                 "message": "Password has been reset successfully."
#             }
#         )

#     except Exception as e:
#         raise HTTPException(
#             status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
#             detail=f"An error occurred: {str(e)}"
#         )



#logs
from fastapi import APIRouter, HTTPException, Depends, status, Request
from datetime import datetime, timedelta, timezone
from fastapi.responses import JSONResponse
from pydantic import BaseModel
import re
from prisma import Prisma
from app.api.userManagement.utils.emailUtils import send_verification_email, generate_verification_code
from app.core.auth import get_user_by_email, update_user_password, update_user_email_verification_code
from app.api.userManagement.utils.passwordUtils import hash_password
from app.api.userManagement.schemas.userSchema import (ForgotPasswordRequest, OTPVerificationRequest, ResetPasswordRequest)
from app.core.database import get_prisma_client



# Router instance
router = APIRouter()

# Regular expression for password validation
PASSWORD_REGEX = r"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,16}$"

# Temporary in-memory storage for email and OTP (replace with database in production)
otp_cache = {}

# Endpoint: Forgot Password
@router.post("/forgotPassword")
async def forgot_password(request: Request, body: ForgotPasswordRequest):
    """
    Endpoint to initiate the forgot password process by sending an OTP.
    """
    try:
        logger = request.state.logger  # Access the logger from request.state

        # Check if the user exists
        user = await get_user_by_email(body.email)
        if not user:
            logger.error(f"User with email {body.email} does not exist.")
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="User with the provided email does not exist."
            )

        # Check if the user is an admin
        if not user.is_admin:
            logger.error(f"User {body.email} is not an admin. Cannot reset password.")
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Only admins can reset their own password. Please contact your domain admin for assistance."
            )

        # Get Prisma client
        prisma = await get_prisma_client()

        # 1. Check if aq_user_verification and aq_user_security exist, create if not
        verification = await prisma.aq_user_verification.find_unique(where={"user_id": user.id})
        if not verification:
            # Create missing aq_user_verification entry
            verification = await prisma.aq_user_verification.create(
                data={"user_id": user.id}
            )
            logger.info(f"Created aq_user_verification for user_id={user.id}")

        security = await prisma.aq_user_security.find_unique(where={"user_id": user.id})
        if not security:
            # Create missing aq_user_security entry
            security = await prisma.aq_user_security.create(
                data={"user_id": user.id}
            )
            logger.info(f"Created aq_user_security for user_id={user.id}")

        # Generate verification code and expiration time
        verification_code = generate_verification_code()
        expiration_time = datetime.now(timezone.utc) + timedelta(minutes=1)

        # 2. Store the OTP code in the database
        updated_verification = await prisma.aq_user_verification.update(
            where={"user_id": user.id},
            data={
                "reset_password_code": verification_code,
                "reset_password_code_expires_at": expiration_time
            }
        )
        logger.info(f"Stored verification code in database for user_id={user.id}")

        # Send the verification code via email
        send_verification_email(body.email, verification_code, email_type="forgot_password")
        logger.info(f"Sent verification code to {body.email}.")

        # Return success response
        return JSONResponse(
            status_code=status.HTTP_200_OK,
            content={
                "success": True,
                "message": "A verification code has been sent to your email."
            }
        )

    except Exception as e:
        logger.error(f"Error occurred during forgot password process: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"An error occurred: {str(e)}"
        )

        
@router.post("/emailVerifyOTP")
async def verify_otp(request: Request, body: OTPVerificationRequest):
    """
    Endpoint to verify the OTP sent during the forgot password process.
    Verifies the OTP stored in the `aq_user_verification` table.
    """
    if not body.email:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Email is required."
        )

    try:
        # Initialize Prisma client and logger
        prisma = Prisma()
        logger = request.state.logger  # Access the logger from request.state

        if not prisma.is_connected():
            await prisma.connect()

        # Fetch the user verification record from the database using the email
        user_verification = await prisma.aq_user_verification.find_first(
            where={
                "aq_users": {  # Join the aq_users table to access the email field
                    "email": body.email
                }
            }
        )

        if not user_verification:
            logger.error(f"User verification record not found for email {body.email}.")
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="No verification record found for this email."
            )

        # Check if the OTP matches
        if user_verification.email_verification_code != body.verification_code:
            logger.error(f"Invalid OTP {body.verification_code} for email {body.email}. Stored OTP: {user_verification.email_verification_code}")
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid verification code."
            )

        # Check if the OTP has expired
        if user_verification.email_verification_code_expires_at and user_verification.email_verification_code_expires_at < datetime.now(timezone.utc):
            logger.warning(f"OTP {body.verification_code} for email {body.email} has expired.")
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Verification code has expired."
            )

        # Log success and proceed
        logger.info(f"OTP {body.verification_code} verified successfully for email {body.email}.")

        # Optional: Mark the email as verified in the database if needed
        await prisma.aq_user_verification.update(
            where={"user_id": user_verification.user_id},  # Update using user_id to reference the correct user
            data={"is_email_verified": True}  # Assuming there's an `is_email_verified` field
        )

        # Return a success message
        return JSONResponse(
            status_code=status.HTTP_200_OK,
            content={
                "success": True,
                "message": "OTP verified successfully. You can now reset your password."
            }
        )

    except Exception as e:
        logger.error(f"Error occurred during OTP verification for {body.email}: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"An error occurred while verifying the OTP: {str(e)}"
        )

@router.post("/verifyOTP")
async def verify_otp(request: Request, body: OTPVerificationRequest):
    global otp_cache

    try:
        logger = request.state.logger

        # 1. Get prisma client (make sure to await the coroutine here)
        prisma = await get_prisma_client()

        # Try to find the user by the provided email
        user = await prisma.aq_users.find_unique(where={"email": body.email})
        if not user:
            raise HTTPException(status_code=404, detail="User not found.")

        # 2. Check if aq_user_verification and aq_user_security exist, create if not
        verification = await prisma.aq_user_verification.find_unique(where={"user_id": user.id})
        if not verification:
            # Create missing aq_user_verification entry
            verification = await prisma.aq_user_verification.create(
                data={"user_id": user.id}
            )
            logger.info(f"Created aq_user_verification for user_id={user.id}")

        security = await prisma.aq_user_security.find_unique(where={"user_id": user.id})
        if not security:
            # Create missing aq_user_security entry
            security = await prisma.aq_user_security.create(
                data={"user_id": user.id}
            )
            logger.info(f"Created aq_user_security for user_id={user.id}")

        # 3. Check for OTP code in aq_user_verification table
        if not verification.reset_password_code:
            raise HTTPException(status_code=400, detail="No OTP request found for password reset.")

        # 4. Validate OTP and expiration
        if verification.reset_password_code != body.verification_code:
            logger.error("Invalid verification code.")
            raise HTTPException(status_code=400, detail="Invalid verification code.")

        if verification.reset_password_code_expires_at < datetime.now(timezone.utc):
            logger.warning("OTP expired.")
            raise HTTPException(status_code=400, detail="OTP has expired.")

        # 5. If OTP is valid, allow password reset
        return JSONResponse(
            status_code=200,
            content={"success": True, "message": "OTP verified. You can now reset your password."}
        )

    except Exception as e:
        logger.error(f"Error during OTP verification: {str(e)}")
        raise HTTPException(status_code=500, detail=f"An error occurred: {str(e)}")



@router.get("/resendOTP")
async def resend_otp(request: Request):
    """
    Endpoint to resend the OTP for the forgot password process.
    Uses the most recent email used for generating the OTP.
    """
    try:
        logger = request.state.logger  # Access the logger from request.state

        # Extract the email from the frontend (localStorage or request body)
        email = request.headers.get("email")  # Assuming email is sent in headers, you can adjust this logic

        if not email:
            logger.error("Email not provided.")
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Email is required."
            )

        # Initialize Prisma client
        prisma = Prisma()
        if not prisma.is_connected():
            await prisma.connect()

        # Fetch the user verification record from the database using the email
        user_verification = await prisma.aq_user_verification.find_first(
            where={
                "aq_users": {
                    "email": email  # Search for the email in the related aq_users table
                }
            }
        )

        if not user_verification:
            logger.error(f"User verification record not found for email {email}.")
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="No verification record found for this email."
            )

        # Generate new verification code and expiration time
        verification_code = generate_verification_code()  # You need to implement this function
        expiration_time = datetime.now(timezone.utc) + timedelta(minutes=5)  # New expiry time

        # Update the OTP and expiration time in the database
        updated_verification = await prisma.aq_user_verification.update(
            where={"user_id": user_verification.user_id},
            data={
                "email_verification_code": verification_code,
                "email_verification_code_expires_at": expiration_time,
                "email_verification_code_sent_at": datetime.now(timezone.utc)
            }
        )

        # Send the new OTP to the email
        send_verification_email(email, verification_code, email_type="resend_otp")  # Ensure this function is defined

        # Log resend OTP
        logger.info(f"Resent verification code to {email}.")

        # Return success response
        return JSONResponse(
            status_code=status.HTTP_200_OK,
            content={
                "success": True,
                "message": f"A new verification code has been sent to the email: {email}."
            }
        )

    except Exception as e:
        logger.error(f"Error occurred during OTP resend for {email}: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"An error occurred: {str(e)}"
        )
@router.post("/resetPassword")
async def reset_password(request: Request, body: ResetPasswordRequest):
    prisma = await get_prisma_client()
    logger = request.state.logger

    try:
        # Validate password strength
        if not re.match(PASSWORD_REGEX, body.new_password):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=(
                    "Password must be 8-16 characters long, including at least one uppercase letter, "
                    "one lowercase letter, one number, and one special character."
                )
            )

        if body.new_password != body.confirm_password:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="New password and confirmation password do not match."
            )

        # Find user
        user = await prisma.aq_users.find_unique(where={"email": body.email})
        if not user:
            raise HTTPException(status_code=404, detail="User not found.")

        # Hash password
        hashed_password = hash_password(body.new_password)

        # Update aq_users table
        await prisma.aq_users.update(
            where={"id": user.id},
            data={
                "password": hashed_password,
                "first_login": False,
            }
        )

        # Update aq_user_security table
        await prisma.aq_user_security.update(
            where={"user_id": user.id},
            data={
                "last_password_reset_date": datetime.now(timezone.utc),
                "force_password_reset": False,
                "is_temp_used": True
            }
        )

        logger.info(f"Password for {body.email} has been reset successfully.")

        return JSONResponse(
            status_code=status.HTTP_200_OK,
            content={"success": True, "message": "Password has been reset successfully."}
        )

    except Exception as e:
        logger.error(f"Password reset failed: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"An error occurred: {str(e)}"
        )
