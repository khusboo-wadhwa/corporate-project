from fastapi import APIRouter, Depends, HTTPException, status, Request
from prisma import Prisma
from app.core.database import get_prisma_client  # Import the Prisma client dependency
from app.core.auth import get_current_user
from app.api.userManagement.utils.wsUtils import broadcast_message  # Import the WebSocket utility

# Create an instance of APIRouter
router = APIRouter()

@router.get("/getRoleRequests", status_code=status.HTTP_200_OK)
async def get_all_role_requests(request: Request,
    current_user: dict = Depends(get_current_user),  # Admin authentication assumed
    prisma: Prisma = Depends(get_prisma_client)  # Inject the Prisma client here
):
    """
    Fetch all role requests, including ID, reason, status, user details, and permission name.
    This endpoint is only accessible by admins.
    """
    logger = request.state.logger  # Access the logger from request.state

    logger.info(f"Admin {current_user.username} is fetching all role requests.")

    # Ensure the current user is an admin
    if not current_user.is_admin:
        logger.warning(f"Non-admin user {current_user.username} tried to access role requests.")
        raise HTTPException(
            status_code=403,
            detail="You do not have permission to access this resource."
        )

    # Query the database for all role requests and include user details AND permission details
    try:
        all_requests = await prisma.aq_rolerequests.find_many(
            include={
                "aq_users": True,  # Include the related user details
                "aq_permissions": True  # Include the related permission details
            }
        )
        logger.info(f"Successfully fetched {len(all_requests)} role requests from the database.")
    except Exception as e:
        logger.error(f"Error retrieving role requests: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail=f"Error retrieving role requests: {str(e)}"
        )

    # Format the data
    formatted_requests = [
        {
            "id": request.id,
            "reason": request.reason,
            "requested_role": request.requested_role,
            "user_id": request.user_id,
            "timestamp": request.timestamp,
            "status": request.status,  # Include status of the request
            "admin_comment": request.admin_comment,
            "requested_permission_id": request.requested_permission_id,
            "permission_name": request.aq_permissions.permission_name if request.aq_permissions else None,
            "permission_description": request.aq_permissions.description if request.aq_permissions else None,
            "first_name": request.aq_users.first_name if request.aq_users else None,
            "last_name": request.aq_users.last_name if request.aq_users else None,
            "user_email": request.aq_users.email if request.aq_users else None,
        }
        for request in all_requests
    ]

    # Broadcast the updated role requests to connected WebSocket clients
    try:
        broadcast_message_content = f"{len(all_requests)} role requests retrieved."
        await broadcast_message(broadcast_message_content)
        logger.info(f"Broadcasted message: {broadcast_message_content}")
    except Exception as e:
        logger.error(f"Error broadcasting message: {str(e)}")

    # Return the results
    return {
        "success": True,
        "role_requests": formatted_requests,
    }

# from fastapi import APIRouter, Depends, HTTPException, status, Request
# from prisma import Prisma
# from app.core.database import get_prisma_client  # Import the Prisma client dependency
# from app.core.auth import get_current_user
# from app.api.userManagement.utils.wsUtils import broadcast_message  # Import the WebSocket utility

# # Create an instance of APIRouter
# router = APIRouter()

# @router.get("/getRoleRequests", status_code=status.HTTP_200_OK)
# async def get_all_role_requests(request: Request,
#     current_user: dict = Depends(get_current_user),  # Admin authentication assumed
#     prisma: Prisma = Depends(get_prisma_client)  # Inject the Prisma client here
#       # Access the request object to get the logger
# ):
#     """
#     Fetch all role requests, including ID, reason, status, and user's first name, last name, and email.
#     This endpoint is only accessible by admins.
#     """
#     logger = request.state.logger  # Access the logger from request.state

#     logger.info(f"Admin {current_user.username} is fetching all role requests.")

#     # Ensure the current user is an admin
#     if not current_user.is_admin:
#         logger.warning(f"Non-admin user {current_user.username} tried to access role requests.")
#         raise HTTPException(
#             status_code=403,
#             detail="You do not have permission to access this resource."
#         )

#     # Query the database for all role requests and include user details
#     try:
#         all_requests = await prisma.aq_rolerequests.find_many(
#             include={"aq_users": True}  # Include the related user details
#         )
#         logger.info(f"Successfully fetched {len(all_requests)} role requests from the database.")
#     except Exception as e:
#         logger.error(f"Error retrieving role requests: {str(e)}")
#         raise HTTPException(
#             status_code=500,
#             detail=f"Error retrieving role requests: {str(e)}"
#         )

#     # Format the data
#     formatted_requests = [
#         {
#             "id": request.id,
#             "reason": request.reason,
#             "requested_role": request.requested_role,
#             "user_id": request.user_id,
#             "timestamp": request.timestamp,
#             "status": request.status,  # Include status of the request
#             "admin_comment": request.admin_comment,
#             "first_name": request.aq_users.first_name if request.aq_users else None,
#             "last_name": request.aq_users.last_name if request.aq_users else None,
#             "user_email": request.aq_users.email if request.aq_users else None,  # Get the user's email
#         }
#         for request in all_requests
#     ]

#     # Broadcast the updated role requests to connected WebSocket clients
#     try:
#         broadcast_message_content = f"{len(all_requests)} role requests retrieved."
#         await broadcast_message(broadcast_message_content)
#         logger.info(f"Broadcasted message: {broadcast_message_content}")
#     except Exception as e:
#         logger.error(f"Error broadcasting message: {str(e)}")

#     # Return the results
#     return {
#         "success": True,
#         "role_requests": formatted_requests,
#     }
