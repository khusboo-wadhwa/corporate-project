from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from datetime import datetime
import jwt
from app.api.userManagement.utils.jwt import SECRET_KEY, ALGORITHM

router = APIRouter()

async def get_current_user(request: Request):
    try:
        access_token = request.cookies.get("access_token")
        if not access_token:
            raise HTTPException(status_code=401, detail="Not authenticated")
        
        payload = jwt.decode(access_token, SECRET_KEY, algorithms=[ALGORITHM])
        
        # Check if token is expired
        if datetime.utcnow() > datetime.fromtimestamp(payload["exp"]):
            raise HTTPException(status_code=401, detail="Token expired")
            
        return {
            "id": payload["sub"],
            "email": payload["email"],
            "first_name": payload["first_name"],
            "last_name": payload["last_name"],
            "property_id": payload["property_id"],
            "roles": payload["roles"],
            "permissions": payload["permissions"]
        }
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token expired")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Invalid token")
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.get("/currentuser")
async def current_user(user = Depends(get_current_user)):
    return user