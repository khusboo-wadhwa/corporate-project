"""this api for non admin user to send request mail to admin for the 
input-email of the user who requested foe foreget password"""
from fastapi import FastAPI, HTTPException, Depends, APIRouter
from pydantic import BaseModel, EmailStr
from app.core.database import get_prisma_client
from app.api.userManagement.utils.emailUtils import send_email_forgetpass_non_admin

# Initialize FastAPI app
router = APIRouter()

FROM_EMAIL="vaishnavi.bhambure@rgs-tech.com"
# Pydantic model for the request
class ForgotPasswordRequest(BaseModel):
    email: EmailStr


# Forgot password endpoint
@router.post("/forgotPasswordNonAdmin")
async def forgot_password(request: ForgotPasswordRequest, prisma=Depends(get_prisma_client)):
    # Fetch the user from the database
    user = await prisma.aq_users.find_first(where={"email": request.email})

    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    if user.is_admin:
        raise HTTPException(status_code=403, detail="Admin users cannot use this endpoint")

    # Fetch the admin email from the database
    admin_user = await prisma.aq_users.find_first(where={"is_admin": True})
    if not admin_user or not admin_user.email:
        raise HTTPException(status_code=500, detail="Admin email not found in the database")

    # Prepare the email for admin
    subject = "Forgot Password Request"
    body = (
        f"A forgot password request has been initiated for the user with the following details:\n\n"
        f"Name: {user.first_name} {user.last_name}\n"
        f"Email: {user.email}\n"
        f"Username: {user.username}\n\n"
        f"Please verify and reset the password as necessary."
    )

    # Send email to admin via Mailjet
    await send_email_forgetpass_non_admin(FROM_EMAIL, admin_user.email, subject, body)

    return {"message": "Password reset request has been sent to the admin."}


#logs
from fastapi import FastAPI, HTTPException, Depends, APIRouter, Request
from pydantic import BaseModel, EmailStr
from app.core.database import get_prisma_client
from app.api.userManagement.utils.emailUtils import send_email_forgetpass_non_admin

# Initialize FastAPI app
router = APIRouter()

FROM_EMAIL = "vaishnavi.bhambure@rgs-tech.com"

# Pydantic model for the request
class ForgotPasswordRequest(BaseModel):
    email: EmailStr


# Forgot password endpoint
@router.post("/forgotPasswordNonAdmin")
async def forgot_password(
    request: ForgotPasswordRequest,req: Request,
    prisma=Depends(get_prisma_client),
      # Access logger via request state
):
    logger = req.state.logger  # Access logger from request state

    try:
        # Step 1: Fetch the user from the database
        logger.info(f"Fetching user with email: {request.email}")
        user = await prisma.aq_users.find_first(where={"email": request.email})

        if not user:
            logger.warning(f"User with email {request.email} not found.")
            raise HTTPException(status_code=404, detail="User not found")

        if user.is_admin:
            logger.warning(f"Admin user {request.email} attempted to use non-admin endpoint.")
            raise HTTPException(status_code=403, detail="Admin users cannot use this endpoint")

        # Step 2: Fetch the admin email from the database
        logger.info("Fetching admin email from the database.")
        admin_user = await prisma.aq_users.find_first(where={"is_admin": True})
        if not admin_user or not admin_user.email:
            logger.error("Admin email not found in the database.")
            raise HTTPException(status_code=500, detail="Admin email not found in the database")

        # Step 3: Prepare the email for admin
        logger.info(f"Preparing email for admin: {admin_user.email}")
        subject = "Forgot Password Request"
        body = (
            f"A forgot password request has been initiated for the user with the following details:\n\n"
            f"Name: {user.first_name} {user.last_name}\n"
            f"Email: {user.email}\n"
            f"Username: {user.username}\n\n"
            f"Please verify and reset the password as necessary."
        )

        # Step 4: Send email to admin via Mailjet
        logger.info(f"Sending email to admin: {admin_user.email}")
        await send_email_forgetpass_non_admin(FROM_EMAIL, admin_user.email, subject, body)

        logger.info(f"Password reset request sent to admin for user: {user.email}")
        return {"message": "Password reset request has been sent to the admin."}

    except HTTPException as http_exc:
        logger.error(f"HTTPException: {http_exc.detail}")
        raise http_exc

    except Exception as e:
        logger.error(f"Unexpected error processing forgot password request: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Error processing request: {str(e)}")

