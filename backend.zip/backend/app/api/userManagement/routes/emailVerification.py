
# from fastapi import APIRouter, HTTPException
# from datetime import datetime, timedelta, timezone
# from app.core.database import get_prisma_client
# from app.api.userManagement.utils.emailUtils import generate_verification_code, send_verification_email



# router = APIRouter()

# @router.post("/verifyEmail")
# async def verify_email_code(email: str, verification_code: str):
#     """
#     Verifies the email code and marks the email as verified.
#     If the code is expired, it generates a new code and sends it to the email.
#     """
#     try:
#         prisma = await get_prisma_client()

#         # Fetch user by email
#         user = await prisma.aq_users.find_first(where={"email": email})
        
#         if not user:
#             raise HTTPException(
#                 status_code=404, 
#                 detail="Email does not exist in the database"
#             )
        
#         # Check if the email is already verified
#         if user.is_email_verified:
#             return {
#                 "success": True,
#                 "message": "This email is already verified."
#             }

#         current_time = datetime.now(timezone.utc)  # Timezone-aware (UTC)

#         # Check if the verification code has expired
#         if user.email_verification_code_expires_at < current_time:
#             new_code = generate_verification_code()
#             new_expiry_time = current_time + timedelta(minutes=1)  # Set new expiry time
            
#             # Update the user's verification code and expiry time in the database
#             await prisma.aq_users.update(
#                 where={"email": email},
#                 data={
#                     "email_verification_code": new_code,
#                     "email_verification_code_expires_at": new_expiry_time,
#                     "email_verification_code_sent_at": datetime.utcnow()
#                 }
#             )

#             # Send the new verification code to the user's email
#             send_verification_email(email, new_code)  # Your function is synchronous

#             return {
#                 "success": True,
#                 "message": "Verification code expired. A new code has been sent to your email."
#             }

#         # Validate the provided verification code
#         if user.email_verification_code != verification_code:
#             return {
#                 "success": False,
#                 "message": "The provided verification code is incorrect."
#             }

#         # If the code is valid and not expired, mark the email as verified
#         await prisma.aq_users.update(
#             where={"email": email},
#             data={
#                 "is_email_verified": True,
#                 "email_verification_code": None  # Nullify the verification code column
#             }
#         )

#         return {
#             "success": True,
#             "message": "Email verified successfully."
#         }
        
#     except HTTPException as e:
#         raise e

#     except Exception as e:
#         raise HTTPException(
#             status_code=500,
#             detail=f"An error occurred while verifying the email: {str(e)}"
#         )




#logs
from fastapi import APIRouter, HTTPException, Request
from datetime import datetime, timedelta, timezone
from app.core.database import get_prisma_client
from app.api.userManagement.utils.emailUtils import generate_verification_code, send_verification_email

router = APIRouter()

@router.post("/verifyEmail")
async def verify_email_code(email: str, verification_code: str, request: Request):
    """
    Verifies the email code and marks the email as verified.
    If the code is expired, it generates a new code and sends it to the email.
    """
    logger = request.state.logger  # Access the logger from request.state

    try:
        logger.info(f"Verifying email for {email}")

        prisma = await get_prisma_client()

        # Fetch user by email
        user = await prisma.aq_users.find_first(where={"email": email})
        
        if not user:
            logger.warning(f"Email {email} does not exist in the database.")
            raise HTTPException(
                status_code=404, 
                detail="Email does not exist in the database"
            )
        
        # Check if the email is already verified
        if user.is_email_verified:
            logger.info(f"Email {email} is already verified.")
            return {
                "success": True,
                "message": "This email is already verified."
            }

        current_time = datetime.now(timezone.utc)  # Timezone-aware (UTC)

        # Check if the verification code has expired
        if user.email_verification_code_expires_at < current_time:
            logger.info(f"Verification code expired for {email}. Generating a new code.")
            new_code = generate_verification_code()
            new_expiry_time = current_time + timedelta(minutes=1)  # Set new expiry time
            
            # Update the user's verification code and expiry time in the database
            await prisma.aq_users.update(
                where={"email": email},
                data={ 
                    "email_verification_code": new_code,
                    "email_verification_code_expires_at": new_expiry_time,
                    "email_verification_code_sent_at": datetime.utcnow()
                }
            )

            # Send the new verification code to the user's email
            send_verification_email(email, new_code)  # Your function is synchronous

            logger.info(f"New verification code sent to {email}")
            return {
                "success": True,
                "message": "Verification code expired. A new code has been sent to your email."
            }

        # Validate the provided verification code
        if user.email_verification_code != verification_code:
            logger.warning(f"Invalid verification code for {email}.")
            return {
                "success": False,
                "message": "The provided verification code is incorrect."
            }

        # If the code is valid and not expired, mark the email as verified
        await prisma.aq_users.update(
            where={"email": email},
            data={ 
                "is_email_verified": True,
                "email_verification_code": None  # Nullify the verification code column
            }
        )

        logger.info(f"Email {email} successfully verified.")
        return {
            "success": True,
            "message": "Email verified successfully."
        }

    except HTTPException as e:
        logger.error(f"HTTPException occurred: {e.detail}")
        raise e

    except Exception as e:
        logger.error(f"An unexpected error occurred while verifying email {email}: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail=f"An error occurred while verifying the email: {str(e)}"
        )
