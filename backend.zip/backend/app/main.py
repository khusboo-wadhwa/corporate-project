import logging
from logging.handlers import RotatingFileHandler
from fastapi import FastAPI, Request, WebSocket, WebSocketDisconnect
from app.api.userManagement.routes.tokenCron import start_token_cleanup_job
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse
from app.api.userManagement.utils.wsUtils import (
    broadcast_message,
    add_client,
    remove_client,
)
from app.api.userManagement.routes.adminRotues import router as adminReg_router
from app.api.userManagement.routes.userRegisterRoutes import router as userReg_router
from app.api.userManagement.routes.loginRoutes import router as login_router
from app.api.userManagement.routes.checkEmail import router as checkemail_router
from app.api.userManagement.routes.verifyPhoneRoute import router as verifyphone_router
from app.api.userManagement.routes.emailVerification import router as verifyemail_router
from app.api.userManagement.routes.getUser import router as getUser_router
from app.api.userManagement.routes.forgetPassword import router as forgetPassword_router
from app.api.userManagement.routes.updatePassword import router as updatePassword_router
from app.api.userManagement.routes.roleRequest import router as roleRequest_router
from app.api.userManagement.routes.acceptRole import router as acceptRole_router
from app.api.userManagement.routes.rejectRole import router as rejectRole_router
from app.api.userManagement.routes.deleteRole import router as deleteRole_router
from app.api.userManagement.routes.deleteUser import router as deleteUser_router
from app.api.userManagement.routes.editUser import router as editUser_router
from app.api.userManagement.routes.getRoleReq import router as getRoleReq_router
from app.api.userManagement.routes.forgetPassNonAdmin import (
    router as forgetNonAdmin_router,
)
from app.api.userManagement.routes.sendTempPassEmailNonAdmin import (
    router as resetNonAdmin_router,
)
from app.api.userManagement.routes.resetPassUserNonAdmin import (
    router as resetPassUserNonAdmin_router,
)
from app.api.userManagement.routes.routes import router as user_router
from app.api.userManagement.routes.phoneotp import router as otp_router
from app.api.userManagement.routes.createrole import router as roles_router
from app.api.userManagement.routes.googleOauth import router as oauth_router
from app.api.userManagement.routes.refreshToken import router as refresh_token
from app.api.userManagement.routes.decodeToken import router as decode_token
from app.api.userManagement.routes.twoFactor import router as twofactor_touter

from app.api.settings.routers import (
    credit_policy_router,
    notification_templates_router,
    security_settings_router,
    dashboard_router,
    management_router,
    system_management_router,
    system_settings_router,
    verification_policy_router,
    contract_defaults_router
)

from starlette.middleware.sessions import SessionMiddleware
from dotenv import load_dotenv

load_dotenv()


# Create FastAPI app
app = FastAPI()

# Add CORS middleware
origins = [
    "https://aq.dev.rhombusquest.com",
    "https://bq.dev.rhombusquest.com",
    "http://localhost:3000",
    "http://localhost:8000",
    "http://localhost:3001",
    "http://localhost:9000",
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

SESSION_SECRET_KEY = "super-secret-session-key"
print(type(SESSION_SECRET_KEY))
app.add_middleware(
    SessionMiddleware,
    secret_key=SESSION_SECRET_KEY,
    same_site="lax",  # allow redirect cookies from Google
    https_only=False,  # only True in production with HTTPS
    path="/",  # make sure it's not scoped to /aq/api
)
# Initialize the logger
logger = logging.getLogger("AQ_log")
logger.setLevel(logging.INFO)

# Create a RotatingFileHandler to log to a file with rotation
log_file = "AQapplication.log"  # Path to your log file
file_handler = RotatingFileHandler(log_file, maxBytes=10 * 1024 * 1024, backupCount=3)
file_handler.setLevel(logging.INFO)

# Create a formatter and set it for the handler
formatter = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
file_handler.setFormatter(formatter)

# Add the file handler to the logger
logger.addHandler(file_handler)


# Middleware to add the logger to request.state
@app.middleware("http")
async def add_logger_to_request(request: Request, call_next):
    request.state.logger = logger
    response = await call_next(request)
    return response


@app.on_event("startup")
async def startup_event():
    start_token_cleanup_job()


# Register routers
shared_tag = ["AQ API-Vaish"]
app.include_router(adminReg_router, prefix="/aq/api", tags=shared_tag)
app.include_router(userReg_router, prefix="/aq/api", tags=shared_tag)
app.include_router(login_router, prefix="/aq/api", tags=shared_tag)
app.include_router(checkemail_router, prefix="/aq/api", tags=shared_tag)
app.include_router(verifyemail_router, prefix="/aq/api", tags=shared_tag)
app.include_router(verifyphone_router, prefix="/aq/api", tags=shared_tag)
app.include_router(getUser_router, prefix="/aq/api", tags=shared_tag)
app.include_router(forgetPassword_router, prefix="/aq/api", tags=shared_tag)
app.include_router(updatePassword_router, prefix="/aq/api", tags=shared_tag)
app.include_router(roleRequest_router, prefix="/aq/api", tags=shared_tag)
app.include_router(getRoleReq_router, prefix="/aq/api", tags=shared_tag)
app.include_router(acceptRole_router, prefix="/aq/api", tags=shared_tag)
app.include_router(rejectRole_router, prefix="/aq/api", tags=shared_tag)
app.include_router(deleteRole_router, prefix="/aq/api", tags=shared_tag)
app.include_router(deleteUser_router, prefix="/aq/api", tags=shared_tag)
app.include_router(editUser_router, prefix="/aq/api", tags=shared_tag)
app.include_router(forgetNonAdmin_router, prefix="/aq/api", tags=shared_tag)
app.include_router(resetNonAdmin_router, prefix="/aq/api", tags=shared_tag)
app.include_router(resetPassUserNonAdmin_router, prefix="/aq/api", tags=shared_tag)
app.include_router(roles_router, prefix="/aq/api")
app.include_router(user_router, prefix="/api/userManagement", tags=["User Management"])
app.include_router(oauth_router, prefix="/aq/api", tags=shared_tag)
app.include_router(otp_router, prefix="/aq/api", tags=shared_tag)
app.include_router(refresh_token, prefix="/aq/api", tags=shared_tag)
app.include_router(decode_token, prefix="/aq/api", tags=shared_tag)
app.include_router(twofactor_touter, prefix="/aq/api", tags=shared_tag)

corporate_routers = (
    credit_policy_router,
    notification_templates_router,
    security_settings_router,
    dashboard_router,
    management_router,
    system_management_router,
    system_settings_router,
    verification_policy_router,
    contract_defaults_router
)

for router in corporate_routers:
    app.include_router(router, prefix="/aq/api")


@app.get("/")
async def root(request: Request):
    request.state.logger.info("Root endpoint accessed")
    return {"message": "Welcome to the API!"}


@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
    await add_client(websocket)

    try:
        while True:
            data = await websocket.receive_text()
            await broadcast_message(data)
    except WebSocketDisconnect:
        await remove_client(websocket)
        print("Client disconnected")


@app.get("/")
async def get():
    return HTMLResponse("""
        <html>
            <body>
                <h1>FastAPI WebSocket Example</h1>
                <script>
                    var ws = new WebSocket("ws://localhost:8000/ws");
                    ws.onmessage = function(event) {
                        console.log("Message from server: ", event.data);
                    };
                    ws.onopen = function() {
                        ws.send("Hello, server!");
                    };
                </script>
            </body>
        </html>
    """)
